 #include<iostream>
 #include<string>
 using namespace std;
 int main ()
 {
    string str;
    cin >> str;
    cout << str << endl;
    string str1(5,'S');// to print character S five times
    cout << str1 << endl;
    string str2="Suraj Kumar";
    cout<<str2<<endl;
    string str3;
    cin>>str3;
    cout<<str3<<endl;// this give only first word of the sentence as cin will take only 1st word as input;
     return 0;
 }