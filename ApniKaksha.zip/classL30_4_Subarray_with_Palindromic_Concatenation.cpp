 #include<bits/stdc++.h>
 using namespace std;

 bool check(vector<int>& v){
    for(int i=0; i<v.size()/2;i++){
          if(v[i]!=v[v.size()-1-i]){
            return false;
          }
    }return true;
 }
vector<int> PalindromicSubarayofsizeK1(vector<int>& v,int k){
        vector<int> ans,index;
        for(int i=0;i<k; i++){
            ans.push_back(v[i]);
            index.push_back(i);
        }
        if(check(ans)){
             cout<<"Required Subarray Index: "<< endl;
             for(int j=0;j<index.size();j++){
                    cout<<index[j]<<" ";
                }cout<<endl;
            return ans;
        }
        for(int  i=k;i<v.size();i++){
            ans.erase(ans.begin());
            index.erase(index.begin());
            ans.push_back(v[i]);
            index.push_back(i);
            if(check(ans)){
                 cout<<"Required Subarray Index: "<< endl;
                for(int j=0;j<index.size();j++){
                    cout<<index[j]<<" ";
                }cout<<endl;
                return ans;
            }
        }
        ans.clear();
        ans.push_back(-1);
        return ans;

}

// second way of  finding 
bool isPalindrome(int n){
    int temp=n,num=0;
    // reverse n-->123.. number--> 321
    while(temp>0){
        num=num*10+temp%10;
        temp/=10;
    }
    if(num==n){
        return 1;
    }
    return 0;
}
int PalindromicSubarayofsizeK2(vector<int>  v,int k){
    int  num=0;
    for(int i=0;i<k; i++){
        num=num*10+v[i];
    }
    if(isPalindrome(num)){
        return 0;
    }
    for(int j=k;j<v.size();j++){
        int p=pow(10,k-1);
        if(k%2!=0){
          p=p+1;
        }
        num=(num%p)*10+v[j];
        if(isPalindrome(num)){
            return j-k+1;
        }
    }return -1;
}
int main(){
    vector<int> v={2,3,1,5,1,5,1};
    int k;cin>>k;
    vector<int> ans=PalindromicSubarayofsizeK1(v,k);
    cout<<"Required Subarray: "<<endl;
    for(int i=0;i<ans.size();i++){
        cout<<ans[i]<<" ";
    }cout<<endl;
    
    cout<<"Index: "<<PalindromicSubarayofsizeK2(v,k)<<" to "<<PalindromicSubarayofsizeK2(v,k)+k-1<<endl;
    return 0;
    
}