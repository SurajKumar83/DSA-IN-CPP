#include "bits/stdc++.h"
#include <climits>
using namespace std;
bool isPossible(int arr[], int n, int m, int min)//min: takes the mid value
{
    int studentsRequired = 1;// number of students required
    int sum = 0;// sum of total pages
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > min)// if arr[i] if greater than the minimum means false
        {
            return false;
        }
        if (sum + arr[i] > min)// if sum + arr[i] if greater than the minimum then go for next student

        {
            studentsRequired++;
            sum = arr[i];
            if (studentsRequired > m)// in case the studentsRequired greater than  the number of student then false
            {
                return false;
            }
        }
        else// sum+arr[i]<=min
        {
            sum += arr[i];
        }
    }
    return true;
}
int allocateMinimum(int arr[], int n, int m) // n: n different books;and m: m different students
{
    int sum = 0; // use to find the maximum value
    if (n < m)// means number of books are smaller than students
    {
        return -1;
    }
    for (int i = 0; i < n; i++)
    {
        sum += arr[i];
    }
    int start = 0, end = sum, ans = INT_MAX;
    // range (start,end)
    while (start <= end)
    {
        int mid = (start + end) / 2;
        if (isPossible(arr, n, m, mid))
        {
            ans = min(ans, mid);
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
    }
    return ans;
}
int main()
{
    int arr[] = {12, 34, 67, 90};
    int n = 4;
    int m = 2;
    cout << "The minimum number of pages: " << allocateMinimum(arr, n, m) << endl;
    return 0;
}