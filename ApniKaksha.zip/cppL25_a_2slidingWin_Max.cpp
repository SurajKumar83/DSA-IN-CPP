#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,k;// n=num of elements in array ,k= size of window;
    cin>>n>>k;
    vector<int> a(n);
    for(auto &i: a)
    {
      
    }
    return 0;
}