#include<bits/stdc++.h>
using namespace std;
int decimaltobinary(int n){
   int t=1;
int sum=0;
while (t<=n)
{
   t*=2;
}
t/=2;
while (t>0)
{
   int lastdigit=n/t;
   n=n-lastdigit*t;
   t/=2;
   sum=sum*10+lastdigit;
}
return sum;


  /* while(n>0)
   {
       t=n%2;
       cout<<t;
       n=n/2;
   } */ 
}
int main(){
    int n;
    cin>>n;
    cout<< decimaltobinary(n);
    return 0;
}

// recursion method

// #include<bits/stdc++.h>
// using namespace std;
// void decimaltoBinary(int n)
// {
//    if (n==0)
//    {
//       return;
//    }
   
//    decimaltoBinary(n/2);
//    cout<<n%2;
// }
// int main(){
//    int n;
//    cin>>n;
//    decimaltoBinary(n);
// }