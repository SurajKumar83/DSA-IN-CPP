// Divide and Conquer
//Merge sort in cpp
#include<iostream>
#include<vector>
using namespace std;
void merge(int arr[],int l,int mid,int r){
    int b[r];
    int i=l;
    int j=mid+1;
    int k=l;
    vector<int> v;
    while (i<=mid && j<=r)
    {
        if (arr[i]<arr[j])
        {
            b[k]=arr[i];
            v.push_back(arr[i]);
             i++;
        }
        else
        {
            b[k]=arr[j];
            v.push_back(arr[j]);
            j++;
        }
        k++;
    }
    // if array a remain after end of b or array b remain after a end
   if(i>mid)
   { 
      while (j<=r)
    {
        b[k]=arr[j];
        v.push_back(arr[j]);
        k++; 
        j++;
    } 
   }
   else
   {
         while (i<=mid)
    {
        b[k]=arr[i];
        v.push_back(arr[i]);
        k++; 
        i++;
    }
    
   }
   for (int i = l; i <=r; i++)
   {
       arr[i]=b[i];
   }
   for(int i=0;i<v.size(); i++){
      cout<<v[i]<<" ";
   }cout<<endl;
}
void mergeSort(int arr[], int l ,int r)
{
    // if l==r means only one element remained
    if (l<r)
    {
        int mid =(l+r)/2;
        mergeSort(arr,l,mid);
        mergeSort(arr,mid+1,r);
        merge(arr,l,mid,r);
    }
}
int main()
{
    
    int arr[]={3,3,4,1,5,6};
    mergeSort(arr,0,5);
    for (int i = 0; i <6; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;
}