// The span of the stock's price today is defined as the maximm number of consecutive days (starting from today and goning backwads) for which the price of the stocks was less then or wqual to today's price.
// Find the span of the stocks for all the days.

// //brute force approach
// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for (int i = 0; i < n; i++)
//     {
//         cin>>arr[i];
//     }
//     for (int i = 0; i < n; i++)
//     {
//         int days=0;
//         for (int j = i; j>=0; j--)
//         {
//             if (arr[i]>=arr[j])
//             {
//                 days++;
//             }
//             else
//             {
//                 break;
//             }
            
//         }
        
//     }
    
    
//     return 0;
// }

#include<bits/stdc++.h>
using namespace std;

vector<int> stockspan(vector<int> prices)
{
    vector<int> ans;// to store answer
    stack<pair<int,int>> s;// stack of pair

    for(auto price: prices)
    {
        int days=1;// intially
        while (!s.empty() && s.top().first <= price)
        {
            days+= s.top().second;// till not empty and top element less then current element
            s.pop();
        }
        
        s.push({price,days});
        ans.push_back(days);
    }
    return ans;
}
int main(){
    vector<int> a={100,80,60,70,60,75,85};
    vector<int> res=stockspan(a);
    for(auto i :res){
        cout<<i<<" ";

    }cout<<endl;
    return 0;
}