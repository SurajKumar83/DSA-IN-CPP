#include<bits/stdc++.h>
using namespace std;
 
 class Node 
 {
     public:
     int data;
     class Node* left;
     class Node* right;
   
  
   Node (int val)
   {
      data = val;
      left=NULL;
      right=NULL;
   }
 };
 int search(int inorder[],int st,int end,int curr)
 {
     for (int  i = st; i <=end; i++)
     {
         if (inorder[i] == curr)
         {
             return i;
         }
         
     }
     return -1;
     
 }
 // Functions to return Node pointer mens node of all tree
 Node* BuildTree(int preorder[],int inorder[],int st,int end)// st means start of INORDER AND end means END of INORDER sequence
 {
      static int idx = 0;// to say the position of the node in preorder
      if (st>end)
      {
          return NULL;
      }
      
      // to form node of for the element at  index position in preorder
      int curr = preorder[idx];
      idx++;// increment in index position
      Node* node = new Node(curr);

     if(st==end)// in case start == end 
      {
         return node;
      }
      // Search the position of current node in inorder list
      int pos = search(inorder,st,end,curr);
      // Build  left subtree
      node->left = BuildTree(preorder,inorder,st,pos-1);//pos -1  means in inorder we move till left part of the trees
      node->right = BuildTree(preorder,inorder,pos+1,end);// pos +1 means in inorder we move from start of right to end of right part of the tree 
      return node;
 }

 void inorderPrint(Node* root)
 {
     if (root==NULL)
     {
         return;
     }
     
     
     inorderPrint(root->left);
     cout<<root->data<<" ";
     inorderPrint(root->right);
 }
 int main()
 {
     int preorder[]={1,2,4,3,5};
     int inorder[]={4,2,1,5,3};

     // build trees
     Node* root = BuildTree(preorder, inorder,0,4);
     cout<<"Inorder Sequence"<<endl;
     inorderPrint(root);
     return 0; 
 }