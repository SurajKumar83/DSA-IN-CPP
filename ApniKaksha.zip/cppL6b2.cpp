#include<iostream>
using namespace std;
void fibonacci(int n)
{
    int t1=0;
    int t2=1;
    int sum;
    for (int i = 1; i <=n; i++)
    {
        cout<<t1;
        sum = t1+t2;
        t1=t2;
        t2=sum;
    }
  
        
}
int main()
{
    
    int n;
    cin>>n;
   
    fibonacci(n);
   
    return 0;
}