#include <bits/stdc++.h>
using namespace std;
void helper(int r, int c, vector<vector<char>> &a, map<pair<int, int>, map<int, int>> &mp, vector<map<int, int>> &row, vector<map<int, int>> &col)
{
 
    if (r == 9)
    { // as we reach the (8,8)  means we have completed then print the sudoku matrix
        for (auto &it : a)
        {
            
            for (auto &i : it)
            {
                cout << i << " ";
            }
            cout << endl;
        }
        cout << endl;
        return;
    }
    if (c == 9)
    { // means we have completed the current row so move to the next row
        helper(r + 1, 0, a, mp, row, col);
        return;
    }
    if (a[r][c] != '.')
    {
        // not empty that column  then go to the next column;
        helper(r, c + 1, a, mp, row, col);
        return;
    }
    for (int i = 1; i <= 9; i++)
    { // this is for 3x3 9 matrices
        int rw = r / 3, cl = c / 3;
        if (!mp[{rw, cl}][i] and !row[r][i] and !col[c][i])
        {
            mp[{rw, cl}][i] = 1;
            row[r][i] = 1;
            col[c][i] = 1;
            a[r][c] = i + '0';
            helper(r, c + 1, a, mp, row, col);
            mp[{rw, cl}][i] = 0;
            row[r][i] = 0;
            col[c][i] = 0;
            a[r][c] = '.';
        }
    }
}
void solveSudoku(vector<vector<char>> &a)
{
    map<pair<int, int>, map<int, int>> mp; // here pair is used for location of  in small grid of 3x3 and  map store the  element  and frequency
    vector<map<int, int>> row(9);          // vector denoting  row and map to store the element and frequency
    vector<map<int, int>> col(9);          // vector denoting column and map to store the element and frequency
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            if (a[i][j] != '.')
            {
                mp[{i / 3, j / 3}][a[i][j] - '0'] = 1; // i/3 and j/3 denotes the location
                row[i][a[i][j] - '0'] = 1;
                col[i][a[i][j] - '0'] = 1;
            }
        }
    }
    helper(0, 0, a, mp, row, col);
}
int main()
{
    vector<vector<char>> soduku =
        {
            {'2', '6', '4', '.', '1', '5', '8', '3', '9'},
            {'.', '3', '7', '8', '9', '2', '6', '4', '5'},
            {'5', '9', '8', '.', '.', '6', '.', '7', '1'},
            {'4', '2', '3', '1', '7', '8', '5', '9', '.'},
            {'8', '1', '6', '.', '4', '.', '7', '2', '3'},
            {'7', '5', '9', '6', '2', '3', '.', '.', '.'},
            {'3', '7', '5', '2', '.', '.', '9', '6', '4'},
            {'9', '8', '.', '3', '6', '4', '1', '.', '7'},
            {'6', '.', '1', '.', '9', '5', '7', '8', '2'}};

cout<<"Solved Sudoku is: "<<endl;
    solveSudoku(soduku);
    return 0;
}