#include<bits/stdc++.h>
using namespace std;
int decimaltohexadecimal(int n)
{
   int t=1;
   int sum=0;
   while (t<=n)
   {
     t*=16;
   }
   t/=16;//as t comes out of the loop then its value will be increased by 16 times
   while (t>0)
   {
      int lastdigit=n/t;
      n=n-lastdigit*t;
      t/=16;
      if(lastdigit<=9)
     {
          sum=sum+to_string(lastdigit);//to_string fun converts the given number to string 
     }
      else
      {
          char c = 'A' + lastdigit-10;
          ans.push_back(c);
      }
   }
   return sum;
}
int main()
{
    int n;
    cin >> n;
    cout<< decimaltohexadecimal(n)<<endl;
}