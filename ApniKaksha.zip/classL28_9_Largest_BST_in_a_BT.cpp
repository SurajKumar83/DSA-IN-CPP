// return the size of the largest BST in binary tree.
