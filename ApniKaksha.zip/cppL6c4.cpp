//WAP for conversion of octal number to decimal number
#include<iostream>
#include<math.h>
using namespace std ;
int octaltodecimal(int n)
{  
    int sum=0;
    int i=1;
    while (n>0)
    {
        int lastdigit=n%10;
        sum+=lastdigit*i;
          i =i*8;
          n/=10;
    }  
   
    return sum; 
}
int main()
{ 
    int n;
    cin>>n;
    cout<<octaltodecimal(n)<<endl;
    return 0;
}