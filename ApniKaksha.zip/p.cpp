#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int T;
    cin >> T;
  for (int i = 0; i < T; i++)
  {
      int N,K;
      cin>>N>>K;
      string s;
      cin>>s;
     for (int i,j = 0; i,j < s.length(); i++,j++)
     {
         int n=0;
         if (s[i]=='1' && s[j]=='1' && |i-j|<=K )
         {
            n++; 
         }
         cout<<n;
         
         
         
     }
     
  }
  
    
    return 0;
}