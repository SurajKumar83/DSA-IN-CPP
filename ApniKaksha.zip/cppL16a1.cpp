//... Recursion 
// sum of n integers using recursion
#include<bits/stdc++.h>
using namespace std;
int sum(int n)
{
    
   if (n<=0)
   {
       return 0;
   }
   int s=sum(n-1);
   return s+n; 
}
int main()
{
    int n;
    cin>>n;
   
    cout<<sum(n)<<endl;
    return 0;
}
/*
#include<bits/stdc++.h>
using namespace std;
int sum(int n)
{
    
   if (n<=0)
   {
       return 0;
   }
   if (n>0)
   {
       int s=0;
        for (int  i = 1; i <=n; i++)
         {
             s=s+i; 
         }
         return s;
   }  
}
int main()
{
    int n;
    cin>>n;
    int Sum=n+sum(n-1)
    cout<<Sum<<endl;
    return 0;
}
*/