// Intution max(left height,right height)+1 
#include<bits/stdc++.h>
using namespace std;
class Node{
    public:
    int data; 
    class Node* left;
    class Node* right;
    Node(int val){
        data=val;
        left=NULL;
        right=NULL;
    }

};
// Calculate th height of tree 
int calHeight(Node* root)// time comlexity O(N) N: Number of nodes in BT;
{
    if (root==NULL)
    {
        return 0;
    }
    
    int leftHeight=calHeight(root->left);
    int rightHeight=calHeight(root->right);
    return max(leftHeight,rightHeight)+1;
}
// Calculate the diameter of tree
// Diameter of the tree is number of nodes in the longest path between any 2 leaves
int calDiameter(Node *root)// time complexity of O(n^2)
{
    if(root==NULL)
    {
        return 0;
    }
    int leftHeight =calHeight(root->left);
    int rightHeight =calHeight(root->right);
    int curdiameter=leftHeight+rightHeight+1;// if root included

    int leftdiameter =calDiameter(root->left);
    int rightdiameter=calDiameter(root->right);
    return max(leftdiameter,max(rightdiameter,curdiameter));
}
int CalDiameter(Node* root,int* height) {
    if (root==NULL)
    {
        *height=0;
        return 0;
    }
    
    int lh=0,rh=0;
    int leftdiameter=CalDiameter(root->left, &lh);
    int rightdiameter=CalDiameter(root->right,&rh);

int currdiameter=lh+rh+1;
*height=max(lh,rh)+1;
return max(currdiameter,max(leftdiameter,rightdiameter));
}

int main(){

    Node* root=new Node(1);
    root->left=new Node(2);
    root->right=new Node(3);
    root->left->left=new Node(4);
    root->left->right=new Node(5);
    root->right->left=new Node(6);
    root->right->right=new Node(7);
    cout<<"The height of tree is:  "<<calHeight(root)<<endl;
   cout<<"The diameter of the tree is: "<<calDiameter(root);
   int height=0;
     cout<<"The diameter of the tree is: "<<CalDiameter(root,&height)<<endl;
    
    return 0;
}