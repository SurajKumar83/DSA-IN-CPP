/*
Find the  distance between two Nodes in a binary tree.
The distance between two Nodes is the minimum number of edges to be traversed to reach one Node from another.
STRATEGY:
1.find the LCA(lowest common ancestor)
2.find the distance of n1(d1) and n2(d2) from LCA.
3. Return (d1+d2)
*/
#include <bits/stdc++.h>
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val)
    {
        data = val;
        left = NULL;
        right = NULL;
    }
};
Node *LCA(Node *root, int n1, int n2)
{
    if (root == NULL)
    {
        return NULL;
    }
    if (root->data == n1 || root->data == n2)
    {
        return root;
    } // means root data is equal to either n1 or n2
    // if not then
    Node *left = LCA(root->left, n1, n2);   // call for left
    Node *right = LCA(root->right, n1, n2); // call for right
    if ((left != NULL) && (right != NULL))
    {
        // this means we got either n1 or n2 in left and right; so we return the root as lca;

        return root;
    }
    if ((left == NULL) && (right == NULL))
    {
        return NULL; // we don't get LCA HERE as both subtree of that Node are NULL
    }
    if (left != NULL)
    {
        return LCA(root->left, n1, n2);
    }
    return LCA(root->right, n1, n2);
}
int findDistance(Node *root, int k, int final_dist) // here root is LCA
{                                                     // in case iwe have to find the distance between LCA and the node in subtree so that is level
    if (root == NULL)
    {
        return -1;
    }
    if (root->data == k)
    {
        return final_dist;
    }
    int left = findDistance(root->left, k, final_dist + 1);// here final_dist+1 means we have crossed that currentnode
    if (left != -1)
        return left;
        // in case we don't get in left subtree
        
    return findDistance(root->right, k, final_dist + 1);
}
int distanceBtNodes(Node *root, int n1, int n2)
{
    Node *lca = LCA(root, n1, n2);
    int d1 = findDistance(lca, n1, 0);
    int d2 = findDistance(lca, n2, 0);
    return d1 + d2;
}
int main()
{
    Node *root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);
    root->right->right = new Node(5);
    cout << distanceBtNodes(root, 4, 5);
    return 0;
}