/* Output like this 
1 
1 1 
1 2 1 
1 3 3 1 
1 4 6 4 1 
*/
#include<iostream>
using namespace std;
long int factorial(int p)
{
    int fact =1;
    for (int i =1 ; i <= p; i++)
    {
        fact=fact*i;  
    }
    return fact;
}
int NCR(int n,int r){
    int nCr=factorial(n)/(factorial(n-r)*factorial(r));
    return nCr;
}

int main(){
    int n;
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            cout<<NCR(i,j)<<" ";
        }
        cout<<endl;
        
    }
    
    return 0;
}