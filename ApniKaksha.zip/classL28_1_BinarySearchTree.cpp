/*
Binary Search Tree is a node-based binary
tree data structure which has the following
 properties:



1 The left subtree of a node contains only
 nodes with keys lesser than the node’s key.
2 The right subtree of a node contains only
 nodes with keys greater than the node’s key.
3 The left and right subtree each must also
 be a binary search tree.
                      3
                    /  \
                  2     7
                 /     / \
                1    5    8
                    /  \
                   4   6
  Inorder: 1 2 3 4 5 6 7 8
  Preorder: 3 2 1 7 5 4 6 8
*/
#include "bits/stdc++.h"
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val)
    {
        data = val;
        left = NULL;
        right = NULL;
    }
};
// buid BST using array
Node *insertBST(Node *root, int val)
{
    if (root == NULL) // at null node we add new node
    {
        return new Node(val);
    }

    if (val < root->data)
    {
        root->left = insertBST(root->left, val);
    }
    else
    { // val > root->data

        root->right = insertBST(root->right, val);
    }
    return root;
}
void preorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    cout << root->data << " ";
    preorder(root->left);

    preorder(root->right);
}
void inorder(Node *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}
int main()
{
    Node *root = new Node(3);
    root->left = new Node(2);
    root->right = new Node(7);
    root->left->left = new Node(1);
    root->right->right = new Node(8);
    root->right->left = new Node(5);
    root->right->left->left = new Node(4);
    root->right->left->right = new Node(6);
    cout << "Preorder" << endl;
    preorder(root);
    cout << endl;
    int size;
    cin >> size;
    int array[size];
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    Node *root2 = NULL;
    root2 = insertBST(root2, array[0]);
    for (int i = 1; i < size; i++)
    {
        insertBST(root2, array[i]);
    }
    // print inorder
    inorder(root2);
    cout<<endl;
}