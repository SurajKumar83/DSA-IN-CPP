#include <bits/stdc++.h>
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int data) : data(data), left(NULL), right(NULL) {}
};
/*
                             1
                           /   \
                          2     3
                        /  \   /  \
                       4    5 6    7
                           / \
                          8   9

to print the BT in order 1 3 2 6 7 4 5 9 8

*/
void zigzag1(node *root)
{
    if (root == NULL)
        return;
    int level = 0;

    queue<node *> q;
    q.push(root);
    q.push(NULL);
    while (!q.empty())
    {
        node *curr = q.front();
        q.pop();
        if (curr != NULL)
        {

            if (level % 2 == 0)
            {
                cout << curr->data << " ";
                q.push(curr->right);
                q.push(curr->left);
            }
            else
            {
                cout << curr->data << " ";
                q.push(curr->left);
                q.push(curr->right);
            }
        }
        else if (!q.empty())
        {
            q.push(NULL);
            level++;
        }
    }
}
/*
                             1
                           /   \
                          2     3
                        /  \   /  \
                       4    5 6    7
                           / \
                          8   9

to print the BT in order 1 3 2 4 5 6 7 9 8

*/
/*
Strategy
1 Use 2 stacks- CurrentLevel & nextLevel
2 variable LeftToRight
3 if LeftToRight, Push left child then right child
4 else, push right child then left child
*/
void zigzag2(node *root)
{
    if (root == NULL)
        return;
    stack<node *> currLevel;
    stack<node *> nextLevel;
    bool leftToRight = true; // for showing direction
    currLevel.push(root);    // for showing currentLevel
    while (!currLevel.empty())
    {
        node *temp = currLevel.top(); // storing current level top to temp var
        currLevel.pop();              // then removing the current level top
        if (temp != NULL)
        {
            cout << temp->data << " ";

            if (leftToRight) // we are moveing left to right at that level
            {
                if (temp->left) // means temp->left is not null
                {
                    nextLevel.push(temp->left); // then push the temp left to the nextLevel
                }
                if (temp->right) // means temp->right is not null
                {
                    nextLevel.push(temp->right); // then push the temp right to
                }
            }
            // Right to left
            else
            {
                if (temp->right) // means temp->right is not null
                {
                    nextLevel.push(temp->right); // then push the temp right to
                }
                if (temp->left) // means temp->left is not null
                {
                    nextLevel.push(temp->left); // then push the temp left to
                }
            }
        }
        if (currLevel.empty())
        {
            leftToRight = !leftToRight; // opposite of the left to right
            swap(currLevel, nextLevel);
        }
    }
}
int main()
{
    node *root = new node(1);
    root->left = new node(2);
    root->right = new node(3);
    root->left->left = new node(4);
    root->left->right = new node(5);
    root->right->left = new node(6);
    root->right->right = new node(7);
    root->left->right->left = new node(8);
    root->left->right->right = new node(9);
    zigzag2(root);
    cout << endl;
    zigzag1(root);
    return 0;
}