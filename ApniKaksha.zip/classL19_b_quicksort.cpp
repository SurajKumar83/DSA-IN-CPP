#include<iostream>
using namespace std;
int swap(int a[],int i,int j){
    int temp=a[i];
    a[i]=a[j];
    a[j]=temp;
}
int partition(int a[],int l, int h){
    // int mid=(l+h)/2;
    int pivot=a[l];
    int i=l;
    int j=h;
    while (i<j)
    {
        while (a[i]<=pivot)
        {
            i++;
        }
        while (a[j]>pivot)
        {
            j--;
        }
        if (i<j)
        {
            swap(a,i,j);
        }   
    }
    swap(a,j,l);
    return j;
    
}
int quicksort(int a[],int l,int h){
    if (l<h)
    {
      int pivot=partition(a,l,h);
      quicksort(a,l,pivot-1);
      quicksort(a,pivot+1,h);  
     }
    
}
int main(){
    int a[]={1,2,4,1,8,7,2,0};
    quicksort(a,0,7);
    for (int  i = 0; i < 8; i++)
    {
        cout<<a[i]<<" ";
    }
    
    return 0;
}