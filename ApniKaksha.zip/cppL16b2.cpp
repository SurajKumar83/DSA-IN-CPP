// decreasing and increasing order using recursion
#include<iostream>
using namespace std;
void dec(int n)
{
    if (n==0)
    {
        return;
    }
    cout<<n<<endl;
    dec(n-1);   
}
void inc(int p)
{
    if (p==0)
    {
        return;
    }
     inc(p-1);
     cout <<p<<endl;   
}
int main(){
    int n;
    cin>>n;
   //dec(n);
   inc(n);
    return 0;
}