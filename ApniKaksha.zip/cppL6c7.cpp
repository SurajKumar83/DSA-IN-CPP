#include<bits/stdc++.h>
using namespace std;
int decimaltooctal(int n)
{
   int t=1;
   int sum=0;
   while (t<=n)
   {
      t*=8;
   }
   t/=8;
   while (t>0)
   {
      int lastdigit=n/t;
      n=n%t;
      t/=8;
      sum=sum*10+lastdigit;
   }
   return sum;
}
int main()
{
    int n;
    cin >> n;
    cout<< decimaltooctal(n)<<endl;
}