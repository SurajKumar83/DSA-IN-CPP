//Check prime or not
#include<iostream> 
#include<cmath>// used to include the definition of mathematical fun. like sqrt() used in this program.  
using namespace std;
int main()
{
    int n;
    cin>>n;
    bool flag=0;
    for (int  i = 2; i < sqrt(n); i++)//as the factors less then then the square rt will give the quatient greater then square rt i.e.,no need to check with quatient again.This wwill reduce the time oof excecution.
    {    
       if(n%i==0)
       {
           cout<<"The given number is a not a Prime Number."<<endl;
           flag=1;
           break;
       }
       }
    if(flag==0){
        
    cout<<"The given number is Prime Number" <<endl;
    }
    
    return 0;
}