// check if an array is sorted or not
#include<bits/stdc++.h>
using namespace std;
bool sortedarray (int arr[], int n)
{
    if (n==1)
    {
         return true;
    }
    
    bool check=sortedarray(arr+1,(n-1));// arr+1 points to 2nd element
    return (arr[1]>arr[0] && check);
   
   
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for (int i = 0; i <n; i++)
    {
        cin>>arr[i];
    }
    
    cout<<sortedarray(arr,n)<<endl;
    return 0;
}