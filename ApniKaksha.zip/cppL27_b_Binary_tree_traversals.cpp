#include<bits/stdc++.h>
using namespace std;

// Preorder Traversal
int main()
{
        
    return 0;
}