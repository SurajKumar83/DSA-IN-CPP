#include <bits/stdc++.h>
using namespace std;
vector<int> MergeSort(vector<int> &v1, vector<int> &v2)
{
    vector<int> v;
    int n1 = v1.size(), n2 = v2.size();
    int i = 0;
    int j = 0;
    while (i < n1 && j < n2)
    {
        if ((v1[i] < v2[j]))
        {

            v.push_back(v1[i]);
            i++;
        }
        else if (v1[i] == v2[j])
        {
            v.push_back(v1[i]);
            v.push_back(v2[j]);
            i++;
            j++;
        }
        else
        {

            v.push_back(v2[j]);
            j++;
        }
    }
    if (n1 > n2)
    {

        while (i < n1)
        {
            v.push_back(v1[i]);
            i++;
        }
    }
    else
    {

        while (j < n2)
        {
            v.push_back(v2[j]);
            j++;
        }
    }
    return v;
}
int main()
{

    vector<vector<int>> v = {{1, 2, 3, 4},
                             {5, 6, 7, 8},
                             {1, 3, 4, 5}};
    vector<int> v3;

    for (int i = 0; i < v.size(); i++)
    {
        v3 = MergeSort(v3, v[i]);
    }
    for (int i = 0; i < v3.size(); i++)
    {
        cout << v3[i] << " ";
    }
    cout << endl;

    int k;
    cin >> k;
    vector<vector<int>> a(k);
    for (int i = 0; i < k; i++)
    {
        int size;
        cin >> size;

        a[i] = vector<int>(size);
        for (int j = 0; j < size; j++)
        {
            cin >> a[i][j];
        }
    }
    vector<int> idx(k, 0);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    for (int i = 0; i < k; i++)
    {
        pq.push({a[i][0], i});
    }
    vector<int> ans;
    while(!pq.empty()){
        pair<int,int> x=pq.top();
        pq.pop();
        ans.push_back(x.first);

        if(idx[x.second]+1<a[x.second].size()){
            pair<int,int> p;
            p.first = a[x.second][idx[x.second]+1];
            p.second=x.second;
            pq.push(p);
        }idx[x.second]+=1;
    }
    for(int i=0;i<ans.size();i++){
        cout<<ans[i]<<" ";
    }cout<<endl;
    return 0;
}