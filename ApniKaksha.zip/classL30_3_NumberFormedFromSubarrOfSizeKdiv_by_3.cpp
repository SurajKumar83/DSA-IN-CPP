#include <bits/stdc++.h>
using namespace std;
int subarraysumdivby3(int a[], int n, int k)
{
    int sum = 0;
    int count = 0;
    for (int i = 0; i < k; i++)
    {
        sum += a[i];
    }
    for (int i = k; i <= n; i++)
    {

        if (sum % 3 == 0)
        {
            count++;
            sum = sum - a[i - k] + a[i];
        }
        else
        {
            sum = sum - a[i - k] + a[i];
        }
    }
    return count;
}
void computeNumbeFromSubarray(int a[], int n, int k)
{
    pair<int, int> ans;
    int sum = 0;
    for (int i = 0; i < k; i++)
    {
        sum += a[i];
    }
    bool found = false;
    if (sum % 3 == 0)
    {
        ans = make_pair(0, k - 1);
        found = true;
    }
    for (int i = k; i < n; i++)
    {
        if (found == true)
            break;
        sum = sum + a[i] - a[i - k];

        if (sum % 3 == 0)
        {
            ans = make_pair(i - k + 1, i);
            found = true;
        }
    }
    if (!found)
    {
        ans = make_pair(-1, 0);
    }
    if (ans.first == -1)
    {
        cout << "no such Subarray exists" << endl;
    }
    else
    {
        for (int i = ans.first; i <= ans.second; i++)
        {
            cout << a[i] << " ";
        }
        cout << endl;
    }
}
int main()
{
    int arr[] = {15, 21, 11, 4, 5, 6, 7};
    int n = 7;
    int k = 3;
    int count = subarraysumdivby3(arr, n, k);
    if (count)
    {
        cout << "count: " << count << endl;
    }
    else
    {
        cout << "Do not exit" << endl;
    }
    computeNumbeFromSubarray(arr, n, k);
}