//DNF sort or 1,2,3 sort
#include<bits/stdc++.h>
using namespace std;
void swap(int arr[],int mid, int low){
    int temp=arr[mid];
    arr[mid]=arr[low];
    arr[low]=temp;
}
void DNFSort(int arr[], int n){
    int high=n-1;
    int low=0;
    int mid=0;
    for (int i = 0; i < n; i++)
    {
        if (high>=mid && arr[mid]==0)
        {
            swap(arr[mid],arr[low]);
            low++;
            mid++;
        }
        else if (high>=mid && arr[mid]==2)
        {
             swap(arr[mid],arr[high]);
            
            high--;
        }
        else{
            mid++;
        }
    }
} 
int main()
{
    int arr[]={1,0,2,0,1,2,2,1,0};
    DNFSort(arr,9);
    for (int i = 0; i < 9; i++)
    {
      cout<<arr[i]<<" ";
    }cout<<endl;
    return 0;
}