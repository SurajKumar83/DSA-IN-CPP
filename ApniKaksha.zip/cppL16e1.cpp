// Given a "2*n" board and tiles of size "2*1" count the number of ways to tile the given board using these tiles;
#include<iostream>
using namespace std;
int tilingways(int n)
{
    if (n==0)
    {
        return 0;
    }
    if (n==1)
    {
        return 1;
    }
    return tilingways(n-1)/* for vertical*/+tilingways(n-2)/*for horrizontal*/ ; 
}
int main(){
    cout<<tilingways(4)<<endl;
    return 0;
}