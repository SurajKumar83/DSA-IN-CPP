#include<bits/stdc++.h>
using namespace std;
 class S_tack{
   int N;// for size of queue
   queue <int> q1;
   queue <int> q2;
    public:
    S_tack(){
        N=0;
    }
    // push
    void push(int val){
        q1.push(val);
        N++;//as we have pushed on element into our queue
    }
    // function to pop
    void pop()// this is costly as we know that there is N times  iteration 
    {
        // in case our queue is empty
        if (q1.empty())
        {
            return;
        }
        // if not then traverse till empty - 1 maens size !=1
        while (q1.size()!=1)
        {
            // till that time we push the front of q1 into the q2 and pop
            q2.push(q1.front());
            q1.pop(); 
        }
        // now we have only one element in our queue 
        q1.pop();
        N--;// as size of queue decreased by one
        
        // after poping out last element we swap our queue
        queue<int> temp = q1;
        q1=q2;
        q2=temp;

    }
    int top(){
        if (q1.empty())
        {
            return -1;
        }
        while (q1.size()!=1)
        {
            q2.push(q1.front());
            q1.pop();
        }
        // to return one value
        int ans=q1.front();
        // as we are not poping the elements so after storing to ans we push into q2
        q2.push(ans);
        // now we swap the value means store q2. to q1
        queue<int> temp=q1;
        q1=q2;
        q2=temp;  
        return ans;
    }
    int size(){
        return N;
    }

 };
 int main(){
     S_tack st;
     st.push(1);
     st.push(2);
     st.push(3);
     st.push(4);
     cout<<st.top()<<endl;
     st.pop();
      cout<<st.top()<<endl;
     st.pop();
      cout<<st.top()<<endl;
     st.pop();
      cout<<st.top()<<endl;
     st.pop();
     cout<<st.size()<<endl;
     return 0;
 }