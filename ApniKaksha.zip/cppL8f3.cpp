//... Maximum Circular Subarray Sum;
// case1 ={ -1,4,-6,7,5,-4} here maximum sum is 7+5 a contributing and nonwrap elements
// case2={ 4,-4,6,-6,10,-11,12} here -11 in noncontributing non wrapping 
//to get max subaray sum we use max subarray sum = total sum of array - sum of noncontributing elements
// here we use kadanes algorithm to get sum of noncontributing elements sum by reversing sign of elements before kadane;
#include<bits/stdc++.h>
using namespace std;
int kadane(int arr[],int n)
{
    int currsum=0;
    int maxsum=INT_MIN;
    for (int i = 0; i < n; i++)
    {
        currsum+=arr[i];
        if(currsum<0)
        {
            currsum=0;
        }
        maxsum=max(maxsum,currsum);
    }
    return maxsum;

}
int main()
{
      int n;
      cin>>n;
      int arr[n];
      for(int i=0;i<n;i++)
      {
          cin>>arr[i];
      }
      int wrapsum;
      int nonwrapsum;
      nonwrapsum=kadane(arr,n);
      int totalsum=0;
      for (int  i = 0; i < n; i++)
      {
          totalsum+=arr[i];
          arr[i]=-arr[i];
      }
      wrapsum=totalsum+kadane(arr,n);//arrr store the reverse value
cout<<max(wrapsum,nonwrapsum)<<endl;
return 0;
      
}