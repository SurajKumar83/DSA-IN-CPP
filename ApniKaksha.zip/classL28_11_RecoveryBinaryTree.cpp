#include <bits/stdc++.h>
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int value) : data(value), left(NULL), right(NULL) {}

};
/*
Case 1:{1,8,3,4,5,6,7,2}
first: previous node where 1st number<previous[8]
mid:number where 1st number<previous[3]
last:2nd node where number<previous[2]

here we simply swap the two pointer first and last

Case 2:{1,2,4,3,5,6,7,8}
first: previous node where 1st number<previous[4]
mid:number where 1st number<previous[3]
last: NULL

then swap the two pointer first with mid
*/
void inorder(node *root){
    if(root==NULL){return;}
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
void calcPointers(node *root, node **first, node **mid, node **last, node **prev)
{
    if (root == NULL)
    {
        return;
    }
    calcPointers(root->left, first, mid, last, prev);
    if (*prev && root->data < (*prev)->data)// is the prev exits and the root data is less than the previous data if yes means there is need of recovery
    {
        if (!*first)// in case of first time voilation 
        {
            *first = *prev; 
            *mid = root;
        }
        else// in case of second time voilation 
        {
            *last = root;
        }
    }
    *prev = root;// means now root become previous 
    calcPointers(root->right, first, mid, last, prev);
}
void restoreBST(node *root)
{
    node *first, *mid, *last, *prev;
    first = NULL;
    mid = NULL;
    last = NULL;
    prev = NULL;

    calcPointers(root, &first, &mid, &last, &prev);
    // case 1
    if (first && last)
    {
        swap(&(first->data), &(last->data));
    }  
    // case 2 means elements are adjacent to each other
    else if (first && mid)
    {
        swap(&(first->data), &(mid->data));
    }
}
int main()
{
    node *root = new node(6);
    root->left = new node(9);
    root->right = new node(3);
    root->left->left =new node(1);
    root->left->right = new node(4);
    root->right->right = new node(13);
    inorder(root);cout<<endl;
    restoreBST(root);
    inorder(root);
    return 0;
}