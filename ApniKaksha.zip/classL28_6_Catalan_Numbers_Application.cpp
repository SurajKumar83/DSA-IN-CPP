// Catalan Numbers: Interview based
#include <bits/stdc++.h>
#include <vector>
using namespace std;
#define ll long long int
ll catalan(int n)
{
    if (n <= 1)
    {
        return 1;
    }
    ll res = 0;
    for (int i = 0; i < n; i++)
    {
        res += catalan(i) * catalan(n - i - 1);
    }
    return res;
}
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val) : data(val), left(NULL), right(NULL) {}
};
// Function
vector<Node *> constructTrees(int start, int end) // start means 1 the starting value and end will be the end
{
    vector<Node *> Trees; // to store different BST;
    if (start > end)
    {
        Trees.push_back(NULL);
        return Trees;
    }

    for (int i = start; i <= end; i++)
    {
        vector<Node *> leftsubtrees = constructTrees(start, i - 1); // left subtrees should be less than the ith node
        vector<Node *> rightsubtrees = constructTrees(i + 1, end);  // rights subtrees should be greater than the ith node

        // this for loop, we are using to for combining all possible leftsubtree with all possible rightsubtree and forming a larger BST  
        for (int j = 0; j < leftsubtrees.size(); j++)
        {
            Node *left = leftsubtrees[j]; // subtree at jth position
            for (int k = 0; k < rightsubtrees.size(); k++)
            {
                Node *right = rightsubtrees[k];
                Node *node = new Node(i);// AS we have formed our left subtree and right subtree so now construct our ith key as node
                node->left = left;// now we attach the left subtree to the left of the node  
                node->right = right;// now we attach the subtree right to the right of the node
                Trees.push_back(node);
            }
        }
    }
    return Trees;
}
void preorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}
int main()
{
    for (int i = 0; i < 10; i++)
    {
        cout << catalan(i) << " " << endl;
    }
    cout << endl;
    vector<Node *> totalTrees = constructTrees(1, 3);
    for (int i = 0; i < totalTrees.size(); i++)
    {
        cout << (i + 1) << " : ";
        preorder(totalTrees[i]);
        cout << endl;
    }
    return 0;
}