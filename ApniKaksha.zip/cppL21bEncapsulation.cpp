// Encapsulation 
// hiding "sensitive" data from the user.like car driving in which driver noot need to know about working of engine means encapsulated
#include<bits/stdc++.h>
using namespace std;
class A{
    public:
    int a;
    void funcA(){
        cout<<" Func A \n";

    }
    protected:
    int b;
    void funcB(){
         cout<<"Func B\n";
    }
     
     private:
     int c;
     void funcC(){
         cout<<" Func C\n";
     }
};
int main()
{
    A obj;
    obj.funcA();
    obj.funcB();
    obj.funcC();
    return 0;
}