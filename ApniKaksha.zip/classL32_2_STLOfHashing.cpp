#include<bits/stdc++.h>
#include<map>
using namespace std;
int main(){
    map<int,int> m;
    m[8]=2;
    cout<<m[8]<<endl;
    return 0;
}