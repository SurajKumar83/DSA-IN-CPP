//WAP  to check the pythagorian triplet
#include<iostream>
//#include<math.h>
using namespace std;
bool pytha(int a,int b,int c){
    int d=max(a,max(b,c));
    if(((d==a) & (d*d==b*b+c*c)) || ((d==b) & (d*d==a*a+c*c) )|| ((d==c) & (d*d==b*b+a*a)))
    {
       return true;
    }
    else{
       return false;
    }
    
}
int main()
{
    int a,b,c;
    cin>>a>>b>>c;
   if (pytha(a,b,c))
   {
       cout << "Pythagorian Triplet "<<endl;

   }
   else{
       cout<< "Not Pythagorian Triplet "<<endl;
   }
   
    return 0;
}