#include <iostream>
using namespace std;
int main(){
     char button;
     cout<<"Input a character:"<<endl;
     cin>>button;
     switch (button )
     {
     case 'a':
         cout<<"hello"<<endl;
         break;
     case 'b':
         cout<<"Namaste"<<endl;
         break;
     case 'c':
         cout<<"Hola"<<endl;
         break;
     case 'd':
         cout<<"Ciao"<<endl;
         break;
     case 'e':
         cout<<"Salute"<<endl;
         break;
     default:
     cout<<"I am learning  more "<<endl;

         break;
     }





    return 0;
}//In this we use break to terminate the switch after execution of any case otherwise all the coming cases will execute;