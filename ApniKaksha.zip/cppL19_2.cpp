// we have to reduce the given array
// idea is to use pair so that we can keep sorted array and their index sticky
#include<bits/stdc++.h>
#include<vector>
using namespace std;
bool myCompare(pair<int ,int> p1,pair<int ,int> p2){
    return p1.first<p2.first;//first denotes the element of array
}
int main()
{
    int arr[]={10,16,7,14,5,3,2,9};
    vector<pair<int,int>> v;// to declare pair 
    // to store this arr as pairs
    for (int  i = 0; i <(sizeof(arr)/sizeof(arr[0])); i++)
    {
       // (pair<int ,int > p;p.first=arr[i];p.second=i;)
        //or 
        v.push_back(make_pair(arr[i],i));
    }
    sort(v.begin(), v.end(), myCompare);//myCompare will help to decide how we are sorting our pairs
    for (int i = 0; i < v.size(); i++)
    {
        arr[v[i].second]=i;// this second means index
    }
     for (int i = 0; i < v.size(); i++)
    {
        cout<<arr[i]<<" ";
    }cout<<endl;
    return 0 ;
}