//...write a program to count the number of ones in binary representation of a number
#include<iostream>
using namespace std;
int num_of_ones(int n)
{
    int count =0;
    while (n)
    {
        n=n&(n-1);// as n&(n-1) has same bits as n except the rightmost set bit;
        count++;
    }
    return count;
    
}
int main()
{
    cout<<" '"<<num_of_ones(11)<<"' "<<endl;
    return 0;
}