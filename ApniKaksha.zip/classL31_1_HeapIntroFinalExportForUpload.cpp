/*
Heaps : 1.Binary Tree based dat structure
   2. Not necessarily BST

Types of Heaps : 1.maxHeap(Root>rest of the elements present in its subtree)
                      6                      
                    /  \                      
                   5    4                    
                 /  \                         
                1   2                         
                2.Min Heap: Root<rest of the elements present in its subtree)
                1                          
              /  \                            
             3    2                 
           /   \                    
          9    8                    
                                  
                                  
Using Heapification Method we can make these heaps   
Popping Elements: Delete the root element and then Place last element and 
     apply Heapify down till max heap                          
*/