#include<bits/stdc++.h>
using namespace std;

int bruteforce(int a[],int n){

   vector<pair<int,int> >v;
    int ans=0;
    for(int i=0;i<n; i++){
        int  sum=0;
        for(int j=i;j<n; j++){
          sum+=a[j];
          if(sum==0){
            v.push_back(make_pair(i,j));
               ans++;
        }
        }
        
    }
    for(int i=0;i<v.size(); i++){
        cout<<v[i].first<<" "<<v[i].second<<endl;
    }
    return ans;
}

void optimized(int a[],int n,map<int,int> &m){
   int presum=0;
   for(int i=0;i<n;i++){
    presum+=a[i];
    m[presum]++;
   }
    
    
}
int  main(){
    int  n;
    cin>>n;
    int a[n];
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    // cout<<bruteforce(a,n)<<endl;
    map<int,int> cnt;
   optimized(a,n,cnt);
   int ans=0;
   map<int,int>::  iterator it;
   for(it=cnt.begin();it!=cnt.end();it++) {
    cout<<it->first<<" "<<it->second<<endl;
    int  c=it->second;
    ans+=(c+(c-1))/2;
    if(it->first==0){
        ans+=it->second;
    }
   }
   cout<<ans<<endl;
    return 0;
}