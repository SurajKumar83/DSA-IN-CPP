// Circular Linked List
#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int data;
    node* next;
    node(int val){
        data=val;
        next=NULL;
    }
};
// Insert at head
void insertAtHead(node* &head,int val){
    node* n=new node(val);
    if (head==NULL)
    {
        n->next=n;
        head=n;
        return;
    }
    
    node* temp=head;
    while (temp->next!=head)
    {
        temp=temp->next;
    }
    temp->next=n;// node which is connected with head
    n->next=head;//after connecting temp->next to n we link n->next to head
    head=n;// finally we name head to n;
    
}
// insert at tail
void insertAtTail(node* &head,int val){
   if (head==NULL)
   {
       insertAtHead(head,val);
       return;
   }
   
    node* n=new node(val);

       
    node* temp=head;// traverse
    while (temp->next!=head)
    {
        temp=temp->next;
    }
    temp->next=n;
    n->next=head;
    
}
// to display
void display(node* head){
    node* temp=head;
    // while(temp!=head)
    //  we can not do this as initial value of temp is head; in case temp->next!=head then we cannot print last node value as temp ->next points to head then without going to last node it comes out of loop
    do
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    } while (temp!=head);
    cout<<endl;
    
 }
 // TO DELETE 1ST NODE OR HEAD NODE
 void deletehead(node* &head){
     
     node* temp=head;
     while (temp->next!=head)
     {
         temp=temp->next;
     }
     node* todelete=head;//to store which value we want to delete other wise it will lost 
     temp->next=head->next;
     head=head->next;
     delete todelete;
     
 }
 // to delete at any position
 void deletion(node* &head,int pos)
 {
     if (pos==1)
     {
         deletehead(head);
         return;
     }
     
     node* temp=head;
     int count=1;// to count position at which we have to reach
     while (count!=pos-1)
     {
         temp=temp->next;
         count++;
     }
     node* todelete=temp->next;//here temp is node at pos-1   position
     temp->next=temp->next->next;
     delete todelete;
     

 }
int main(){
    node* head=NULL;
    for (int i = 1; i <5; i++)
    {
        insertAtTail(head,i);
    }
    display(head);
    insertAtHead(head,5);
     display(head);
     deletehead(head);
     display(head);
     deletion(head,4);
     display(head);
    return 0;

}