#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
   string str="ftfjhjhgughaaa";
   // convert into uper case
   for (int i = 0; i < str.size(); i++)
   {
       if (str[i]>='a' && str[i]<='z')
       {
           str[i]-=32;
       }
       
   }
   cout<<str<<endl;
   //convert into lower case
   for (int  i = 0; i < str.size(); i++)
   {
      if(str[i]>='A' && str[i]<= 'Z')
      str[i]+=32;
   }
   cout<<str<<endl;
   //using transform fun we can convert into upper or lower case
   string str1="sjfifflfjskrnwjkhhis";
   transform(str1.begin(), str1.end(), str1.begin(),::toupper);
   cout<<str1<<endl;
   transform(str1.begin(),str1.end(),str1.begin(),::tolower);
   cout<<str1<<endl;
    return 0;
    // Form The Biggest Number From The Number String 
    string s="8957588558789587598570"
    for (int i = 0; i < s.size(); i++)
    {
        string s1="0";
        if (s[i]>='0')
        {
            s1=s[i];
        }
        
        
        
    }
    co
    return 0;
}