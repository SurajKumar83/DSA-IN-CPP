// write a program to check if a given number is power of 2 .
// 1st approach to divide by 2 and if remainder 0 means yes
// 2nd approach bit manupilation 
#include<iostream>
using namespace std;
bool ispowerof2(int n)
{
    return (n && !( n & n-1 ));
}
int main()
{
    cout<<ispowerof2(0)<<endl;
    return 0;
}