// #include<bits/stdc++.h>
// using namespace std;

// class Que 
// {
//    int* array;
//    int size;// Size of the queue
//    int rear;// not fixed as it will change but not the front(which remaing -1)
//    public:
//    Que(){}
//    Que(int n)
//    {
//        size = n;
//        array=new int[n];
//        rear=-1;// as its intial value will be -1 for empty array representation
//    }
//    // To insert the value we need to insert
//    void enqueue(int data)
//    {
//        if(rear==size-1)// means at the end of the array
//        {  
//            cout<<"OVERFLOW"<<endl;
//            return;
//         }
//          // means we can insert
//          rear++;// increment 
//          array[rear]=data; 
//    }
//    int dequeue(){// time complexity of big O(n);
//        if (rear==-1)
//        {
//            cout<<"Empty"<<endl;
          
//        }
//        int result=array[0];// as this will be removed 
//        for (int i=0;i<rear;i++)
//        {
//            array[i]=array[i+1];// we place the array[i+1] element to the ithe position

//        }
//        rear--;// to show the position of last element in array without removing last one;
//        return result;
     
//    }
//    int getFront(){
//        if (rear==-1)
//        {
//            return -1;
//        }
//        return array[0];
//     }
    
// };
// class CircularQueueArray{
//    int* a;
//    int N;
//    int front=-1;
//    int rear=-1;
//    public:
//    CircularQueueArray(){}
//    CircularQueueArray(int n)
//    {
//     N=n;
//     a=new int[n];
//    }
//    // to insert data
//    void enqueue(int data)
//    {
//       if((rear+1)%N==front)// rear+1)%N==front means next position of rear 
//        {
//            return;// Full queue
//        }
//        if(front==-1)// means empty queue
//        {
//            front=0;
//            rear=(rear+1)%N;
//            a[rear]=data;
//        }
//    }
//   int dequeue()
//   {
//       if (front==-1)// means empty queue
//       {
//           cout<<"Empty queue"<<endl;
//           return -1;
//       }
//       int result=a[front];
//       if(front==rear)// means only one element in queue
//       {
//           front=rear=-1;
//       }
//       else
//       {
//           front=(front+1)%N;
//       }
//       return result; 
//   }

   
// };
// int  main(){
//     Que c;
//     // int data;
//     // cout<<"Enter the data:"<<endl;
//     // cin>>data;
//     c.enqueue(1);
//     c.enqueue(2);
//     c.enqueue(3);
//     c.enqueue(4);
//     c.enqueue(5);
//     cout<<c.dequeue()<<endl;
//      cout<<c.dequeue()<<endl;
//       cout<<c.dequeue()<<endl;
//        cout<<c.dequeue()<<endl;
//         cout<<c.dequeue()<<endl;
//     return 0;
// }

#include<bits/stdc++.h>
using namespace std;

class CQueue
{
        public:
        int *array,Size;
        int front,rear;

        CQueue(int size)
        {
          Size=size;
          array= new int[size];
          front = rear = -1;
        }
         
         int isFull()
         {
             if((front==rear+1)||(front == 0 && rear== Size-1))
                 return 1;
             return 0;
         }
         int isEmpty()
         {
             if (front == -1) return 1;
             return 0;
         }
         
         void enqueue(int value)
         {
             cout<<"Pushing the value :"<<value<<endl<<endl;
             if (isFull())
                 cout<<"Can not push "<<value<<", The Circular Queue is Full."<<endl<<endl;
             else
             {
                 if (front==-1 ) front = 0;
                 rear = (rear + 1) % Size;
                 array[rear] = value;
           }
         }
         
         int dequeue()
         {
           int element;
           if (isEmpty())
            {
             cout<<"The Circular Queue is empty."<<endl<<endl;
             return -1;
            }
             element = array[front];
             if (front ==rear) {
               front = -1;
               rear = -1;
             }
         
             else {
               front = (front + 1) % Size;
             }
             cout<<"Popping out the value : "<<element<<endl<<endl;
             return element;
           
         }
         
         void Show()
         {
             int i;
             if (isEmpty()) cout<<"The Circular Queue is empty."<<endl<<endl;
             else
             {
                 cout<<"The Circular Queue is :"<<endl<<endl;
                 for (i=front; i!=rear;i= (i+1)%Size)
                     cout<<array[i]<<" ";
             cout<<array[i]<<endl;
           }
         }
};

int main() {

  CQueue CQ(6);
  CQ.enqueue(2);
  CQ.enqueue(7);
  CQ.enqueue(3);
  CQ.enqueue(9);
  CQ.Show();
  CQ.enqueue(8);
  CQ.enqueue(4);
  CQ.enqueue(1);
  CQ.dequeue();
  
  CQ.enqueue(10);
  CQ.dequeue();
  CQ.Show();

  return 0;
}