// Matrix Exponentiation
/*
Given a square matrix A we will calculate A^n.
This method work if matrix is square matrix

Matrix Exponentiation=>(Matrix Multiplication + Binery Exponentiation)

Fibonacci Series in the form of matrix multiplication
f(n)     a b      f(n-1)
               x
f(n-1)   c d      f(n-2)

on solving we get a=1,b=1,c=1,d=0
on expansion
f(n)     a b  |^(n-2)     f(2)
              |       x
f(n-1)   c d  |           f(1)

*/
#include <bits/stdc++.h>
using namespace std;
int mod = 1e9 + 7;
vector<vector<int>> multiply(vector<vector<int>> a, vector<vector<int>> b)
{
    vector<vector<int>> ans(2, vector<int>(2, 0));
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 2; k++)
            {
                ans[i][j]+= (a[i][k] * b[k][j]) % mod;
            }
        }
    }
    return ans;
}
// for Power or binery Exponentiation time would be (logN)
// since we are dividing again and again
vector<vector<int>> power(vector<vector<int>> &a, int n)
{

    if (n == 0)
    {
        int sz = a.size();
        vector<vector<int>> ans(sz, vector<int>(sz, 0));
        for (int i = 0; i < sz; i++)
        {
            ans[i][i] = 1;
        }
        return ans;
    }
    if (n == 1)
    {
        return a;
    }
    vector<vector<int>> temp = power(a, n / 2);
    vector<vector<int>> ans = multiply(temp, temp);
    if (n & 1) // check for n is even
    {
        ans = multiply(ans, a);
    }
    return ans;
}
int main()
{
    int n;
    cin >> n;
    vector<vector<int>> a = {{1, 1}, {1, 0}};
    vector<vector<int>> ans = power(a, n);
    for (int i = 0; i < ans.size(); i++)
    {
        for (int j = 0; j < ans.size(); j++)
        {
            cout << ans[i][j] << " ";
        }
        cout << endl;
    }

    cout << ans[0][0] << endl;
}
