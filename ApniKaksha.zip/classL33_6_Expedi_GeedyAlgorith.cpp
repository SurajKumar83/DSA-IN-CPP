#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        vector<pair<int, int>> a(n);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i].first >> a[i].second;
        }
        int l, p;
        cin >> l >> p;
        // we make the distance from the town to the distance from the truck
        for (int i = 0; i < n; i++)
        {
            a[i].first = l - a[i].first;
        }
        sort(a.begin(), a.end());
        int ans = 0;
        int currfuel = p;
        bool flag = 0;
        priority_queue<int, vector<int>> pq;
        for (int i = 0; i < n; i++)
        {
            if (currfuel >= l)// current fuel is grater than equals to distane between truck and town;
            {
                break;
            }
            while (currfuel < a[i].first)
            {
                if (pq.empty())// fuel is not  available
                {
                    flag = 1;
                    break;
                }
                ans++;
                currfuel += pq.top();
                pq.pop();
            }
            if (flag)// if fuel is not available then break; current loop
            {
                break;
            }
            pq.push(a[i].second);
        }
        if (flag)
        {
            cout << "-1" << endl;
            continue;
        } // we have reached the last stop but not the town
        while (!pq.empty() && currfuel < l)
        {
            currfuel += pq.top();
            pq.pop();
            ans++;
        }
        if (currfuel < l)
        {
            cout << "-1" << endl;
            continue;
        }
        cout << ans << endl;
    }
}