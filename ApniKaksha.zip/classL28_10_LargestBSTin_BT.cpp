/*
Largest BST in a BT:
   Strategy:
   For each node the following information:
   1. min in subtree
   2. max in subtree
   3. subtree size
   4. size of largest BST
   5. isBST

Recursively : traverse in the bottom up
     manner & find out the size of largest BST
*/
#include "bits/stdc++.h"
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int data) : data(data), left(NULL), right(NULL) {}
};
class info // for different types of info
{
public:
    int size;
    int max;
    int min;
    int ans;
    bool isBST;
};
info largestBSTinBT(node *root) // function to give info
{
    if (root == NULL) // means no BT exist
    {
        return {0, INT_MIN, INT_MAX, 0, true}; // here we are typecasting the list difined in info class;
        // as there is no root so size 0,min INT_MIN,max= INT_MAX,ans 0 and isBST true
    }
    if ((root->left == NULL) && (root->right == NULL)) // in case of leaf node
    {
        return {1, root->data, root->data, 1, true}; // size of 1 ,min value= root->data,max value= root->data as single leaf node is always a BST
    }
    info leftInfo = largestBSTinBT(root->left);   // check for  leftInfo
    info rightInfo = largestBSTinBT(root->right); // check for rightInfo
    info curr;                                    // current level size
    curr.size = (1 + leftInfo.size + rightInfo.size);
    if (leftInfo.isBST && rightInfo.isBST && leftInfo.max < root->data && rightInfo.max > root->data)
    {
        curr.min = min(leftInfo.min, min(rightInfo.min, root->data));
        curr.max = max(leftInfo.max, max(rightInfo.max, root->data));
        curr.ans = curr.size;
        curr.isBST = true;
        return curr;
    }
    // in case no BST form
    curr.ans = max(leftInfo.ans, rightInfo.ans);
    curr.isBST = false;
    return curr;
}
int main()
{
    node *root = new node(5);
    root->left = new node(3);
    root->right = new node(6);
    root->left->left = new node(2);
    root->left->right = new node(4);
    cout << "Largest BST in BT :" << largestBSTinBT(root).ans << endl;
}