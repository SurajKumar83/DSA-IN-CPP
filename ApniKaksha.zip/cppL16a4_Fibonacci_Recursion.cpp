#include<bits/stdc++.h>
using namespace std;
int Print_Fibo(int n)
{
   if (n==0 || n==1)
   {
       return n;
   }
    return Print_Fibo(n-1)+Print_Fibo(n-2);
}
int main()
{
    int n;
    cin>>n;
    cout<<Print_Fibo(n)<<endl;
    return 0;
}