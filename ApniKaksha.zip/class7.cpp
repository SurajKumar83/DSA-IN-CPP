#include <iostream>
using namespace std;
//int inc(int i);
//int dec(int d);
int power (int a, int b)
{
   if(b==0)
   return 1;
   else
   return a*power(b-1 );
   cout<<
}
int main()
{


   return 0;
}