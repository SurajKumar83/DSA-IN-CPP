#include<bits/stdc++.h>
#include<stack>
using namespace std;

void insertAtbottom(stack<int> &st,int ele){
    if (st.empty())
    {
        st.push(ele);
        return;

    }
    int topEle=st.top();
    st.pop();
    insertAtbottom(st,ele);
    st.push(topEle);// at last we add our topelement
    
}
void reversestack(stack<int> &st){
    if (st.empty())
    {
        return;
    }
    int ele=st.top();
    st.pop();
    reversestack(st);
    insertAtbottom(st,ele);

}
int main(){
  stack<int> st;
  st.push(1);
  st.push(2);
  st.push(3);
  st.push(4);
//    while (!st.empty())
//   {
//       cout<<st.top()<<" ";
//       st.pop();
//   }cout<<endl;
  reversestack(st);
  while (!st.empty())
  {
      cout<<st.top()<<" ";
      st.pop();
  }cout<<endl;
  
    return 0;
}