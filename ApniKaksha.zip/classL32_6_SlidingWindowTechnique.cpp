#include<bits/stdc++.h>
using namespace std;
int bruteforce(int a[],int n,int k){
   
   int ans=INT_MAX;
   for(int i=0;i<n-k+1;i++){
    int sum=0;
     for(int j=i;j<i+k;j++){
        sum+=a[j]; 
     }
     ans=min(ans,sum);
      cout<<sum<<" "<<ans<<endl;
     
   } 
   return ans;
}
int optimized1(int a[],int n,int k){
    int sum=0;
    int ans=INT_MAX;
    for(int i=0;i<k;i++){
            sum+=a[i];
    }
    ans=sum;
    for(int i=k;i<n;i++){
        sum=sum+a[i] - a[i - k];
        cout<<ans<<endl;
        ans=min(ans,sum);
    }
    return ans;
}
int main(){
   int n,k;cin>>n>>k;
   int a[n];for(int i=0;i<n;i++){
    cin>>a[i];
   }
   
   cout<<"Brute force approach: " <<bruteforce(a,n,k)<<endl;
    cout<<"Optimized Approach1: "<<optimized1(a,n,k)<<endl;
    return 0;
}