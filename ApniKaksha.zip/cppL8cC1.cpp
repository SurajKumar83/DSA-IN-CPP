#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for (int  i = 0; i <n ; i++)
    {
        cin>>arr[i];
    }
    for (int i = 1; i < n; i++)//i=1 so that we can start from 2nd element
    {
        int current = arr[i];
        int j=i-1;
        //now we compare the current number with its previous ones using while loop
         while (arr[j]>current && j>=0)//j>=0 mean till j should not be less than 0;
         {
             arr[j+1]=arr[j];//to move by one position;
             j--; //to go to previous element;
         }
         // .. after inserting all number we assigning the arr[j+1] number the current 
         arr[j+1]=current;
    }
    for (int i = 0; i < n; i++)
    {
        cout<<arr[i]<<" ";
    }
    
    return 0;
}