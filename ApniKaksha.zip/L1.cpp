#include<iostream>
using namespace std;
int main()
{
  /*#ifndef ONLINE_JUDGE
    freopen("inpput.txt","r",stdin );
    freopen("output.txt","w",stdout);
    #endif*/
    int a,b;
    cout<<"Enter the numbers";
    cin>>a>>b;
    cout<<a+b<< "\n";
    return 0;
}
 

 
