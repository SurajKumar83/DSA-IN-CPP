//... Matrix Search
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m,n;
    cin>>m>>n;
    int target;
    cin>>target;
    int A[m][n];
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin>>A[i][j];
        }
        cout<<endl;
    }
    int r=0,c=n-1;
    bool flag=false;
    while (r<m && c>=0)
    {
        if (A[r][c]== target)
        {
           flag = true;
        }
        else if (A[r][c]>target)
        {
            c--;
        }
        else
        {
            r++;
        }   
    }
    if (flag)
    {
        cout<<"Element found";
    }
    else
    {
        cout<<" doesn't exist";
    }
    return 0; 
}