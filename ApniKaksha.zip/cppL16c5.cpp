//move all x to the end of the string 
#include<iostream>
using namespace std;
string mmovetoend(string s)
{
    if (s.length()==0)
    {
      return "";
    }
    char ch=s[0];
    string ans =mmovetoend(s.substr(1));
    if (ch=='x')
    {
       return (ans + ch);
    }
    else
    {
        return (ch + ans);
    }
}
int main(){
    cout<<mmovetoend("fkjmnvnxxmnvbxmbxvmbvmvb")<<endl;
    return 0;
}