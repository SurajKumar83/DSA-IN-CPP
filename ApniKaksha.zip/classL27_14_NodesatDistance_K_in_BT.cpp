
#include "bits/stdc++.h"
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val)
    {
        data = val;
        left = NULL;
        right = NULL;
    }
};
// case 1;
void subtreeNode(Node *root, int k)
{
    if (root == NULL || k < 0) // means no possible ans for this situation
        return;
    if (k == 0) // we have already reached to final node
    {
        cout << root->data << " ";
        return;
    }
    // if k>0 then we move to left or right node
    subtreeNode(root->left, k - 1); // k-1 as we have moved one node that is current node
    subtreeNode(root->right, k - 1);
}
// case 2;
// we have used int return type for the printNodeatk fun
// as whenever we able to find the target node then we
// return the distance from target to the ancestor node
// as we need a value d after using this value we convert case 2 to case 1
int printNodeatk(Node *root, Node *target, int k)
{
    if (root == NULL)
        return -1;
    if (root == target)
    {
        subtreeNode(root, k); // means current root is the target so distance is zero
        return 0;
    }
    // otherwise we move to the left of the current root
    int dl = printNodeatk(root->left, target, k); // distance in left part
    if (dl != -1)                                 // if dl =-1 means we don't got our target in left part
    {                                             // if dl !=-1 means we got our target in   left part
        if (dl + 1 == k)// this means target node is at kth distance from current node
        {
            cout << root->data << " ";
        }
        else
        {
            subtreeNode(root->right, k - dl - 2);// as we call directly root->right so -1 and second -1 because of the distace from root left sub child to root then added one
        }
        return 1 + dl;
    }
    int dr = printNodeatk(root->right, target, k);
    if (dr != -1)
    {
        if (dr + 1 == k)
        {
            cout << root->data << " ";
        }
        else
        {
            subtreeNode(root->left, k - dr - 2);
        }
        return 1 + dr;
    }
    return -1;// when we couldn't find the target node
}

int main()
{
    /*
             1
           /  \
          2    3
        /
       4

    */
    Node *root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);

    printNodeatk(root, root->left, 1);
    return 0;
}