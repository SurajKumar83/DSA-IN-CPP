//... Pointer Arithmetics;
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b;
    cin>>a>>b;
    int *aptr,*bptr;
    aptr=&a;
    bptr=&b;
    cout<<a<<endl;
    cout<<b<<endl;
    cout<<aptr<<endl;
    cout<<bptr<<endl;
    cout<<*aptr<<endl;
    cout<<*bptr<<endl;
    cout<<aptr+10<<endl;
    cout<<bptr+10<<endl;
    cout<<*aptr+*bptr<<endl;
    cout<<*aptr/(*bptr)<<endl;
    cout<<*aptr*(*bptr)<<endl;
    cout<<(*bptr-*aptr)<<endl;
    cout<<(*aptr>*bptr)<<endl;
    cout<<(*aptr)++<<endl;
    cout<<aptr++<<endl;
    cout<<bptr++<<endl;
    cout<<aptr-bptr<<endl;
    return 0;
}