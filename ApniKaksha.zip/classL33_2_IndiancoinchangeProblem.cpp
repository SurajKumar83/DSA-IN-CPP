/* Problem:-
 You are given an array of Denominations adn a value X.You
 need to find the minimum number of coins required to make
 value X.
 NOTE: We have infinite supply of each coin.
*/
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n, m;
    cin >> n >> m;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    sort(a, a+n, greater<int>());
    int ans = 0;
   
    for (int i = 0; i <n; i++)
    {
        if(m>0){
            ans += (m / a[i]);
            m=m-(m/a[i])*a[i];
           
        }
    }
     cout<<ans<<endl;
   
}