// polymorphism
#include<bits/stdc++.h>
using namespace std;

// Function overloading 
// class A_C
// {
//     public:
//     void fun()
//     {
//         cout<<" I am a fun with no aruguments"<<endl;
//     }
//     void fun(int x)
//     {
//         cout<<" I am a fun with int = " <<x<<" arugument"<<endl;
//     }
//     void fun(double x)
//     {
//         cout<<" I am a fun with double = " <<x<<" arugument"<<endl;
//     }
// };

// operator overloading
// class complex
// {
//     private:
//     int real,imag;
//     public:
//      complex(int r=0,int i=0)// constructor
//      {
//          real =r;
//          imag=i;
//      }
// code for overloading
//       complex operator + (complex const &obj/*by refrence object*/){
//           complex result;//to store result
//           result.imag =imag/*current*/ + obj.imag/*from obj*/;
//           result.real=real +obj.real;
//           return result;
//       }
//       void display(){
//           cout<<real<<"+i" << imag<<endl;
//       }
// };

// Virtual Function 
class base 
{
    public:
    virtual void print(){ // by doing this now dynamically bind happens means as we give address at runtime then after that it takes the address and then executed their fun 
        cout<<"This is the base class's print fun"<<endl;
    }
    void display(){
        cout<<"This is the base class's display fun"<<endl;
    }
};
class derived :public base
{
    public:
    void print(){
        cout<<"This is the derived class's print fun"<<endl;
    }
    void display(){
        cout<<"This is the derived class's display fun"<<endl;
    }
};

int main(){

//   A_C obj;
//  obj.fun();;
//  obj.fun(5);
//  obj.fun(3.554);

//   complex c1(12,7);
//   complex c2(6,7);
//   complex c3 = c1+c2;
//   c3.display();

base *baseptr;// base class pointer
derived d;
baseptr =&d;
baseptr -> print();// -> used as baseptr is pointer not obj so cannot use (.) 
baseptr -> display();// both will print basse class fun but have assigned address of d in baseptr to change it use virtual kayword before void in base class
    return 0;
}