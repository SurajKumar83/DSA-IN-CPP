#include <iostream>
using namespace std;
int main()
{
    char op;
    cout << "Input an operator";
    cin >> op;
    switch (op)
    {
    case '+':
        cout << "n1+n2" << endl;
        break;
    case '-':
        cout << "n1-n2" << endl;
        break;
    case '*':
        cout << "n1*n2" << endl;
        break;
    case '/':
        cout << "n1/n2" << endl;
        break;
    default:
        cout << "All done " << endl;
        break;
    }
    return 0;
}