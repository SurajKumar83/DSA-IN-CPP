#include<bits/stdc++.h>
using namespace std;
class student{
  string name;
  public:
  int age;
  bool gen;
  student(){
    cout<<" Default Constructor "<<endl;
 }
  student(string p,int a,int g)
  {
    cout<<" Parametarised Constructor "<<endl;
    name =p;
    age = a;
    gen = g;
  //constructor with parameters 
  }
  student(student &a){
    cout<<" Copy Constructor "<<endl;
    name=a.name;
    age= a.age;
    gen=a.gen ;

  }
  // destructor called after end of main 
  // no input ,no return 
  // it's number of call depends upon how many obj we have created
  ~ student(){
    cout<<"Destructor called"<<endl;
  }
 void setname(string p){
     
    name=p;
     
 }
  
  // void getName(){//to access the name attribute out side the class
  //     cout<<name<<endl; 
  // }

  void printInfo(){
      cout<<"Name = ";
      cout<<name<<endl;
      cout<<"Age = ";
      cout<<age<<endl;
      cout<<"Gender = ";
      cout<<gen<<endl;
  }
  // It need to specify our expectation from == operator  we call it operator overloading as we want to some special which it normally don't do
  bool operator == (student &a){
    if(name==a.name && age==a.age && gen==a.gen)
    return 1;
    return 0;
  }


};
int main()
{   
      
//    // to take multiple instance 
//     student arr[2];
//     for (int  i = 0; i < 2; i++)
//     {
//         string p;
//         cout<<"Name = ";
//         cin>>p;
//         arr[i].setname(p);
//         cout<<"Age = ";
//         cin>>arr[i].age;
//         cout<<"Gender = ";
//         cin>>arr[i].gen;
//     }
//     for (int i = 0; i < 2; i++)
//     {
//         arr[i].printInfo();
//     }
//     for (int i = 0; i < 2; i++)
//     {
//         arr[i].getName();
//     }

// to specify  the value what we need at the time of specifing use concept of CONSTRUCTOR
   student a("Ram", 30, 1);
    //    a.printInfo();
   student b("Sita",28,0);
   student c=a;

   // operator overloading : we can use it to compare two obj whether same or not
   if (b==c)
   {
     cout<<"Same"<<endl;
   }
   else{
     cout<<"Not Same"<<endl;
   }
 return 0;
    
}