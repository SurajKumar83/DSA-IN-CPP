// Problem statement 
// Given a string s , find the length of the longest substring without repeating characters.
// Sample Test Case 
// input: s="abcbcbb"
// Ouput: 3
// Explanation : THE ANSWER IS "abc", WITH THE LENGTH OF 3; 

/*
idea:
while iterating mark the  position of each character 
At i'th character, check the precious occurrence and decide the start of the substring accordingly*/

#include<bits/stdc++.h>
using namespace std;

int main ()
{
    string s;cin>>s;
    vector<int> dict(256,-1);
    int maxlen =0,start =-1;
    for (int i = 0; i < s.size(); i++)
    {
        if (dict[s[i]]>start)// if position of old key is greater then start
        {
            start=dict[s[i]]; // update start

        }
        dict[s[i]]=i;// update the position of the key
        maxlen=max(maxlen,i-start);
    }
    cout<<maxlen<<endl;
    
    return 0;
}