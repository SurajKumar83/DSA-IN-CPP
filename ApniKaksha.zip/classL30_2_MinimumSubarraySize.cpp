#include <bits/stdc++.h>
using namespace std;
int smallestsubarraysum(int a[], int n, int x)
{
    int ans = INT_MAX;
    int sum = a[0];
    int i = 0, j = 0;
    while ( j <=n)
    {
        if (sum <= x)
        {
            sum += a[j++];
        }
        else if (sum > x)
        {
            ans = min(ans, j - i);
            sum = sum - a[i++];
        }
    }
    return ans;
}
// second way of writing it
int smallestsubarraywithsum(int a[],int n,int x){
    int sum=0,ans=n+1,i=0,j=0;
    while(j<n){
        while(sum<=x && j<n){
            sum+=a[j++];
        }
        while(sum>x&& i<n){
            ans=min(ans,j-i);
            sum-=a[i++];
        }
    }
    return ans;
}
int main()
{
    int a[] = {3, 5, 2, 5, 3, 6, 8, 7, 4, 6, 9};
    int b[] = {1, 4, 45, 6, 20, 59};
    int x = 40;

    cout << smallestsubarraysum(a, 11, x) << endl;
    cout<<smallestsubarraywithsum(b,6,x)<<endl;
    return 0;
}