// // Count sort Algorithm
// // Time complexity of order(n+k);
// // k of order n means not very large
// // not prefferable for elements of different range in that use redix sort as that applied on digits {0-9} 
// // Counting sort which takes negative numbers as well
// #include <algorithm>
// #include <iostream>
// #include <vector>
// using namespace std;
 
// void countSort(vector<int>& arr)
// {
//     int max = *max_element(arr.begin(), arr.end());
//     int min = *min_element(arr.begin(), arr.end());
//     int range = max - min + 1;
 
//     vector<int> count(range), output(arr.size());
//     for (int i = 0; i < arr.size(); i++)
//         count[arr[i] - min]++;
 
//     for (int i = 1; i < count.size(); i++)
//         count[i] += count[i - 1];
 
//     for (int i = arr.size() - 1; i >= 0; i--) {
//         output[count[arr[i] - min] - 1] = arr[i];
//         count[arr[i] - min]--;
//     }
 
//     for (int i = 0; i < arr.size(); i++)
//         arr[i] = output[i];
// }
 
// void printArray(vector<int>& arr)
// {
//     for (int i = 0; i < arr.size(); i++)
//         cout << arr[i] << " ";
//     cout << "\n";
// }
 
// int main()
// {
//     vector<int> arr = { 5, 10, 0, 3, 8, 5, 1, 10 };
//     countSort(arr);
//     printArray(arr);
//     return 0;
// }
//Counting sort which takes only positive elements
#include<bits/stdc++.h>
using namespace std;

void countSort(int arr[], int n,int k)
{
   
    int count[k+1]={0};
    for (int i = 0; i < n; i++)
    {
        count[arr[i]]++;
    }
    for (int i = 1; i <=k; i++)
    {
        count[i]+=count[i-1];
    }
    
    int output[n];
    for (int i = n-1; i >=0; i--)
    {
        output[--count[arr[i]]]=arr[i];
    }
    
    for (int i = 0; i < n; i++)
    {
        arr[i]=output[i];
    } 
    for (int i = 0; i < n; i++)
    {
        cout<<arr[i]<<" ";
    }
}
int main()
{
    int arr[]={1,2,7,1,8,9,3,4,6,4};
    countSort(arr,10,9);
    
    return 0;
}