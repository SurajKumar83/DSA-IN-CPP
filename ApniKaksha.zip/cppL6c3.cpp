//WAP to convert binary to decimal 
#include<iostream>
#include<math.h>
using namespace std ;
int binarytodecimal(int n)
{  
    int sum=0;
    int i=1;
    while (n>0)
    {
        int lastdigit=n%10;
        sum+=lastdigit*i;
          i =i*2;
          n/=10;
    }  
   
    return sum; 
}
int main()
{ 
    int n;
    cin>>n;
    cout<<binarytodecimal(n)<<endl;
    return 0;
}