// ... Calculate n raised to power of p 

#include<bits/stdc++.h>
using namespace std;
long int p1(int n, int p)
{
    if (p<=0)
    {
        return 1;
    }
    long int Power = p1(n,(p-1));
    return n*Power;
}
long int p2(int n, int p)
{
    if (p<=0)
    {
       return 1;
    }
    if (p>0)
    {
        int s=1;
        for (int i = 1; i <=p; i++)
        {
            s=s*n;
        }return s;
    }  
}
int main()

{
    int n,p;
    cin>>n>>p;
    cout<<p1(n,p)<<endl;// using recursion
     cout<<p2(n,p)<<endl;// using for loop
    return 0;
}