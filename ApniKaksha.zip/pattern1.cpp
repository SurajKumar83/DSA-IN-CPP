/*
n=3
333222111
332211
321
*/
#include<bits/stdc++.h>
using namespace std;
void pattern(int n){

    for (int i=1;i<=n; i++)
    {
       int x=n;
       for (int j = 1; j <=n; j++)
       {
         for (int k = 1; k<=n-i+1; k++)
         {
             cout<<x<<" ";
         }
         x--;
          
       }
       cout<<endl;
       
    }
}
int main(){
    int n;cin>>n;
    pattern(n);
    return 0;
}