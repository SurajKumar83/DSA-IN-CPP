//... Character Array : array of characters
#include<iostream>
using namespace std;
int main()
{
    char arr[100]="apple";
    int i=0;
    while (arr[i]!= '\0')
    {
        cout<<arr[i]<<endl;
        i++;
    }
    
    char A[100];
    cin>>A;
    cout<<A<<endl;
    cout<<A[2]<<endl;
    return 0;
}