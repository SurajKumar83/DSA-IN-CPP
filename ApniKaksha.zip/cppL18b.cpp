#include<iostream>
using namespace std;
bool isSafe(int** arr ,int x,int y ,int n)
{
    //For column check
    for (int  row = 0; row < x; row++)
    {
        if (arr[row][y]==1)
        {
            return false;
        }
    }
    // for left diagonal
    int row =x;
    int col =y;
    while (row >=0 && col >= 0)
    {
        if (arr[row][col]==1)
        {
            return false;
        }
        row--;
        col--; 
    }
    // for right diagonal
    row = x;
    col = y;
    while (row >= 0 && col < n)
    {
        if (arr[row][col]==1)
        {
            return false;
        }
        row--;
        col++;
    }  
    // if we don't get false anywhere then
    return true;
}
bool nQeen(int** arr,int x,int n)//as we have to check in only 1D so we don't include int y
{
    //base case
    if (x>=n)//Means when all row overs or equal then we print the value 
    {
        return true;
    }
    // we check isSafe for each column in each row
    for (int  col = 0; col < n; col++)
    {
        if (isSafe(arr,x,col,n))
        {
            arr[x][col]=1;
            // but after placing 1 to the current ones we check for next  row wheather we can place the qeen or not
            if (nQeen(arr,x+1,n))
            {
                return true;
            }
            arr[x][col]=0;//backtracking
        } 
    }
    return false;//if we unable to place qeen to that entire row 
}
int main()
{
    int n;
    cin>>n;
    int** arr=new int*[n];
    for (int i = 0; i < n; i++)
    {
        arr[i]=new int[n];// to allocate  memory to every new arr
        //for initialising 
        for (int j= 0; j < n; j++)
        {
            arr[i][j]=0;
        } 
    }
    if (nQeen(arr,0,n))
    {
        for (int i = 0; i <n; i++)
        {
            for (int  j = 0; j < n; j++)
            {
                cout<<arr[i][j]<<" ";
            }
            cout<<endl;
        }
    }
    return 0;
}