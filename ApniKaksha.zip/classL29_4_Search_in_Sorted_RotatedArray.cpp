#include <bits/stdc++.h>
using namespace std;

int index(int a[], int n)
{
    int k = -1;
    for (int i = 0; i < n - 1; i++)
    {
        if (a[i] > a[i + 1])
        {
            return i + 1;
        }
    }
    return k;
}
int search(int a[], int n, int ind, int k)
{
    int l1 = 0, h1 = ind - 1;
    while (l1 <= h1)
    {
        int m = (l1 + h1) / 2;
        if (a[m] == k)
        {
            return m;
        }
        else if (a[m] > k)
        {
            h1 = m - 1;
        }
        else
        {
            l1 = m + 1;
        }
    }
    int l2 = ind, h2 = n - 1;
    while (l2 <= h2)
    {
        int m = (l2 + h2) / 2;
        if (a[m] == k)
        {
            return m;
        }
        else if (a[m] > k)
        {
            h2 = m - 1;
        }
        else
        {
            l2 = m + 1;
        }
    }
    return -1;
}
int search2(int a[], int l, int h, int k)
{
    if (l > h)
    {
        return -1;
    }

    int m = (l + h) / 2;
    if (a[m] == k)
    {
        return m;
    }
    if (a[l] <= a[m])
    {
        if (k >= a[l] && k <= a[m])
        {
            return search2(a, l, m - 1, k);
        }
        return search2(a, m + 1, h, k);
    }
    if (k >= a[m] && k <= a[h])
    {
        return search2(a, m + 1, h, k);
    }
    return search2(a, l, m - 1, k);
}
int main()
{
    int arr[] = {5, 6, 7, 8, 1, 2, 3, 4};
    int k = 2;
    int ind = index(arr, 8);
    cout << search(arr, 8, ind, k) << endl;
    int i = search2(arr, 0, 7, k);
    if (i == -1)
    {
        cout << "Not found" << endl;
    }
    else
    {
        cout << "Found at : " << i << endl;
    }
    return 0;
}