// Linked list is a multiple blocks of memory linked to each other where as in case of array one single  block of memory with partitions  
#include<bits/stdc++.h>
using namespace std;

// Node  is not in built so it needs to define by user
class node
{
  public:
  int data;
  node* next;// pointer pointing to the next node

  /*constructor*/
  node(int val)
  {
      data =val;
      next = NULL;
  }
};
 // function for inserting at start
 void insertAtHead(node* &head,int val){
   node* n=new node(val);
   n->next=head;// to give address of head to new node
   head=n;// to give new node as head
 }
// funtion for inserting an element at tail
void insertAtTail(node* &head/*here we take by refrence as we have to modify the linked list*/ , int val ){

  node* n=new node(val);// this will give one node n with data=val and next = NULL
  //if there is no any node in linked list
  if (head==NULL){
    head=n;
    return;
  }
  
  // to traverse the last node of linked list
  node* temp=head;
  while (temp->next!=NULL)
  {
    temp=temp->next;
  }
  // after this loop we come to the last of our ll
  // now we add our new node
  temp->next=n;

}
// to print this linked list
void display(node* head/* here we take head with value not by refrence as we are not modifying our linked list*/){
  node* temp=head;
  while (temp!=NULL)//traverse our list till temp NULL 
  {
    cout<<temp->data<<"->";
    temp=temp->next;
  }cout<<"NULL"<<endl;
  
}

// searching 
bool search(node* head,int key)
{
  node* temp=head;
  while(temp!=NULL){
    if (temp->data==key)
    {
      return true;
    }
   temp= temp->next;
  }
  return false;
}
int main()
{
    int key;
  cin>>key;
  node* head=NULL;
  insertAtTail(head, 1);
  insertAtTail(head, 2);
  insertAtTail(head, 3);
  insertAtTail(head, 4);
  display(head);
  cout<<search(head,key)<<endl;
  insertAtHead(head,0);
  display(head);
 
  cout<<search(head,key);
  
    return 0;
}