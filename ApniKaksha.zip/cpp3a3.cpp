#include <iostream>
using namespace std;
int main()
{
    int a;
    cin >> a;
    int i;
    for (i = 2; i < a; i++)
    {
        if (a % i == 0)
        {
            cout << "Non Prime " << endl;
            break;
        }
    }
    if (i == a)  //To check completion of for loop or break.
    {
        cout << "Prime " << endl;
    }

    return 0;
}