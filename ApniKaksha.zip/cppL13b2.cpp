#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
    // Form The Biggest Number From The Number String 
    string s="8957588558789587598570";
    sort(s.begin(),s.end(),greater<char>());
    cout<<s<<endl;
    // to find maximum reapeting character
    string s2="akffahoinkfhsfviaswrwjfknfwejfw";
    int freq[26];
    for (int i = 0; i < 26; i++)
    {
    freq[i]=0;
    }
    for (int i = 0; i < s2.size(); i++)
    {
        freq[s2[i]-'a']++;
    }
    char ans='a';
    int maxF = 0;
    for (int i = 0; i < 26; i++)
    {
        if (freq[i]>maxF)
        {
            maxF=freq[i];
            ans = i+'a';
        }
    }
    cout<<maxF<<" " << ans<<endl;
    return 0;
}