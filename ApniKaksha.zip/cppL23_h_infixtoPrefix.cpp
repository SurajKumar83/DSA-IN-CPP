#include<bits/stdc++.h>
#include<stack>

// #include<string>
#include<algorithm>
using namespace std;


int precedence(char c)
{
    if (c=='^')
    {
        return 3;
    }
    else if (c=='*'||c=='/')
    {
        return 2;
    }
    else if (c=='+'||c=='-')
    {
        return 1;
    }
    else// in case of brackets
    {
        return -1;
    } 
}

string infixtopostfix(string s)
{
     // reverse of string 
   reverse (s.begin(),s.end());

   // stack decleration 
   stack<char> st;
   // to store result
   string result;

    for (int  i = 0; i < s.length(); i++)
    {
        // to check operand
        if (s[i]>='a'&& s[i]<='z'|| s[i]>='A'&& s[i]<='Z')
        {
            result+=s[i];// addition of char to result 
        }
        // char is close bracket
        else if (s[i]==')')
        {
            st.push(s[i]);
        }
        // char is open bracket
        else if (s[i]=='(')
        {
            // we pop till we get closing bracket
            while (!st.empty() && st.top()!=')')
            {
                result+=st.top();
                st.pop();
            }
            // if stack is not empty then pop closing bracket
            if (!st.empty())
            {
                st.pop();
            }
            
            
        }
        // in case of operator 
        else
        {
            // precedence of curr operator > top operator
            while (!st.empty() && precedence(st.top())>precedence(s[i]))
            {
                result+=st.top();
                st.pop();
            }
            st.push(s[i]);// push curr operator to stack
            
        }
        
        
    }
    // in case some residue 
    while (!st.empty())
    {
        result+=st.top();// to store residue ones
        st.pop();
    }
    reverse(result.begin(),result.end());
    return result;

}
int main()
{
    cout<<infixtopostfix("(a-b/c)*(a/k-l)")<<endl;
    return 0;
}