#include <bits/stdc++.h>
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int data) : data(data), left(NULL), right(NULL) {}
};
/*
Strategy:
   1. if both empty ,return true
   2.if both non-empty,
      a. check that the data at nodes is equal
      b. check if left subtree are are same
      c. check if right subtree are same
3. if(a,b,c) are true return true
else return false
*/
/*     1                        1
        \                        \
         3                        3
        / \                      / \
       4   5                    4   5

*/
bool check_identical_BST(node *root1, node *root2)
{
    if (root1 == NULL && root2 == NULL)
    {
        return true; //
    }
    else if (root1 == NULL || root2 == NULL)
    {
        return false; // structuraly not same
    }
    else
    {

        bool cond1 = root1->data == root2->data;
        bool cond2 = check_identical_BST(root1->left, root2->left);
        bool cond3 = check_identical_BST(root1->right, root2->right);
        if (cond1 && cond2 && cond3)
        {
            return true;
        }
        return false;
    }
}

int main()
{
    node *root1 = new node(3);
    root1->left = new node(2);
    root1->right = new node(4);
    root1->left->left = new node(1);
    root1->right->right = new node(5);
    node *root2 = new node(3);
    root2->left = new node(2);
    root2->right = new node(4);
    root2->left->left = new node(1);
    root2->right->right = new node(5);

    node *root3 = new node(3);
    root3->left = new node(1);
    root3->right = new node(4);
    root3->left->left = new node(1);
    root3->right->right = new node(6);
    if (check_identical_BST(root1, root2))
        cout << "Identical";
    cout << endl;
    if (!check_identical_BST(root1, root3))
        cout << "Not identical";
    return 0;
}