// Detection and removal of cycle in linked list 
#include<bits/stdc++.h>
using namespace std;
class node
{
    public:
    int data;
    node* next;// ptr points to address
    // constructor
    node(int val)
    {
        data =val;
        next =NULL;
    }
};
// func. to insert at tail
void atTail(node* &head,int val){
    node* n=new node(val);
    if (head==NULL)
    {
        head=n;
        return;
    }
    node* temp=head;
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=n;
    
    
}
// func. to print linked list
void display(node* head){
    node* temp=head;
    while (temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }cout<<"NULL"<<endl;
    
}

void makeCycle(node* &head,int pos)// pos represents position where cycle is being formed
{
    node* temp=head;
    node* startNode;// for start of cycle node
    int count =1;
    while (temp->next!=NULL)
    {
        if (count==pos)
        {
           startNode=temp;
        }
        temp=temp->next;
        count++;
    }
    // after this loop temp will be on last node
    temp->next=startNode;// when temp reaches to last node then  its next points to NULL to make cycle we linked it to startnode;
}
// to check cycle
bool detectCyle(node* head){
    node* slow=head;
    node* fast=head;
    while (fast!=NULL && fast->next!=NULL)//as fast moves two steps in one move so it should be clear that fast and its next should not be null
    {
        slow=slow->next;
        fast=fast->next->next;
        if (fast==slow)
        {
            return 1;
        }
        
    }
    return 0;
}

// removal of cycle from linked list
void removalCyle(node* &head)
{
    node* slow=head;
    node* fast=head;
    //as slow == fast so we use do while loop
    do
    {
        slow=slow->next;
        fast=fast->next->next;
    } while (slow!=fast);
    // finding position of meeting 
    fast=head;
    while (slow->next!=fast->next)
    {
        fast=fast->next;
        slow=slow->next;
    }
    // after this we got position of start of cycle
    slow->next=NULL;
    
}
int  main(){
    node* head=NULL;
    for (int i = 0; i < 9; i++)
    {
        atTail(head,i);
    }
   makeCycle(head,4);
   // display(head);
   cout<<detectCyle(head)<<endl;
    removalCyle(head);
    cout<<detectCyle(head)<<endl;
    display(head);
    return 0;
}