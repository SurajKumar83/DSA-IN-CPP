#include<bits/stdc++.h>
using namespace std;
class S_tack
{
    int N;// for size of queue
    queue<int> q1;
    queue<int> q2;
    public:
    S_tack()
    {
        N=0;
    }
    // function for push
    void push(int val){
        q2.push(val);
        N++;// increase in size
        while (!q1.empty())// element by element
        {
            q2.push(q1.front());
            q1.pop();
        }
        // swap of q2 to q1
        queue<int> temp=q1;
        q1=q2;
        q2=temp;
    }
    void pop(){
        q1.pop();
        N--;
    }
     
     int top(){
         return q1.front();
     }
     // to know the size of stack
     int size(){
         return N;
     }
};

int main(){
    S_tack st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
   cout<<st.top()<<endl;
   st.pop();
   cout<<st.top()<<endl;
   st.pop();
   cout<<st.top()<<endl;
   st.pop();
   cout<<st.top()<<endl;
   st.pop();
   cout<<st.size()<<endl;
    return 0;
}