#include<bits/stdc++.h>
using namespace std;

// Node  is not in built so it needs to define by user
class node{
  public:
  int data;
  node* next;// pointer pointing to the next node

  /*constructor*/
  node(int val){
      data =val;
      next = NULL;  
  }
};
// function to insert at tail
void insertAtTail(node* &head,int val)
{
    node* n=new node(val);
    if (head==NULL)
    {
        head=n;
        return;
    }
    node* temp=head;
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=n;
}
// function to delete head
void deleteAtHead(node* &head){
    node* todelete=head;
    head=head->next;
    delete todelete;
}
// function to delete nth element
void deletion(node* &head,int val){
    // if no any node
    if (head==NULL)
    {
        return;
    }
    // if only one node
    if (head->next==NULL)
    {
        deleteAtHead(head);
        return;
    }
    
    
    node* temp=head;
    while (temp->next->data!=val)//till temp ke next node data!= val
    {
        temp=temp->next;
    }
    node* todelete=temp->next;// the node which we want to delete
    temp->next=temp->next->next;// n-1)th ko n+1)th se link
    
    delete todelete;// we first declare todelete node to store temp-next and then delete other wise we wouldn't delete after changing link
}
// to print linked list
void display(node* head){
    node* temp=head;
    while (temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }cout<<"NULL"<<endl;
    
}
// fun to reverse a linked list using iterative method
node* reverse(node* &head)
{
    node* prevptr=NULL;
    node* currptr=head;
    node* nextptr;
    while (currptr!=NULL)
    {
       nextptr=currptr->next;// to store next of currentptr to  nextptr;
       currptr->next=prevptr;// now link of currentptr changes to prevptr

       prevptr=currptr;
       currptr=nextptr;// shifting of position of currentptr

    }
    // after this loop we current ptr reaches to null
    return prevptr;

}
// Recursion method to print reverse of linked list
node* reverseRecursive(node* &head)
{

    if (head==NULL || head->next==NULL)
    {
        return head;
    }
    
    node* newhead=reverseRecursive(head->next);
    head->next->next=head;// to changing the link of 2nd node to head
    head->next=NULL;
    return newhead;
}
int main(){
    node* head=NULL;
    insertAtTail(head,0); 
    insertAtTail(head,1);
    insertAtTail(head,2);
    insertAtTail(head,3);
    display(head);
     deleteAtHead(head);
     display(head);
    deletion(head,2);
    display(head);
    node* newhead=reverseRecursive(head);
    display(newhead);
    return 0;
}