#include <bits/stdc++.h>
using namespace std;
int findPeakelement(int arr[], int n, int l, int h)
{
    int m = l + (h - l) / 2;
    if ((m == 0 || arr[m - 1] <= arr[m]) && (m == n - 1 || arr[m + 1] <= arr[m]))
    {
        return m;
    }
    else if (m > 0 && arr[m - 1] > arr[m])
    {
        return findPeakelement(arr, n, l, m - 1);
    }
    else
    {
        return findPeakelement(arr, n, m + 1, h);
    }
}
int main()
{
    int arr[] = {1, 2, 6, 3, 2, 7, 5,6,4};
    int l = 0, h = 8;
    vector<int> v;
    int i = 0;
    while (i < 9)
    {

        int p = findPeakelement(arr, 9, i, h);
        cout << arr[p] << endl;
        v.push_back(arr[p]);
        i = p+1;
    }
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << endl;
    }
    return 0;
}