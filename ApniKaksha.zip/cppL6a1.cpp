#include<iostream>
using namespace std;
int sum(int a, int b)
{
    cout<<" The sum of "<< a <<" and "<< b <<" is "<< a+b <<endl;
}
int main()
{
    double a,b;
    cin>>a>>b;
    double c=sum(a,b);

    return 0;
}