//Level Order Traversal , Sum at Kth Level In Binary Tree
// Level Order Traversal
#include "bits/stdc++.h"
using namespace std;

class Node
{
  public:
  int data;
  class Node* left;
  class Node* right;
  Node(int val){
      data=val;
      left=NULL;
      right=NULL;
  }  
};
//To print the level order 
// void printLevelOrder(Node* root)
// {
//     if (root==NULL)
//     {
//        return;
//     }
//     queue<Node*> q;// queue of nodes that will store the data of the node
//     q.push(root);//to add the root  node
//     q.push(NULL);// to Show the end of that level of trees
//     // Loop will run till the end of the queue

//     while (!q.empty())
//     {
//         // Check the front of the queue for null or not
//         Node* node = q.front();// to form the node of the front of the queue
//         q.pop();// to remove the front of the queue as this is stored as node
//         if (node!=NULL)
//         {
//             cout<<node->data<<" ";
//             if (node->left)
//             {
//                 q.push(node->left);

//             }
//             if (node->right)
//             {
//                 q.push(node->right);
//             }
            
            
//         }
//         //IF root is null then 
//         // check that wheather the queue is empty 
//         // if not then enqueue the NULL 
//         else if(!q.empty())
//         {
//             q.push(NULL);
//         }
        
//     }
    
    
// }
/*
               1
             /  \
            2    3
           / \  /  \
          4   5 6   7
*/
//  Sum at Kth Level In Binary Tree
void sumAtKthLevel(Node* root,int K){
    //Base Conditional
    if (root == NULL)
    {
         return ;//  means no root
    }   
    queue<Node*> q;
    q.push(root);
    q.push(NULL);// to Show the end of that level of trees
    int level=0;// to track the  level of the tree
    int sum=0;// to the sum of the elements of that level
    while (!q.empty())
    {
         Node* node = q.front();// to form the node of the front of the queue
        q.pop();// to remove the front of the queue as this is stored as node
        if (node!=NULL)
        {
            if (level!=K)
            {
                cout<<"Elements at "<<level<<" "<<node->data<<" ";
            }
            
            
            if (level==K)
            {
               sum+=node->data;
             cout<<endl<<"The Element at K level is: "<<node->data<<endl;
            }
            
            if (node->left)
            {
                q.push(node->left);

            }
            if (node->right)
            {
                q.push(node->right);
            }
            
            
        }
        // node null but queue is not empty
        else if (!q.empty())
        {
            q.push(NULL);
            level++;
        }
        
    }
    cout<<endl;
    cout<<"The Sum of elements at k level is: "<<sum<<endl;
    
}
int main(){
    Node* root = new Node(1);
    root->left=new Node(2);
    root->right=new Node(3);
    root->left->left=new Node(4);
    root->left->right=new Node(5);
    root->right->left=new Node(6);
    root->right->right=new Node(7);
    // Level Order Traversal
   // printLevelOrder(root);
    cout<<endl;
    sumAtKthLevel(root,1);
    return 0;
}