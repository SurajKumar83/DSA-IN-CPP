#include <iostream>
using namespace std;
int main()
{
    int Pocketmoney = 3000;
    for (int i = 0; i <= 30; i++)
    {
        if (i % 2 == 0)
        {
            continue;
        }
     if (Pocketmoney == 0 || Pocketmoney < 0)
     {
         break;
     }
        cout << "Go out today" << endl;
        Pocketmoney = Pocketmoney - 300;
    }

    return 0;
}