#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n, k;
    cin >> n >> k;
    int a[n];
    map<int, int> m;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    for (int i = 0; i < n; i++)
    {
        int size=m.size();
        if(m[a[i]]==0 && size==k){
            break;
        }
        m[a[i]]++;
    }
    vector<pair<int,int>> v;
    for (auto &it : m)
    {
        v.push_back(make_pair(it.second,it.first));
        --k;
        if(k==0){
            break;
        }
    }
    
    sort(v.begin(), v.end(),greater<pair<int,int>>());
    for(int i = 0; i < v.size(); i++){
        cout<<v[i].second<<" "<<v[i].first<<endl;
    }
    return 0;
} 