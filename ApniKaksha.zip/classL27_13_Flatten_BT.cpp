// Given a binary tree , flatten it into 
//linked  list inplace.After flattening ,left
 ///of each node should point to NULL and  
// right should contain next node in preorder
//  sequence.
//(It's NOT allowed to use other data structures)

#include "bits/stdc++.h"
using namespace std;
class Node{
    public:
    int data;
    Node* left;Node* right;
    Node(int val)
    {
        data=val;
        left=NULL;right=NULL;
    }
};
void inorderPrint(Node* root){
    if(root==NULL) return;
    inorderPrint(root->left);
    cout<<root->data<<" ";
    inorderPrint(root->right);
}
void flatten(Node *root)
{
    //s1
    if(root==NULL ||( root->left==NULL && root->right==NULL)){return;}
    if(root->left!=NULL) // if root  left is NULL then no need to flatten
    {
        flatten(root->left);
        Node * temp = root->right;
        root->right =root->left;
        root->left =NULL;
        Node * t=root->right;// same what we have root left as
        while(t->right!=NULL){
            t=t->right;
        }// we have reached to the end of t
        t->right =temp;
    }
    flatten(root->right);
}
int main()
{
    /*                     After flattening                               
            4               4                      
           /  \              \     
          9    5              9     
        /  \    \              \     
       1    3    6              1     
                                 \                    
                                   3  
                                    \
                                     5
                                      \ 
                                       6 
                                        
                                          
                                           
    inorder  1 9 3 4 5 6      INORDER 4 9 1 3 5 6 
    */
    Node* root = new Node(4);
    root->left =new Node(9);
    root->right =new Node(5);
    root->left->left =new Node(1);
    root->left->right =new Node(3);
    root->right->right =new Node(6);
    cout<<"Before flattening ";
    inorderPrint(root);
    cout<<endl;
    flatten(root);
    cout<<"After flattening ";
    inorderPrint(root);
    cout<<endl;
    return 0;
}