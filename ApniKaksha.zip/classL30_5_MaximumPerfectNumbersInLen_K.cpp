#include<bits/stdc++.h>
using namespace std;
bool Perfect(int n){
    int sum=1;
    for(int i=2;i<sqrt(n);i++){
        if(n%i==0){
            if(i==n/i){
                sum+=i;
            }
            else{
                sum+=i+n/i;
            }
        }
    }
    if(sum==n && n!=1){return true;}
    return false;
}
int  PerfectNumbersSubarrayOfSizeK(int a[],int n,int k){
     for(int i=0;i<n;i++){
        if(Perfect(a[i])){
            a[i]=1;
        }
        else{
            a[i]=0;
        }
     }
     if(n<k){
        cout<<"Invalid: "<<endl;
        return -1;}
     for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
     }cout<<endl;
     int sum=0;
     for(int i=0;i<k;i++){
        sum+=a[i]; 
     }
     int res=sum;
   
     for(int i=k;i<n;i++){
        sum=sum+a[i]- a[i - k];
        res=max(res,sum);
     }
     return res;
}
int main(){
    int array[]={496,99,2,3,6,28,24,8128};
    int k=4;
    cout<<PerfectNumbersSubarrayOfSizeK(array,8,k);
    return 0;
}