#include<iostream>
using namespace std;
int main()
{
    int a;//declaration
    a=4;//initialization
    cout<<"Size of int data type "<<sizeof(a)<<endl;
    float b;
    cout<<"Size of float  data type "<<sizeof(b)<<endl;
    char d;
    cout<<"Size of char data type "<<sizeof(d)<<endl;
    bool c;
    cout<<"Size of bool data type "<<sizeof(c)<<endl;
    return 0;
}

