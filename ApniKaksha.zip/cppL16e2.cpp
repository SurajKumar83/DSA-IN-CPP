// Find the number of ways in which n friends  can remain single or can be paired up;
#include<iostream>
using namespace std ;
int friendspairing(int n)
{
    // base case 
    if (n==0 || n==1 || n==2)
    {
        return n;
    }
    return friendspairing(n-1)/*if nth person remain single */ + friendspairing(n-2)/* if nth person pair with any of the n-1 person */*(n-1)/* number of ways in which nth person can pair up with n-1 person */;


    
}
int main(){
    cout <<friendspairing(4)<<endl;
    return 0;
}