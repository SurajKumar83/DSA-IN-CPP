#include<bits/stdc++.h>
using namespace std;
long int factorial(int n)
{
    if (n==0)
    {
        return 1;
    }
    
    int fact = factorial(n-1);
    return n*fact;
}
long int factoria_l(int n)
{
    if (n==0)
    {
        return 1;
    }
     int fact=1;
    for (int i = 1; i <=n; i++)
    {
        fact=fact*i;
    }
    return fact;
}
int cal_fact(int *num)
{
    long int fact=1;
    for (int  i = 1; i <= *num; i++)
    {
        fact*=i;
    }
    return fact;
    
}
int main()
{
    int a;
    cin>>a;
    cout<<factorial(a)<<endl;// using recursion
    int n;
    cin>>n;
    cout<<factoria_l(n)<<endl;
     int t;
     cin>>t;
     cout<<cal_fact(&t)<<endl;
    return 0;
}
