// Sorted array to Balanced BST;
// Balanced BST means difference of height of left
// and right subtree <=1
/*
Strategy:
1. Make middle element the root
2. Recursively, do the same for subtrees
    a. start to mid-1 for Left subtree
    b. mid+1 to end for Right subtree
*/
#include <bits/stdc++.h>
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int value) : data(value), left(NULL), right(NULL) {}
};
void Preorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    cout << root->data << " ";
    Preorder(root->left);
    Preorder(root->right);
}
Node *SortedArrayToBST(int array[], int low, int high)
{
    if (low > high)
        return NULL;
    int mid = (low + high) / 2;
    Node *root = new Node(array[mid]);
    root->left = SortedArrayToBST(array, low, mid - 1);
    root->right = SortedArrayToBST(array, mid + 1, high);
    return root;
}
int main()
{
    int array[] = {10, 20, 30, 40, 50};
    Node *root = SortedArrayToBST(array, 0, 4);
    cout<<"Preorder"<<endl;
    Preorder(root);
    cout << endl;
}