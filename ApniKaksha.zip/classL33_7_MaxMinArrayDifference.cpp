#include<bits/stdc++.h>
using namespace std;
 #define ll long long int
int main(){
  
  ll n;cin>>n;
  vector<ll> a(n);
  for(ll i=0; i<n; i++){
    cin>>a[i];
  }
  sort(a.begin(), a.end(),greater<int>());
  ll mnd=0;
  for(int i=0; i<n; i++){
     mnd+=abs(a[i]-a[i+1]);
     i++;
  }
  cout<<"Min "<<mnd<<" ";
  vector<ll> b;
  for(int i=0;i<n/2;i++){
     
    
  }
  a.erase(a.begin(),a.begin()+n/2);
  
  ll mxd=0;
  for(int i=0;i<n/2;i++){
      mxd+=abs(a[i]-b[i]);
  }
  cout<<"Max "<<mxd<<endl;
}