#include <bits/stdc++.h>
using namespace std;
// using sliding window
/*Problem :
For a given array and integers K & X find the
maximum sum subarray of size K and having sum less than X.
*/
int maximumsum(int a[], int n, int k, int x)
{

    int curr = 0, ans = INT_MIN;
    for (int i = 0; i < k; i++)
    {
        curr += a[i];
    }
    if (curr < x)
    {
        ans = curr;
    }cout << curr << endl;
    for (int i = k; i < n; i++)
    {

        curr = curr + a[i] - a[i - k];
        if (curr < x) 
        {
            ans = max(ans, curr);
        }
        cout << curr << endl;
    }
    cout << endl;
    return ans;
} 
int main()
{
    int arr[] = {7,5,4,6,8,9};
    int k = 3;
    int x = 20;
    cout << maximumsum(arr, 6, k, x) << endl;
}
   