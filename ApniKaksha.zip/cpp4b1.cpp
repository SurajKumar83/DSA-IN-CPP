//Inverted Pattern for n=5
#include<iostream>
using namespace std;
int main()
{ 
   int n;
   cin>>n;
   
   for (int  i = 1; i <= n; i++)
   {
      for (int j = 1; i <= n+1-i; j++)
      {
          cout<<j<<" ";
          
      }
      cout<<endl;
      
   }
    return 0;
}