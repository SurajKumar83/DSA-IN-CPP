#include<bits/stdc++.h>
#include<stack>
using namespace std;
int precedence(char c){
    if (c=='^')
    {
        return 3;
    }
    else if (c=='*'||c=='/')
    {
        return 2;
    }
    else if (c=='+'||c=='-')
    {
        return 1;
    }
    else{
        return -1;
    }
}
string infixtopostfix(string s){
    stack<char> st;//stack decleration 
    string result ;// to store result
    
    // iteration  of our string 
    for (int i = 0; i < s.length(); i++)
    {
        // to check operand 
        if ((s[i]>='a'&&s[i]<='z')|| (s[i]>='A'&&s[i]<='Z'))
        {
            result+=s[i];//addition of char to result
        }
        // if char is open bracket then 
        else if(s[i]=='('){

            st.push(s[i]);// store of char to stack st
        }
        // in case close bracket then
        else if (s[i]==')'){
            // we pop till we get open bracket open bracket
            while (!st.empty() && st.top()!='(')
            {
                result+=st.top();
                st.pop();
                //if stack if not empty then pop opening bracket
            }
             if(!st.empty()){
                 st.pop();// to pop opening bracket
             }
        }
        // in case we have operator
        else{
            // till precedence of curr opertator > top operator 
            while (!st.empty() && precedence(st.top())>precedence (s[i]))
            {
                result+=s[i];
                st.pop();
            }
            // then push curr operator(s[i]) to stack
            st.push(s[i]);
        }
        
        
   }
   // in case some resideue 
   while (!st.empty())
   {
       result+=st.top();
       st.pop();
   }
   
   return result;
    
}
int main(){

  cout<<infixtopostfix("(a-b/c)*(a/k-l)");
    return 0;
}