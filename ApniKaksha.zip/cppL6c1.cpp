//WAP to find the sum of n natural numbers using function.
//We can directly use the formula n(n+1)/2.
#include<iostream>
using namespace std;
long int addition(int n)
{
    int sum=0;
    for (int i = 1; i <=n ; i++)
    {
        sum+=i;
    }
    cout<<sum<<endl;
}
int main()
{
    int n;
    cin>>n;
    addition(n);
    return 0;
}