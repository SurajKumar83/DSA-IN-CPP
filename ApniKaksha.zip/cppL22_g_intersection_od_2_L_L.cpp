// Find intersection point of 2 Linked Lists
 #include<bits/stdc++.h>
 using namespace std;
 class node
 {
     public:
     int data;
     node* next;
     node(int val)
     {
         data=val;
         next=NULL;
     }
 };

 // to insert at tail
 void insertAtTail(node*  &head,int val){
     node* n=new node(val);
     if (head==NULL)
     {
         head=n;
         return;
     }
     node* temp=head;
     while (temp->next!=NULL)
     {
         
         temp=temp->next;

     }
     temp->next=n;
     
     
 }
 // to display 
 void display(node* head){
     node* temp=head;
     while (temp!=NULL)
     {
         cout<<temp->data<<"->";
         temp=temp->next;

     }cout<<"NULL\n"<<endl;
     
 }
 // to form a intersecting linked list
 void intersect(node* &head1,node* &head2,int pos){
     // here we traverse 1st ll till pos to which we want to add or link 2nd one
     node* temp1=head1;
     while (pos!=1)
     {
         temp1=temp1->next;
         pos--;
     }
     node* temp2=head2;
     while (temp2->next!=NULL)
     {
         temp2=temp2->next;
     }
     // at last we reached to last node of ll2 and at desired position in ll1
     temp2->next=temp1;
     
     
 }
 // to know the length of linked list
 int length(node* head){
     int l=0;
     node* temp=head;
     while (temp!=NULL)
     {
         temp=temp->next;
         l++;
     }
     return l;
     
 }
 // intersection funtion which detects intersection position as well as thir existence
 int intersection(node* &head1,node* &head2){
     int l1=length(head1);
     int l2=length(head2);
     int d=0;
     node* ptr1;// for longer linked list
     node* ptr2;// for shorter linked list
     if (l1>l2)
     {
         d=l1-l2;
         ptr1=head1;
         ptr2=head2;
     }
     else{
         d=l2-l1;
         ptr1=head2;
         ptr2=head1;
     }
     // after giving position to the pointer
     while (d)
     {
         ptr1=ptr1->next;
         if (ptr1==NULL)// in case ptr1 reaches to null means no intersection possible means that gives single linked list
         {
             return -1;
         }
         
         d--;//till d consumes
     }
     while (ptr1!=NULL && ptr2!=NULL)// we have to do increment in ptr1 and ptr2 till they points equal
     {
         if (ptr1==ptr2)
         {
             return ptr1->data;// when we reached to meeting position then 
         }
         
         ptr1=ptr1->next;
         ptr2=ptr2->next;
     }
     // in case two pointer do not meet in between then;
     return -1;
     

 }
 int main(){
     node* head1=NULL;
     node* head2=NULL;
     for (int i = 1; i < 9; i++)
     {
         insertAtTail(head1,i);
     }
     for (int i = 9; i < 11; i++)
     {
         insertAtTail(head2,i);
     }
     intersect(head1,head2,5);
     display(head1);
     display(head2);
     cout<<intersection(head1,head2);
  return 0;
 }