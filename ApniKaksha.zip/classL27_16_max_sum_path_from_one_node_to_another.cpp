/*
     Strategy
    for each node,compute:
    1. Node value
    2. Max path through left child + node val
    3. Max path through right child + node val
    4. Max path through left child +Max path through right child+ node val
   then max of  all

*/
#include "bits/stdc++.h"
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val)
    {
        data = val;
        left = NULL;
        right = NULL;
    }
};
int maxPathSumUtil(Node *root, int &ans)
{
    if (root == NULL)
        return 0;

    int left = maxPathSumUtil(root->left, ans);
    int right = maxPathSumUtil(root->right, ans);

    int nodeMax = max(max(root->data, root->data + left + right), max(root->data + left, root->data + right));

    ans = max(ans, nodeMax);//assigning the  value to the ans variable of max of ans or nodeMax
    int singlePathSum = max(root->data, max(root->data + left, root->data + right));// here we cann't take both the left and right sum together as we want single path but using that we get complete binary tree sum
    return singlePathSum;
}
int maxPathSum(Node *root)
{
    int ans = INT_MIN;
    maxPathSumUtil(root, ans); // this will calculate all the four values for each node
    return ans;
}
int main()
{
    /*
             1
           /  \
          2    3
        /       \
       4         5

    */
    Node *root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);
    root->right->right = new Node(-5);
    cout << maxPathSum(root);
    return 0;
}