/* Master theorem
 Recurrence Relation 
      A recurrence relation is an equation that recursively defines a sequence;
      Ex:
       fibonacci Series :
         f(n)=f(n-1)+f(n-2);


 According to master theorem
 if T(n)=means time to solve from '1' to 'n';
 for f(n)=O(n^c), a>=1, b>1
 there are following cases;
 c<log(a)base(b) then T(n)=O(n^(log(a)base(b))) 
 c=log(a)base(b) then T(n)=O((n^(c))*(log(a)) 
 c>log(a)base(b) then T(n)=O(f(n));         