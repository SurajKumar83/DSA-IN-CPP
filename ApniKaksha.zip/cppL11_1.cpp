//...use of pointer
#include<bits/stdc++.h>
using namespace std;
void increment(int *a)
{
    (*a)++;
}
int main()
{
    int a=3;
    int *ptr=&a;
    increment(ptr);
    cout<<a<<endl;
    return  0;
}