#include <bits/stdc++.h>
using namespace std;
class node
{
public:
    int data;
    node *left, *right;
    node(int data) : data(data), left(NULL), right(NULL) {}
};
void getVerticalOrder(node *root, int hdis, map<int, vector<int>> &m)
{
    if (root == NULL) // in case root is null then return
    {
        return;
    }
    m[hdis].push_back(root->data);             // pushing root->data at horrizontal distance hdis
    getVerticalOrder(root->left, hdis - 1, m); // after pushing the root data into the  vector to the
                                                // index hdis of the map we move to  the left
                                                // child of the node
    getVerticalOrder(root->right, hdis + 1, m);
}
int main()
{
    node *root = new node(10);
    root->left = new node(7);
    root->right = new node(4);
    root->left->left = new node(3);
    root->left->right = new node(11);
    root->right->left = new node(14);
    root->right->right = new node(6);
    map<int, vector<int>> m;
    int hdis = 0;
    getVerticalOrder(root, hdis, m);
    map<int, vector<int>>:: iterator it;
    for(it=m.begin(); it!=m.end(); it++)
    {
        cout<<it->first<<" ";
        for(int  i=0;i<(it->second).size();i++){
            cout<<(it->second)[i]<<" ";
        }cout<<endl; 
    }
    return 0;
}// time complexiety nlog(n) 