// // // // // /*Inheritance by which we can inherit attributes and methods from one class to another
// // // // // We will have two class a) Derived Class(child class- the class that inherits from another class) and (b) Base class(parent- the class being inherited from)
// // // // // Types of inhertance 
// // // // // 1. Single inheritance
// // // // // 2. Multiple inheritance
// // // // // 3. Multi level inheritance
// // // // // 4. Hybrid inheritance 
// // // // // 5. Hierarchical inheritance
// // // // // */

// // // // // // SINGLE 
// // // // // #include<bits/stdc++.h>
// // // // // using namespace std;
// // // // // class A{
// // // // //     public:
// // // // //     void func(){
// // // // //         cout<<"Inherited";

// // // // //     }
// // // // // };
// // // // // class B: public A{

// // // // // };
// // // // // int main(){
// // // // //     B b;
// // // // //     b.func();
// // // // //     return 0;
// // // // // }

// // // // // MULTIPLE
// // // // #include<bits/stdc++.h>
// // // // using namespace std;
// // // // class A{
// // // //     public:
// // // //     void Afunc(){
// // // //         cout<<"Func A\n";

// // // //     }
// // // // };
// // // // class B{
// // // //     public:
// // // //     void Bfunc(){
// // // //         cout<<"Func B\n";

// // // //     }
// // // // };
// // // // class C:public A,public B{
// // // //     public:

// // // // };
// // // // int main()
// // // // {
// // // //     C c;
// // // //     c.Afunc();
// // // //     c.Bfunc();
// // // //     return 0;
// // // // }

// // // //MULTILEVEL 
// // // #include<bits/stdc++.h>
// // // using namespace std;
// // // class A{
// // //     public:
// // //     void Afunc(){
// // //         cout<<"Func A\n";

// // //     }
// // // };
// // // class B:public A{
// // //     public:
// // //     void Bfunc(){
// // //         cout<<"Func B\n";

// // //     }
// // // };
// // // class C:public B{
// // //     public:

// // // };
// // // int main()
// // // {
// // //     C c;
// // //     c.Afunc();
// // //     c.Bfunc();
// // //     return 0;
// // // }

// // // Hybrid Inheritance
// // #include<bits/stdc++.h>
// // using namespace std;
// // class A{
// //     public:
// //     void Afunc(){
// //         cout<<"Func A\n";

// //     }
// // };
// // class B:public A{
// //     public:
// //     void Bfunc(){
// //         cout<<"Func B\n";

// //     }
// // };
// // class C{
// //     public:
// //   void CFunc(){
// //       cout<<"Func C\n";
// //   }
// // };
// // class D:public B,public C{
// //     public:
// // };
// // int main()
// // {
// //     D d;
// //     d.Afunc();
// //     d.Bfunc();
// //     d.CFunc();
// //     return 0;
// // }

// //HIERARCHICAL
// #include<bits/stdc++.h>
// using namespace std;
// class A{
//     public:
//     void Afunc(){
//         cout<<"Func A\n";

//     }
// };
// class B:public A{
//     public:
//     void Bfunc(){
//         cout<<"Func B\n";

//     }
// };
// class C:public A{
//     public:
//   void CFunc(){
//       cout<<"Func C\n";
//   }
// };
// class D:public B{
//     public:
// };
// class E:public B{
//     public:
// };
// class F:public C{
//     public:
// };
// class G:public C{
//     public:
// };

// int main()
// {
//     D d;
//     E e;
//     F f;
//     G g;
//     d.Afunc();
//     e.Bfunc();
//     f.Afunc();
//     g.CFunc();
   
//     return 0;
// }


 #include<bits/stdc++.h>
using namespace std;
class A{
    int  Rooms;
    protected:
    void put();
    public:
    void get(){
        cout<<"Func A\n";

    }
};
class B:private A{
    int labs;
    public:
    void take(){
        cout<<"Func B\n";

    }
    void give();// can access labs , put(),get(),take(),give()
};
class C:public B{
    int Roof;
    public:
    void in();
    void out();// can access Roof,in(),give(),take()
};
int main()
{
    C T;
    // can access in(),out(), take(),give(),
    return 0;
}