/*
Why Hashing:Play with element's indices.
There are two ways to do this
  1.Traverse the whole array,
  and  2.Thodi si extra memory ke dam pe elements aur indices ko map kare
  but Problem in storing indices is  array's limit is oly 10^8(that too global)

  But Hashing Converts elements into smaller elements using some functions(hash functions)
*/