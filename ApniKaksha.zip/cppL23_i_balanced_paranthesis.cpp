#include<bits/stdc++.h>
#include<string>
#include<stack>
using namespace std;
bool istrue(string s){
    int n=s.length();
    stack<char>  st; 
    // to store ans in ans var to say true or not
    bool ans=true ;

    // iterate over stirng
    for (int i = 0; i < n; i++)
    {
        // to push into the stack if we have s[i]==any of the opening bracket
        if (s[i]=='('||s[i]=='{'||s[i]=='[')
        {
            st.push(s[i]);
        }
        // now we check for closing bracket 
        else if (s[i]==')')
        {
            if (!st.empty()&& st.top()=='(')
            {
                st.pop();
            }
            else
            {
                ans=false;
                break;
            }
            
            
        }
         else if (s[i]=='}')
        {
            if (!st.empty()&& st.top()=='{')
            {
                st.pop();
            }
            else
            {
                ans=false;
                break;
            }
            
            
        }
         else if (s[i]==']')
        {
            if (!st.empty()&& st.top()=='[')
            {
                st.pop();
            }
            else
            {
                ans=false;
                break;
            }
            
            
        }
     
    }
    // in  case some of  more elements remain in the stack for ex if stirng is"{[]}["
    if (!st.empty())
    {
        return false;
    }
    return ans;
    
}
int main(){
     string  s="{[()]}(";
     if (istrue(s))
     {
         cout<<"Valid"<<endl;
     }
     else
     {
         cout<<"Invalid"<<endl;
     }
    return 0;
}