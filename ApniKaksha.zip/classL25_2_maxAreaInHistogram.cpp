#include<bits/stdc++.h>
using namespace std;
int get_max_area(vector<int> a)
{
    int n=a.size(),ans=0,i=0;
    stack <int> st;
    a.push_back(0);// to get rid of handling  rest elemments in the stack 
    while (i<n)
    {
        while (!st.empty() && a[st.top()]>a[i])
        {// this means we will get one potential area
            int t=st.top();
            int h=a[t];
            st.pop();
            if (st.empty())
            {
                // means height is smallest
                ans = max(ans,h*i);
            }
            else
            {
                // means length is smaller than previous
                int len = i-st.top()-1;
                ans =max(ans,h*len);
            }   
        }
        // stack empty or smaller
        st.push(i);
        i++; 
    }
    return ans;
}
int main(){
      vector<int> a={6, 1, 5, 4, 5, 2, 6};
      cout<<get_max_area(a);
    


     // // brute force approach
    // int n;
    // cin>>n;
    // int arr[n];
    // for (int i = 0; i < n; i++)
    // {
    //     cin>>arr[i];
    // }
    // int area=0;
    // for (int i = 0; i < n; i++)
    // {
    //     int left=i;
    //     int right=i;
    //     while (arr[left]>=arr[i])
    //     {
    //         left--;
    //     }
    //     while (arr[right]<=arr[i])
    //     {
    //         right++;
    //     }
    //     area=(right-left-1)*arr[i];   
    // }
    // cout<<area<<endl;

    return 0;
}