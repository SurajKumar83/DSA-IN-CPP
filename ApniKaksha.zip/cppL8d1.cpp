#include <bits/stdc++.h>
#include <climits>

using namespace std;
int main()
{
    int mx=INT_MIN;
    int n;
    cin>>n;
    int array[n];
    for (int i = 0; i < n; i++)
    {
        cin>>array[i];
    }
    int i=0;
    while (i<n)
    {
        mx=max(mx,array[i]);
        cout<<"max is :"<<mx<<endl;
        i++;
    }
    
    
    return 0;
}