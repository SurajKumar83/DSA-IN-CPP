// 3 sum problem
// given an array and a value, find if there exists three numbers whose sum is equal to the given value.

// brute force approach time complexity:O(N^3)
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int n,k;
//     cin>>n>>k;
//     int array[n];
//     for (int i = 0; i < n; i++)
//     {
//         cin>>array[i];
//     }
//     bool found=false;
//     for (int i = 0; i <n; i++)
//     {
//         for(int j=i+1;j<n;j++){
//             for(int k=j+1;k<n;k++){
//                 if (array[i]+array[j]+array[k]== k)
//                 {
//                     found=true;
//                 }           
//             }
//         }
//     }
//     if (found=true)
//     {
//         cout<<"YES"<<endl;
//     }
//     else
//     {
//         cout<<"NO"<<endl;
//     }
//     return 0;  
// }

/* Two Pointer Technique 
 1.Sort the array.
 2.Traverse the array and fix the first element of the triplet. The problem reduces to find if there exist two elements having sum equal to x-array[i].
*/
