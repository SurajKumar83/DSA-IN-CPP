#include<bits/stdc++.h>
#include<map>
using namespace std;
int main(){
    int n;cin>>n;
    vector<int> v(n);
    for(int i=0;i<n;i++){
        cin >>v[i];
    }
    map<int,int> m;
    for(int i=0;i<n;i++){
        m[v[i]]++;
    }
    map<int,int> :: iterator it;
    cout<<"Element "<<" "<<"Frequency "<<endl;
    for(it=m.begin();it!=m.end();it++){
        cout<<it->first<<"          "<<it->second<<endl;
    }
    unordered_map<int,int> um;
    for(int i=0;i<n;i++){
        um[v[i]]++;
    }
    unordered_map<int,int> :: iterator itu;
    cout<<"Element "<<" "<<"Frequency "<<endl;
    for(itu=um.begin();itu!=um.end();itu++){
        cout<<itu->first<<"          "<<itu->second<<endl;
    }
    return 0;
}