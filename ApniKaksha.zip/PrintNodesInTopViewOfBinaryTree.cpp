#include "bits/stdc++.h"
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int data) : data(data), left(NULL), right(NULL) {}
};
void printTopView(node *root, map<int, pair<int, int>> &m, int dist, int level)
{
    if (root = NULL)
    {
        return;
    }

    if (m.count(dist) == 0 || m[dist].second > level)
    {
        m[dist] = make_pair(root->data, level);
    }
    printTopView(root->left, m, dist - 1, level + 1);
    printTopView(root->right, m, dist + 1, level + 1);
}
void printbottomView(node *root, map<int, pair<int, int>> &m, int dist, int level)
{
    if (root == NULL)
    {
        return;
    }
    if (m.count(dist) == 0 || m[dist].second > level)
    {
        m[dist] = make_pair(root->data, level);
    }
    printbottomView(root, m, dist - 1, level + 1);
    printbottomView(root, m, dist + 1, level + 1);
}
int main()
{
    node *root = new node(1);
    root->left = new node(2);
    root->right = new node(3);
    root->left->left = new node(4);
    root->left->right = new node(5);
    root->right->left = new node(6);
    root->right->right = new node(7);
    map<int, pair<int, int>> m;
    cout << "The top view of the tree";
    printTopView(root, m, 0, 0);
    for (auto i : m)
    {
        cout << i.second.first << " ";
    }
    cout << endl;
    m.clear();
    cout << "Bottom view of the tree";
    printbottomView(root, m, 0, 0);
    for (auto i : m)
    {
        cout << i.second.second << " ";
    }
    cout << endl;
    return 0;
}