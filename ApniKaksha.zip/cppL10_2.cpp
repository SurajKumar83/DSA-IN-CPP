#include<iostream>
using namespace std;
int main()
{
    // check palindrome 
    int n;
    cin>>n;
    char arr[n+1];
    cin >> arr;
    bool flag = true;
    for (int  i = 0; i <n; i++)
    {
        if (arr[i]!=arr[n-1-i])
        {
            flag =false;
        }  
    }
    if (flag==true)
    {
        cout<<"Palindrome";
    }
    else
    {
        cout<<"Not a Palindrome";
    }
    
    return 0;
}