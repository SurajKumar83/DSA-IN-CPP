// Append of strings
#include<bits/stdc++.h>
#include<algorithm>//stores definition of sort of string
#include<string>
using namespace std;
int main()
{
    string s1 = "fam";
    string s2 = "ily";
    
    s1=s1+s2;// simple addition of two strings
    cout<<s1<<endl;
    string s3=" man";
  
    s1=s1.append(s3);// use of append function to add two strings
    cout<<s1<<endl;
    cout<<s1[7]<<endl;// to access any particular character from the string ;
    // to clear all the string we write 
    s1.clear();
    cout<<s1<<endl;
    cout<<s2<<endl;
    // To compare given two strings lexicographically 
    /* In this comparison of two strings each character of both the strings is converted into a Unicode value for comparison.
     1. If (str1>str2)it returns a positive value.
     2. if(str1==str2)it rturns 0.
     3. if(str1<str2)it returns a negative value.      */
    string s4="abc";
    string s5="xyz";
    string s6 = "ABC";
    string s7="abcd";
    cout<<s4.compare(s4)<<endl;
    cout<<s4.compare(s5)<<endl;
    cout<<s4.compare(s6)<<endl;
    cout<<s4.compare(s7)<<endl;
    if (s1.empty())//empty fun check wheather s1 is empty or not
    {
        cout<<"String is empty"<<endl;
    }
    // erase fun which erase selected character(/s) and shift next coming characters to the erased position; 
    string s8="ram is a very good boy";
    s8.erase(9,5);
    cout<<s8<<endl;// prints ram is a good boy
    string s9="ram is a good boy";
    cout<<s9.find("good")<<endl;//use of find function which results the index of starting character of find character(/s)
   // insert function in string
   string s10="Ram is a good boy.";
   cout<<s10.insert(8," very")<<endl;
   //...for length of string use length() or size()
   string s11="Ram is a good boy.";
   cout<<s11.size()<<endl;
   string s12="Ram is a good boy.";
   for(int i=0; i<s12.length();i++)
   cout<<s12[i]<<endl<<endl;
   // for some part of string s13
   string s13="Ram is a good boy.";
   cout<<s13.substr(0,13)<<endl;
   // to convert numeral string into integer
   string s14="788";
   int i=stoi(s14);
   cout<<i+2<<endl;
   // string to integer
   int x=788;
   cout<<to_string(x)+"2"<<endl;
    // sorrting of string
   string s15 ="xasfksajfoijkfkjsoj";
   sort(s15.begin(),s15.end());
   cout<<s15<<endl;
   
    return 0;
}