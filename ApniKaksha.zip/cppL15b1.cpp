//how many numbers between 1 and 1000 are divisible by 5 or 7;
#include<iostream>
using namespace std;
int divisible(int n,int a, int b)
{
    int c1=0,c2=0,c3=0;
    for (int i = 1; i <=n ; i++)
    {
        if (i%a==0)
        {
            c1+=1;
        }
        if (i%b==0)
        {
            c2+=1;
        }
        if (i%(a*b)==0)
        {
            c3+=1;
        }
        
        
    }
    return ((c1 + c2)-c3); 
}
int main()
{
    int n,a,b;
    cin>>n>>a>>b;
    cout<<divisible(n,a,b)<<" ";
}