#include <bits/stdc++.h>
using namespace std;
void heapify(vector<int> &v, int n, int i)
{
    // n=last position and i  means the first position
    int maxInd = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    if (l < n && v[l] > v[maxInd])
    {
        maxInd = l;
    }
    if (r < n && v[r] > v[maxInd])
    {
        maxInd = r;
    }
    if (maxInd != i)
    {
        swap(v[i], v[maxInd]);
        heapify(v, n, maxInd);
    }
}
void heapsort(vector<int> &v)
{
    int n = v.size();
    for (int i = n / 2 - 1; i >= 0; i--)
    {
        heapify(v, n, i);
    }
    for (int i = n - 1; i > 0; i--)
    {
        swap(v[0], v[i]);
        heapify(v, i, 0);
    }
}
priority_queue<int, vector<int>, greater<int>> pqm;
priority_queue<int, vector<int>> pq;
void insert(int x)
{
    if (pqm.size() == pq.size())
    {
        if (pq.size() == 0)
        {
            pq.push(x);
            return;
        }
        if (x < pq.top())
        {
            pq.push(x);
        }
        else
        {
            pqm.push(x);
        }
    }
    else
    {
        // two case possible
        // c1.size of maxHeap >size of minHeap
        // c2.size of maxHeap <size of minHeap
        if (pq.size() > pqm.size())
        {
            if (x >= pq.top())
            {
                pqm.push(x);
            }
            else
            {
                int temp = pq.top();
                pq.pop();
                pqm.push(temp);
                pq.push(x);
            }
        }
        else
        {
            if (x <= pqm.top())
            {
                pq.push(x);
            }
            else
            {
                int temp = pqm.top();
                pqm.pop();
                pq.push(temp);
                pqm.push(x);
            }
        }
    }
}
double findMedian()
{
    if (pqm.size() == pq.size())
    {
        return ((pqm.top() + pq.top()) / 2.0);
    }
    else if (pq.size() > pqm.size())
    {
        return pq.top();
    }
    else
    {
        return pqm.top();
    }
}
int main()
{
    vector<int> v = {10, 15, 21, 30, 18};
    int n = v.size();
    heapsort(v);
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;

    int x, y;
    if (n % 2 == 0)
    {
        cout << double(v[n / 2 - 1] + v[n / 2]) / 2.0 << endl;
    }
    else
    {
        cout << v[n / 2] << endl;
    }
    insert(10);
    cout << findMedian() << endl;
    insert(15);
    cout << findMedian() << endl;
    insert(21);
    cout << findMedian() << endl;
    insert(30);
    cout << findMedian() << endl;
    insert(18);
    cout << findMedian() << endl;
    return 0;
}
