#include <bits/stdc++.h>
using namespace std;
int  main(){
  int n,k;
  cin>>n>>k;

    vector<int> v(n);
    
    for(int i=0; i<n;i++){
        cin>>v[i];
    }
    priority_queue<int, vector<int>> pq;
    for(int i=0; i<n; i++){
        pq.push(v[i]);
    }
    int sm=0;
    int cnt=0;
    while (!pq.empty())
    {
          sm+=pq.top();
          pq.pop();
          cnt++;
          if(sm>=k){
            break;
          }
    }
    if(sm<k){
        cout<<"-1"<<endl;
    }
    else{
        cout<<cnt<<endl;
    }
    
    return 0;
} 