#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int data ;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};
// to insertAtTail
void insertAtTail(node* &head,int val){
    node* n = new node(val);
    if (head==NULL )
    {
        head=n;
        return;
    }

    node* temp=head;
    while (temp->next!=NULL)
    {
        temp=temp->next;

    }
    temp->next=n;
    
    
}
// to display 
void display(node* head){
    node* temp=head;
    while (temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }cout<<"NULL"<<endl;
    
}
// to know the  length of linked list
int length(node* head){
    int l=0;
    node* temp=head;
    while (temp!=NULL)
    {
        l++;
        temp=temp->next;
        
    }
    return l;
    
}
// To append last knodes to first node 
node* kappend(node* &head,int k)
{
    node* newHead;
    node* newTail;
    node* tail=head;
    int l=length(head);
    k%=l;//in case of l<k
    int count=1;// to know the postion to which we have reached
    while (tail->next!=NULL)// because we want to stop our LL at the end
    {
        if (count==l-k)
        {
            newTail=tail;//after l-k node we reached to our new tail
        }
        if (count==l-k+1)
        {
            newHead=tail;
        }
        tail=tail->next;
        count++;
        
        
    }// all three pointer has placed to their right position 
    // now change some links
    newTail->next=NULL;
    tail->next=head;
    return newHead;
}
int main()
{
    node* head=NULL;
    for (int  i = 1; i < 7; i++)
    {
        insertAtTail(head,i);
    }
    display(head);
    node* newhead=kappend(head,3);
    display(newhead);
    
  return 0;
}//time complexity of order O(N);