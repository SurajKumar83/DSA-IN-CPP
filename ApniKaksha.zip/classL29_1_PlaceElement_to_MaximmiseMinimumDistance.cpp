#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
bool isFeasible(int m,int arr[],int n,int k){
    int pos=arr[0];
    int elements=1;
    for(int i=1; i < n; i++){
        if(arr[i]-pos>=m){
            pos=arr[i];
            elements++;
            if(elements==k){
                return true;
            }
        }
    }
    return  false;
}
int largestMinDistance(int arr[], int n, int k)
{
    sort(arr, arr + n);
    for(int i=0;i<n; i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
    int result = -1;
    int l = 1;
    int r = arr[n - 1];
    while (l < r)
    {
        int m = (l + r) / 2;
        // check feasibility
        if (isFeasible(m, arr, n, k))
        {
            result = max(result, m);
            l = m+1;
        }
        else
        {
            r = m;
        }
    }
    return result;
}
int main(){
    int arr[]={1,2,8,4,9};
    int n=5;
    int k=3;
    cout<<"Largest min distance is: "<<largestMinDistance(arr,n,k)<<endl;
    return 0;
}