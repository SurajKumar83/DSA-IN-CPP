#include<bits/stdc++.h>
using namespace std;
#define vi vector<int>
#define pii pair<int,int>
#define rep(i,a,b) for(int i=a;i<b;i++)
void heapify(vi &a,int n,int i){
    //here n means the last position and i means the first position
    int maxIdx=i;//max index to start from
    int l=2*i+1;// left index for zero indexing
    int r=2*i+2;
    if(l<n && a[l]>a[maxIdx]){// this  will say about maxIdx(of elements parent,childleft or rightchild)
        maxIdx=l;
    }
    if(r<n && a[r]>a[maxIdx]){
        maxIdx=r;
    }
    if(maxIdx!=i){
        swap(a[i],a[maxIdx]);
        heapify(a,n,maxIdx);
    }
}
void heapsort(vi &a){
    // here we should always use the refrence of 
    // the vector,as we don't want to modify the vector 
    int n=a.size();// the size of the vector
    // here we remove the top the heap and swap with last element of three
    // and use the heapify down 
    // first non leaf elements value = n/2-1;
    for(int i=n/2-1;i>=0;i--){
        heapify(a,n,i);
    }
    for(int i=n-1;i>0;i--){
        swap(a[0],a[i]);
        heapify(a,i,0);
    }
}

int main(){
    int n;
    cin>>n;
    vi a(n);
    rep(i,0,n)
       cin>>a[i];

    heapsort(a);
    rep(i,0,n){
        cout<<a[i]<<" ";
    }cout<<endl;
    return 0;
}