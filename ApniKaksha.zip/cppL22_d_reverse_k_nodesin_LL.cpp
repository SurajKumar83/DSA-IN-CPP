#include<bits/stdc++.h>
using namespace std;
class node
{
    public:
    int data;
    node* next;// ptr points to address
    // constructor
    node(int val)
    {
        data =val;
        next =NULL;
    }
};
// func. to insert at tail
void atTail(node* &head,int val){
    node* n=new node(val);
    if (head==NULL)
    {
        head=n;
        return;
    }
    node* temp=head;
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=n;
    
    
}
// func. to print linked list
void display(node* head){
    node* temp=head;
    while (temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }cout<<"NULL"<<endl;
    
}

// func.to reverse k node in linked list
node* reverseKnodes(node* &head,int k){
    node* prevptr=NULL;
    node* currptr=head;
    node* nextptr;
    int count=0;// to know the length of k node;
    while (currptr!=NULL && count<k)
    {
        nextptr=currptr->next;
        currptr->next=prevptr;
        prevptr=currptr;
        currptr=nextptr;
        count++;
    }
    if (nextptr!=NULL)
    {
           
    head->next=reverseKnodes(nextptr,k);// in func we pass nexrptr as this reaches to after next of k nones,and head next of k nodes to fun head;

    }
  return prevptr;
}
int main()
{
    node* head=NULL;
   for (int i = 0; i < 6; i++)
   {
    atTail(head,i);   
   }
    
    
    display(head);
    int k=4;
    node* newhead=reverseKnodes(head,k);
    display(newhead);
}