#include <bits/stdc++.h>
#include <set>
#include<map>
using namespace std;
set<int> setInsert(int a[],int n)
{
    set<int>s;
    for(int i=0;i<n;i++){
        s.insert(a[i]);
    }
    return s;
    
}


void setDisplay(set<int>s)
{
    for(auto i:s){
        cout<<i<<" ";
    }
    cout<<endl;
}


void setErase(set<int>&s,int x)
{
   if(s.find(x)!=s.end()){
    cout<<"erased "<<x;
    cout<<endl;
    s.erase(x);
    
   return;
       
   }
    cout<<"not found";
    cout<<endl;
}
int main()
{
   int a[]={2,9,4,3,2,4,5,3,2,3,5,6,7,7};
    int x;
    cout<<"Your array in set"<<endl;
    set<int> s;
    s=setInsert(a,14);
    setDisplay(s);
    cout<<"Enter the number you want to delete"<<endl;
    cin>>x;
    setErase(s,x);
    setDisplay(s);
    cout<<*s.lower_bound(2)<<endl;
    cout<<*s.upper_bound(2)<<endl;
    set<int,greater<int>> st;
     for(int i=0;i<14;i++){
        st.insert(a[i]);
     }
     for(auto i:st){
        cout<<i<<" ";
     }cout<<endl;
     
    return 0;
}