//...Maximum subarray sum;
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n];
    for (int  i = 0; i < n; i++)
    {
        cin>>a[i];
    }
  /* // time complexcity is very high
   int maxsum=INT_MIN;
    
    for (int i = 0; i < n; i++)
    {  
        
        for (int j = i; j < n; j++)
        {
            int sum=0;
            for (int k = i; k <= j; k++)
            {
                sum+=a[k];  
                 maxsum=max(maxsum,sum); 
            } 
        }  
    }
   cout<<maxsum<<endl;
    */
    /* int currsum[n+1];
     currsum [0]=0;
     for (int  i = 1; i <= n ; i++)
     {
        currsum[i]= currsum[i-1] + a[i-1];
     }
     int maxsum=INT_MIN;
     for (int i = 1; i <= n; i++)//will tell the current position of currentsum
     {
         int sum=0;
         for (int j = 0; j < i; j++)
         {
             sum = currsum[i]-currsum[j];
             maxsum =max(maxsum,sum);
         }
     }*/
     int currsum=0;
     int maxsum = INT_MIN;
     for (int i = 0; i < n; i++)
     {
         currsum=currsum+a[i];
        if (currsum<0)
        {
            currsum=0;   
        }
        maxsum=max(maxsum,currsum);
     }
     cout<<maxsum<<endl;
    return 0;
}