// Postorder(left,Right,root) and inorder(left,root,right)
/*

Algorithm 
1. Start from the end of the of the  postorder and pick an element to create a node from
2. Decrement postorder idx
3. Search for picked element's pos in inorder
4. Call to build the right subtree from inorder's pos+1 to n
5. Call to build the left subtree from inorder 0 to pos-1
6. Return the  node
*/

/*
We Cann't build the  Tree using the post and preorder Sequence
Because : As the final tree will not similar  to any the post order or preorder
For Complete Binary Tree it is possible but not guaranteed for normal and Squed
*/

#include<bits/stdc++.h>
using namespace std;

class Node
{
    public:
    int data;
   class Node* left;
    class Node* right;
    Node(int val)
    {
       data=val;
       left=NULL;
       right=NULL;
    }
};

int search(int inorder[],int st,int end,int curr)
{
    for (int i = st; i <=end; i++)
    {
        if (inorder[i]==curr)
        {
            return i;
        }
        
    }
    return -1;
    
}

Node* BuildTree(int postorder[],int inorder[],int st,int end)
{
    static int idx=end;
    if (st>end)
    {
        return NULL;
    }
    int curr=postorder[idx];
    idx--;//decrement in index position
    Node* node=new Node(curr);
    if (st==end) // means we have reached to end of tree or leaf of the tree
    {
        return node;
    }
    //Search the position of current node in inorder list
    int pos=search(inorder,st,end,curr);

     // Build the right subtree
    node->right=BuildTree(postorder,inorder,pos+1,end);
    // pos+1 means in inorder we move from start of right to end of tight  part of the tree
   
    node->left=BuildTree(postorder,inorder,st,pos-1);
    // means move in inorder we move till left part of the tree
    return node;
}

void inorderPrint(Node* root)
{
    if(root==NULL)// Base case
    {
        return; // when there is no root
    }
    inorderPrint(root->left);
    cout<<root->data<<" ";
    inorderPrint(root->right);
}

int main()
{
    int postorder[]={4,2,5,3,1};
    int inorder[]={4,2,1,5,3};
    // BuildTree
    Node *root = BuildTree(postorder,inorder,0,4);
    cout<<"Inorder Sequence"<<endl;
    inorderPrint(root);
    return 0;
}