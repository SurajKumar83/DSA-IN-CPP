#include<bits/stdc++.h>
using namespace std;
class Node
{
    public:
    int data;
    Node* left;
    Node* right;
    Node(int val)
    {
        data=val;
        left=NULL;
        right=NULL;
    }
};
int height(Node* root){
    if (root== NULL)
    {
        return 0;
    }
    
    int leftheight=height(root->left);
    int rightheight=height(root->right);
    return leftheight+rightheight+1;
}
// time complexiety of O(n^2) due to call of height fun of O(n) for n node 
bool isBalanced(Node* root){
    if(root==NULL){
        return true;
    }
    if(isBalanced(root->left)==false){
        return false;
    }
    if(isBalanced(root->right)==false){
        return false;
    }
    int lh=height(root->left);
    int rh=height(root->right);
    if (abs(lh-rh)<=1)
    {
        return true;
    }
    else
    {
        return false;
    }
    
    
}
// time complexiety of O(N) NO need to call agaain and again of height use height pointer instead of
bool isBalanced2(Node* root,int * height2){
    if(root==NULL)return true;
    int lh=0,rh=0;
    if (isBalanced2(root->left, &lh)==false)
    {
        
        return false;
    }
    if (isBalanced2(root->right, &rh)==false){
        
        return false;
    }
    *height2=max(lh,rh)+1;
    if (abs(lh-rh)<=1)
    {
        return true;
    }
    else
    {
        return false;
    }
    
    
}
int main()
{
    /*
         1
        / \
       2   3
      / \  / \   
    4   5  6 7

    */
    Node *root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
     root->left->left = new Node(4);
    root->left->right = new Node(5);
    root->right->left = new Node(6);
     root->right->right = new Node(7);
//   if (isBalanced(root)) {cout<<"Balanced"<<endl;}
//   else {cout<<"Not Balanced"<<endl;}
//   cout<<endl;
  int height2=0;
   if (isBalanced2(root,&height2)) {
       cout<<"USING HEIGHT AS POINTER"<<endl;
       cout<<"Balanced"<<endl;}
  else {
      cout<<"USING HEIGHT AS POINTER"<<endl;
      cout<<"Not Balanced"<<endl;}
  /*
         1
        / 
       2   
      /    
    3  

//     */
//   Node* root2 = new Node(1);
//    root2->left = new Node(2);
//  root2->left->left = new Node(3);
//  if (isBalanced(root2)) {cout<<"Balanced"<<endl;}
//   else {cout<<"Not Balanced"<<endl;}
//   cout<<endl;
//    if (isBalanced2(root,&height2)) {cout<<"USING HEIGHT AS POINTER"<<endl;cout<<"Balanced"<<endl;}
//   else {cout<<"USING HEIGHT AS POINTER"<<endl;cout<<"Not Balanced"<<endl;}
  return 0;

}