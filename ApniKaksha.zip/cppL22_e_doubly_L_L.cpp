// Doubly Linked List: have node containing previous then data then next means in such types of lisnked list we can move to and fro
#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int  data;
    node* next;
    node* prev;
    
    node(int val){
        data= val;
        next=NULL;
        prev=NULL;

    }
};
// insert at head
void insertAtHead(node* &head,int val){
    node* n=new node(val);
    n->next=head;
   if (head!=NULL)
   {
        head->prev=n;
   }
   
    head=n;
}
// insert at tail
void insertAtTail(node* &head,int val){

    // if head is null
    if (head==NULL)
    {
        insertAtHead(head,val);
        return ;

    }
    
    node* n=new node(val);
    node* temp=head;
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
    // we have reached to last node
    temp->next=n;//to store our new node to next of temp
    n->prev=temp;// to store prev of n to temp
    
}
// to display
void display(node* head){
    node* temp=head;
    cout<<"NULL"<<" <-> ";
    while (temp!=NULL)
    {
        cout<<temp->data<<" <-> ";
        temp=temp->next;
    }cout<<"NULL \n"<<endl;
    
} //to delete node when only one node exist 
void daleteAtHead(node* &head){
    node* todelete=head;
    head=head->next;
    head->prev=NULL;
    delete todelete;
}
// to delete one node from more than one node
void deletion(node* &head,int pos){//pos position to delete
    if (pos==1)
    {
      daleteAtHead(head);
      return;
    }
    
    node* temp=head;
    int count=1;
    while (temp!=NULL && count!=pos)// till temp  not equal to NULL and count not equal to pos
        {
        temp=temp->next;
        count++;
    }
    temp->prev->next=temp->next;
    if (temp->next!=NULL)
    {
        temp->next->prev=temp->prev;
    }
    
    delete temp;// we have to delete this temp
    
}

int main(){
    node* head=NULL;
    for (int  i = 1; i < 6; i++)
    {
        insertAtTail(head,i);
    }
    display(head);
    insertAtHead(head,0);
    display(head);
    deletion(head,1);
    display(head);
    return 0;
}