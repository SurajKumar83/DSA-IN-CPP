#include<bits/stdc++.h>
using namespace std;

int main(){
    for (int i = 0; i <=5; i++)
    {
        cout<<i<<" ";
    }
    cout<<endl;
    for (int i = 0; i++<=5;)
    {
        cout<<i<<" ";
    }
    cout<<endl;
    for (int i = 0; ++i<=5;)
    {
        cout<<i<<" ";
    }
    cout<<endl;
    for (int i = 0; i<=5;++i)
    {
        cout<<i<<" ";
    }
     cout<<endl;
    for (int i = 0; i<=5;)
    {
        cout<<i++<<" ";
    }
     cout<<endl;
    for (int i = 0; i<=5;)
    {
        cout<<++i<<" ";
    }
    
    
    return 0;
    
}