#include<bits/stdc++.h>
using namespace std;
// fun decleration 
int f1(int a,int b);
int main(){
     int firstNum,secondNum,sumofNums;
     cout<<"Enter first number :-";
     cin>>firstNum;
     cout<<"Enter second number :- ";
     cin>>secondNum;

     sumofNums=f1(firstNum,secondNum);
     cout<<"Addition is :"<<sumofNums<<endl;

    return 0;
}
int f1(int a,int b){
    int c;
    c=a+b;
    return c;
}