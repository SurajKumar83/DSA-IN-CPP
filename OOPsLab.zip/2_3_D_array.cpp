#include<bits/stdc++.h>
using namespace std;
char arr9[2][2][3]={{"ac","de"}, {"fg","hi"}};// global variable
int main(){
    // //char arr1[4]="ABCD";//Error as the last char is null so its size should be 5
    // char arr1[5]="ABCD";
    // for (int i = 0; i <5; i++)
    // {
    //     cout<<arr1[i]<<" ";
    // }
    // cout<<endl;
    // char arr2[]="EFGH";
    // for (int i = 0; i < 5; i++)
    // {
    //     cout<<arr2[i]<<" ";
    // }cout<<endl;

    // char arr3[3][4]={"abc","def","ghi"};
    // for (int i = 0; i <3; i++)
    // {
    //     for (int j = 0; j<4; j++)
    //     {
    //          cout<<arr3[i][j]<<" ";
    //     }cout<<endl;
        
    // }
    // cout<<endl;
    /*
    2 d 
    abc
    def
    ghi
    jkl
        = {"abc","def","ghi","jkl"}
    
    3D
     a[2][4][3]=
     {{{1,2,3},{4,5,6},{7,8,9},{9,10,11}},{{1,2,3},{4,5,6},{7,8,9},{9,10,11}}}

     a[4][3][2]
    
    */





//    int arr4[2][4][3]=
//      {{{1,2,3},{4,5,6},{7,8,9},{9,10,11}},{{12,13,14},{15,16,17},{18,19,20},{21,22,23}}};
//      int *p1=&arr4[0][0][0];
//     for (int i = 0; i<2; i++)
//     {
//         for (int j = 0; j<4; j++)
//         {
//             for (int k = 0; k<3; k++)
//             {
//                 // cout<<**arr4[i][j][k]<<" "; error as we can't use it as pointer
//                 // cout<<***arr4<<" ";// *** will not give error for 
//                 cout<<p1++<<" ";// gives address 24 times
//             }cout<<endl;
            
//         }cout<<endl;
        
//     }cout<<endl;

    //  int arr4[2][4][3]=
    //  {{{1,2,3},{4,5,6},{7,8,9},{9,10,11}},{{12,13,14},{15,16,17},{18,19,20},{21,22,23}}};
    //  int *p1=&arr4[0][0][0];
    // for (int i = 0; i<2; i++)
    // {
      
    //             cout<<p1++<<" "<<endl;// gives address of  times
    //             cout<<**arr4[i]<<endl;//for i=0 1;i=1 12
    // }

//  int arr4[2][4][3]=
//      {{{1,2,3},{4,5,6},{7,8,9},{9,10,11}},{{12,13,14},{15,16,17},{18,19,20},{21,22,23}}};
//      int *p1=&arr4[0][0][0];
//     for (int i = 0; i<2; i++)
//     {
//       for(int j=0;j<4;j++)
//       {
//                 cout<<p1++<<" "<<endl;// gives address of each element that follow this loop
//                 cout<<*arr4[i][j]<<endl;//print value at that particular position like
//       }
//     }
    
    // int arr5[3][4][3]=
    //  {{{1,2,3},{4,5,6},{7,8,9},{9,10,11}},
    //    {{12,13,14},{15,16,17},{18,19,20},{21,22,23}},
    //     {{12,13,14},{15,16,17},{18,19,20},{21,22,23}}};// this how we give value for 3d array
        
    // for (int i = 0; i<3; i++)
    // {
    //     for (int j = 0; j<4; j++)
    //     {
    //         for (int k = 0; k<3; k++)
    //         {
    //             cout<<arr5[i][j][k]<<" ";
    //         }cout<<endl;
            
    //     }cout<<endl;
        
    // }cout<<endl;

 char arr9[2][2][3]={{"ac","de"}, {"fg","hi"}};

//    char *p2=&arr9[0][0][0];
//    for (int i = 0; i <2; i++)
//    {
//        for (int j = 0; j < 1; j++)
//        {
//            for (int k = 0; k < 2; k++)
//            {
//                //cout<<p2++<<endl;
//               // cout<<*p2++<<endl;
//                cout<<arr9[i][j][k]<<" ";

//            }
           
//        }
       
//    }
   
   // char arr9[2][3][3]={{{'a','b','c'},{'d','e','f'},{'g','h','i'}},{{'r','q','p'} ,{'o','n','m'},{'l','k','j'}}};

   char *p2=&arr9[0][0][0];
   for (int i = 0; i <2; i++)
   {
     //  for (int j = 0; j < 3; j++)
      // {
          
               //cout<<p2++<<endl;
              // cout<<*p2++<<endl;
              // cout<<*arr9[i][j]<<endl;// print value
               // cout<<arr9[i][j]<<endl;// print print address of that element
                cout<<*arr9[i]<<endl;// print value
                 cout<<**arr9[i]<<endl;// print value
                cout<<arr9[i]<<endl;//print print address of that element
                cout<<&arr9[i]<<endl;
                cout<<endl;
           
      //}
       
   }














   // char arr5[2][3][2]={{"ab","cd","ef"},{"ab","cd","ef"}};
    // for (int i = 0; i<2; i++)
    // {
    //     for (int j = 0; j<2; j++)
    //     {
    //         for (int k = 0; k<2; k++)
    //         {
    //             cout<<arr4[i][j][k]<<" ";
    //         }
            
    //     }cout<<endl;
        
    // }cout<<endl;
    
    
    return 0;
}