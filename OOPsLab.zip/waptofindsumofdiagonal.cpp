// // WAP to find sum of diagonal elements of a square matrix
// // #include<bits/stdc++.h>
// // using namespace std;

// // int main()
// // {
// //     int count;cin>>count;
// //     int array[count][count];
// //     for (int i = 0; i < count; i++)
// //     {
// //         for (int j = 0; j < count; j++)
// //         {
// //             cin>>array[i][j];
// //         }
        
// //     }
// //     int sum=0;
// //     int i=0,j=0;
// //     while (i<count && j<count )
// //     {
// //        sum+=array[i][j];
// //        i++;j++;
       
// //     }
// //     cout<<"Sum of diagonal : "<<sum<<endl;
    
    
// //     return 0;
// // }

// // write the above program using class concept
// #include<bits/stdc++.h>
// using namespace std;
// class sumofDiag
// {
//    public:
//     int Diagonal(int array[][],int count)
//     {
//          int sum=0;
//          int i=0;
//          int j=0;
//         while (i<count && j<count )
//          {
//            sum+=array[i][j];
//            i++;j++;
//          }
//         return sum;
//     }
// };
// int main()
// {
//     int count;cin>>count;
//     int array[count][count];
//     for (int i = 0; i < count; i++)
//     {
//         for (int j = 0; j < count; j++)
//         {
//             cin>>array[i][j];
//         } 
//     }
//    sumofDiag obj;
//     cout<<"Sum of diagonal : "<<obj.Diagonal(array,count)<<endl;   
//     return 0;
// }

#include<bits/stdc++.h>
using namespace std;

class sumofDiag
{
   public:
    int Diagonal(int *array[],int count)
    {
         int sum=0;
         int i=0;
         int j=0;
         
        while (i<count && j<count )
         {
           sum+=array[i][j];
           i++;j++;
         }
        return sum;
    }
};

int main()
{
    int count;cin>>count;
    int *array[count];
    for (int i = 0; i < count; i++)
    {
        array[i]=new int[count]; // Dynamic memory allocation 

        for (int j = 0; j < count; j++)
        {
            cin>>array[i][j];
        } 
    }
    sumofDiag obj;
    cout<<"Sum of diagonal : "<<obj.Diagonal(array,count)<<endl;   
    return 0;
}