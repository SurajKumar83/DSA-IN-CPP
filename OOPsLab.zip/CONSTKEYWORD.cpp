#include<bits/stdc++.h>
using namespace std;

// class Box : public{
//     public:
    
// }
// static  Object
class test {
    public:
    int a;
    test()
    {
      a=10;
     // cout<<"Constructor is executed"<<endl;

    }
    // test(const test &t1,test &t2)
    // {
    //     test t3;
    //     t1.a=35;
    //     t2.a=40;
    //     cout<<t1<<endl<<t2<<endl;
    // }
    ~test()// destructor use to destroy obj (so that we can empty that memeory)
    // Of one type, and only one in whole class
    {
       // cout<<"Destructor is executed"<<endl;
    }
};
// we can create obj within main or out of that as obj is 
const test obj;
static test obj1;
void myfunction(){
    static test obj2;

}//object obj is still not destroyed because it is static 
int main()
{
    
    cout<<"Main () starts "<<endl;
   
    // myfunction();
    cout<<obj1.a<<endl;
    // obj.a=20;
  //  cout<<obj.a<<endl;assignment of member 'test::a' in read-only object
   
    cout<<"Main () terminates "<<endl;
   // return 0;// Means success 
   return 1;
}
