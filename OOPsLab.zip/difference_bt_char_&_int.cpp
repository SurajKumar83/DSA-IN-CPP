#include<bits/stdc++.h>
using namespace std;
int main()
{
    char c;
    c ='a';
    int i=100;
    cout<<sizeof(c)<<endl;// 1

    cout<<i<<endl;// 100

    cout<<char(i)<<endl;// d

    cout<<c<<endl;// a
    
    cout<<int(c)<<endl;
    cout<<c+4<<endl;// 101

    cout<<char(c+4)<<endl;//e

    cout<<c-32<<endl;//65

    cout<<char(c-32)<<endl;//A  when we subtract 32 from small character then we get its capital form 

    cout<<c+c<<endl;//194

    cout<<char(c+c+c)<<endl;//?

    cout<<c+1<<endl;//98
    cout<<char(36)<<endl;//$

    cout<<char(35)<<endl;//#

    cout<<char(34)<<endl;//"

    cout<<c*c<<endl;;
    
    cout<<c/c<<endl;
    
    cout<<c%c<<endl;

    cout<<char(c+c+c-256)<<endl;// for signed there is reserve bit for sign from -127 to 127 but in case of unsigned value starts from 0 to end to 255
    char d;
    d=c;
    cout<<c+32<<endl;//129
    
    cout<<int(d)<<endl;//97

    return 0 ;
}