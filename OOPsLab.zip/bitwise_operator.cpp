#include<bits/stdc++.h>
using namespace std;

int main()
{ int a=0;;
int b=-7;
int c=5;
int d=8;
int e=7;
cout<<(a && b)<<endl;// 0 as any one of input is 0 we get 0 as there is AND operator
cout<<(a || b)<<endl;// 1  as any one of input is 1 we get 1 as there is OR operator
 cout<<(d || b || c)<<endl;//1 
 cout<<(d && b && c)<<endl;//1
  cout<<(d && e && c)<<endl;//1
  cout<<(d && e || c)<<endl;//1
  cout<<c || b ;// it will give 5 as output as it consider a and leave rest as it is
   cout<<endl;
   cout<<c && b ;
   return 0;
}