#include<bits/stdc++.h>
using namespace std;
class Shape
{
    int x;
    int y;
    public:
    
    void input(){
        cout<<"Enter the x and y value"<<endl;
        cin>>x>>y;

    }
    void area(){
        cout<<"area is"<<endl;
    }
    
    // Shape operator =(int x)
    // {
    //     Fu temp;
    //     temp.x=x;
    // }
    // void input(){
    //     cout<<"input"<<endl;
    //     cin>>x;
    // }
    // void display(){
    //     cout<<"Value of input is = "<<x<<endl;
    // }
    
};
class rectangle
{
    int length;
    int width;
    public:
    void input(){
        cout<<"Length and width of rectangle"<<endl;
        cin>>length>>width;
    }

    // public:
    // B operator =(int y)
    // {
    //     B temp;
    //     temp.y=y;
    // }
};

int main(){
//   Fu obja;
//   obja.input();
//   obja.display();
//   B objb;
//   cout<<"After assigning values of obja to objb"<<endl;
// //   objb=obja;
rectangle r1;
r1.input();
Shape s1;

  return 0;
}
