#include <bits/stdc++.h>
using namespace std;
class employee
{
  string name;
  int id;
  float Basic, DA, HRA, salary;

public:
  void calculate_sal(float, float, float);
  void feed_data()
  {
    cout << "Enter Employee Name: " << endl;
    cin >> name;
    cout << "Enter ID: " << endl;
    cin >> id;
    cout << "Enter the salary data " << endl;

    cout << "Enter the Basic : " << endl;
    cin >> Basic;
    cout << "Enter DA : " << endl;
    cin >> DA;
    cout << "Enter HRA : " << endl;
    cin >> HRA;
    calculateSalary(Basic, DA, HRA);
  }

  void calculateSalary(float Basic, float DA, float HRA)
  {
    salary = (Basic + DA + HRA);
  }

  void showdata()
  {
    cout << endl;
    cout << "Employee name : " << name << endl;
    cout << "Employee id : " << id << endl;
    cout << "Employee salary : " << salary << endl;
  }
};

int main()
{
  employee E1;
  E1.feed_data();
  E1.showdata();
  return 0;
}