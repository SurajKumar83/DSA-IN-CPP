#include<bits/stdc++.h>
using namespace std;

void mystery(int *ptr1,int *ptr2){
    cout<<"Start1"<<endl;
    cout<<ptr1<<endl<<ptr2<<endl<<*ptr1<<endl<<*ptr2<<endl;
    cout<<"Stop1"<<endl<<endl;
    int *temp;
    temp=ptr2;
    ptr2=ptr1;
    ptr1=temp;
    cout<<"Start2"<<endl<<endl;
    cout<<ptr1<<endl<<ptr2<<endl<<*ptr1<<endl<<*ptr2<<endl;
    cout<<"Stop2"<<endl;
}
int main(){
    int a=2016,b=0,c=4,d=42;
    mystery(&a,&b);
    //cout<<a<<" "<<b<<endl;
    if (a<c)
     mystery(&c,&a);
    mystery(&a,&d);
    cout<<endl<<a;
    
    return 0;
}