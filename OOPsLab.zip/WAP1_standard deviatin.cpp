// // WAP to compute the standard deviatin of the 10 floating point numbers.
// #include<bits/stdc++.h>
// #include<cmath>
// using namespace std;
// #define ll long long int


// int main(){
//      int n;cin>>n;
//      float arr[n];
//      for (int i = 0; i < n; i++)
//      {
//          cin>>arr[i];
//      }
//      ll maxsum=INT_MIN;
//      for (int i = 0; i < n; i++)
//      {
//          ll sum=0;
//          sum+=arr[i];
//          maxsum=max(maxsum,sum);

//      }
//      float mean=maxsum/n;
//      float maxdev=-1;
//     for (int i = 0; i < n; i++)
//     {
//         float deviationsum=0;
//         deviationsum+=pow(arr[i]-mean,2);
//        maxdev=max(deviationsum,maxdev);
//     }
//     float stdDeviation=sqrt(maxdev/n);

//      cout<<stdDeviation<<endl;
//     return 0;
// }

// // WAP in which the standard deviation is computed using a function 
// #include<bits/stdc++.h>
// #include<cmath>
// using namespace std;
// #define ll long long int
// float stdDeviation(int n,float  maxdev)
// {
//      return sqrt( maxdev/n);
// }

// int main(){
//      int n;cin>>n;
//      float arr[n];
//      for (int i = 0; i < n; i++)
//      {
//          cin>>arr[i];
//      }
//      ll maxsum=INT_MIN;
//      for (int i = 0; i < n; i++)
//      {
//          ll sum=0;
//          sum+=arr[i];
//          maxsum=max(maxsum,sum);

//      }
//      float mean=maxsum/n;

//      float maxdev=-1;
//     for (int i = 0; i < n; i++)
//     {
//         float deviationsum=0;
//         deviationsum+=pow(arr[i]-mean,2);
//        maxdev=max(deviationsum,maxdev);
//     }
  

//      cout<<stdDeviation( n,maxdev)<<endl;
//     return 0;
// }

#include<bits/stdc++.h>
#include<cmath>
using namespace std;
#define ll long long int
class floatdeviation
{
   public:
   float stdDeviation(int n,float  maxdev)
   {
     return sqrt( maxdev/n);
   }

};

int main(){
     int n;cin>>n;
     float arr[n];
     for (int i = 0; i < n; i++)
     {
         cin>>arr[i];
     }
     ll maxsum=INT_MIN;
     for (int i = 0; i < n; i++)
     {
         ll sum=0;
         sum+=arr[i];
         maxsum=max(maxsum,sum);

     }
     float mean=maxsum/n;

     float maxdev=-1;
    for (int i = 0; i < n; i++)
    {
        float deviationsum=0;
        deviationsum+=pow(arr[i]-mean,2);
       maxdev=max(deviationsum,maxdev);
    }
  
    floatdeviation obj;

     cout<<obj.stdDeviation( n,maxdev)<<endl;
    return 0;
}


