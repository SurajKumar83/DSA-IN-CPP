// to check prime or not

#include<bits/stdc++.h>
#include<cmath>
using namespace std;

int main(){
    int n;
    cout<<"Enter the number: ";
    cin>>n;
    bool flag=false;
    for (int i = 2; i <sqrt(n) ; i++)
    {
        if (n%i==0)
        {
            flag =true;
        }
        
    }
    if(flag==true){
        cout<<"Not a prime number "<<endl;
    }    

    else
    {
        cout<<"Prime number "<<endl;
    }
    
    return 0;
}