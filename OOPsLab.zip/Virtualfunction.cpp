#include <bits/stdc++.h>
using namespace std;
// function overloading take different  argument for difference
// while runtime polymorphism means same fun uses multiple times by using virtual keyword in base class for that particular function
// class having pure virtual functions means =0 then that class  is  pure virtaul class
// virtual function means no need of =0
class calculator
{
   public:
    virtual void cal() = 0; // pure virtual function due to =0
};
class SUM : public calculator
{
public:
    void cal()
    {
        int x, y;
        cout<<"Enter the first num"<<endl;cin>>x;
        cout<<"Enter the Second num"<<endl;cin>>y;
        cout << "sum of " << x << " and " << y << " is " << (x + y) << endl;
    }
};
class DIFF : public calculator
{
public:
    void cal()
    {
        int x, y;
        cout<<"Enter the first num"<<endl;cin>>x;
        cout<<"Enter the Second num"<<endl;cin>>y;
        cout << "Difference of " << x << " and " << y << " is " << x - y << endl;
    }
};
class DIVISION : public calculator
{
public:
    void cal()
    {
        float x, y;
        cout<<"Enter the first num"<<endl;cin>>x;
        cout<<"Enter the Second num"<<endl;cin>>y;
        cout << "Quatient of " << x << " and " << y << " is " << (x / y) << endl;
    }
};
class PRODUCT : public calculator
{
public:
    void cal()
    {
        int x, y;
        cout<<"Enter the first num"<<endl;cin>>x;
        cout<<"Enter the Second num"<<endl;cin>>y;
        cout << "Product of " << x << " and " << y << " is " << (x * y) << endl;
    }
};
int main()
{
    SUM s1;
    DIFF d1;
    DIVISION d2;
    PRODUCT p1;
    char op;
    cout << "Enter the operation you want to perform: " << endl;
    cin >> op;
    switch (op)
     {
        case '+':
          s1.cal();
          break;
        case '-':
          d1.cal();
          break;
        case '*':
          p1.cal();
          break;
        case '/':
          d2.cal();
          break;
    }
    
    // if (op == '+')
    // {
    //     s1.cal();
    // }
    // else if (op == '-')
    // {
    //     d1.cal();
    // }
    // else if (op == '*')
    // {
    //     p1.cal();
    // }
    // else if (op == '/')
    // {
    //     d2.cal();
    // }

    return 0;
}

// #include <bits/stdc++.h>
// using namespace std;
// // an abstract base class with constructor

// class base
// {
// protected:
//     int x;

// public:
//     virtual void fun() = 0;
//     base(int i)
//     {
//         x = i;
//         cout << "Constructor of base class " << endl;
//     }
// };
// class Derived : public base
// {
//     int y;

// public:
//     Derived(int i, int j) : base(i)
//     {
//         y = j;
//     }
//     void fun()
//     {
//         cout << "x= " << x << ", y= " << y << endl;
//     }
// };
// int main()
// {
//     Derived d(4,5);
//     d.fun();
//     // base *ptr =new Derived(6,7);
//     // ptr->fun();
//     return 0;
// }