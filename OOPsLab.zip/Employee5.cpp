// This is the way how we can
#include <bits/stdc++.h>
using namespace std;
class Employee
{
protected:
    string name; // we can also take the name as char[20]=name
    int id;
    float BasicSalary, DA, HRA, Salary;

public:
Employee() 
{
    cout << "Enter Employee Name: " << endl;
    cin >> name;
    cout << "Enter ID: " << endl;
    cin >> id;
   
}
Employee (float BasicSal, float da, float hra)
   {
    cout << "Enter the Salary data " << endl;
    BasicSalary=BasicSal;
    DA=da;
    HRA=hra;
    Salary=(BasicSalary+DA + HRA);
   }
    void showdata();
};


void Employee::showdata()
{
    cout << endl;
    cout << "Employee Name : " << name << endl;
    cout << "Employee Id : " << id << endl;
    cout << "Employee Salary : " << Salary << endl;
}
int main()
{
    float BasicSalary,DA,HRA;
    
    Employee obj;
    cout << "Enter the BasicSalary : " << endl;
    
    cin >> BasicSalary;
    cout << "Enter DA : " << endl;
    cin >> DA;
    cout << "Enter HRA : " << endl;
    cin >> HRA;
    Employee obj2(BasicSalary,DA,HRA);
    
    obj2.showdata();
    
    return 0;
}