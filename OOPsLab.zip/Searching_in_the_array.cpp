#include<bits/stdc++.h>
using namespace std;

int main(){
     int n;
    cout<<"Enter the size of array :";
     cin>>n;

     cout<<"Enter the array elements: ";
     
      int array[n];
     for (int  i = 0; i < n; i++)
     {
         cin>>array[i];
     }
     cout<<"Enter the number you want to search in the given array ";
      int k;
      cin>>k;
      for (int i = 0; i < n; i++)
      {
          if (array[i]==k)
          {
              cout<<i<<endl;
          }
          
      }
    return 0;
}