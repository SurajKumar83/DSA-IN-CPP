// Write a program to demonstrate the use of static data members.
#include <bits/stdc++.h>
using namespace std;
class A
{

public:
    static int Count;
    A()
    {
        cout << "Count: " << Count++ << " " << endl;
    }
};
int A::Count = 0;// intialize the Count variable outside the class using scope resolution operator 
int main()
{
    int n;
    cout<<"Enter the size of array:"<< endl;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        A a1;
    }
    cout << "For 2nd object call" << endl;
    cout << "Here we can see how the value of count having static keyword remain static" << endl;
    for (int i = 0; i < n; i++)
    {
        A a2;
    }
    cout << "Since Static data members are class level variables, we do not require the object to access these variables and they can be accessed simply by using the class name and scope resolution(::) operator with the variable name to access its value." << endl;
    cout << A::Count;
    return 0;
}