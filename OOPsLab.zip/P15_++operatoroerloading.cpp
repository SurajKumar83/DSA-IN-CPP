#include <bits/stdc++.h>
using namespace std;
class A
{
    int x;

public:
    A(int val)
    {
        x = val;
    }

    int operator++() // prefix
    {
        x++;
        return x;
    }
    A operator++(int) // Post increment
    {
        const A old(*this);
        ++(*this);
        return old;
    }
    int operator--() // prefix
    {
        x--;
        return x;
    }
    A operator--(int)
    { // postfix
        const A old(*this);
        --(*this);
        return old;
    }
    int display()
    {
        return x;
    }
};
int main()
{
    A a(3),b(4);
    cout << "Post Increment Operator" << endl;

    cout<<(a++).display()<<endl;
    cout << "Pre Increment Operator" << endl;
    ++a;
    cout<< a.display()<<endl;
    cout << "Post Decrement Operator" << endl;

    cout<<(b--).display()<<endl;
    cout << "Pre Decrement Operator" << endl;
    --b;
    cout<< b.display()<<endl;
    cout << endl;
   
}