#include "bits/stdc++.h"
using namespace std;
int main()
{
    // int a[3][3]={10,12,13,14,5,6,7,8,9};
    // int *p1;
    // p1=&a[0][0];
    // for (int i = 0; i<=8; i++)
    // {
    //    cout<<*(p1+i)<<endl;// p1[i] is same as *(p+i)
    //     cout<<&a[i]<<" "<<p1[i]<<endl;
        
    //     cout<<a[i]<<" "<<p1[i]<<endl;
         
    //     cout<<*a[i]<<" "<<p1[i]<<endl;// *a[i] gives value of each row
    //     cout<<endl;
    // }
   
//    char c[5]={"abcd"};// we have given size 5 but entered of four as last one is backslash

//     char *r=c;
//     cout<<r<<" "<<c<<endl<<r[1]<<" "<<r[2]<<endl;

// multiple dimension char array;
char d[5][5]={"1bcd","asdf","ascg","abc","def"};
char *s=&d[0][0];
cout<<*s<<" "<<s[3]<<" "<<s[2]<<endl<<s<<endl;//1 d c
//1bcd
    return 0; 
}