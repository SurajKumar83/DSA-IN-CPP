#include <bits/stdc++.h>
using namespace std;

class test
{
public:
    virtual void d() = 0;
};
class B : public test
{
public:
    void d()
    {
        cout << "class b" << endl;
    }
};
class C : public test
{
public:
    void d()
    {
        cout << "class c" << endl;
    }
};
int main()
{
    B b1;
    b1.d();
    C c1;
    c1.d();
    return 0;
}