// C++ program to find the prime numbers
// between a given interval
#include <bits/stdc++.h>
#include<cmath>

using namespace std;

// Function for print prime
// number in given range
void primeInRange(int L, int R)
{
	int flag;

	// Traverse each number in the
	// interval with the help of for loop
	for (int i = L; i <= R; i++) {

		// Skip 0 and 1 as they are
		// neither prime nor composite
		if (i == 1 || i == 0)
			continue;

		// flag variable to tell
		// if i is prime or not
		flag = 1;

		// Iterate to check if i is prime
		// or not
		for (int j = 2; j < sqrt(i); ++j) {
			if (i % j == 0)
             {
				flag = 0;
				break;
			}
		}

		// flag = 1 means i is prime
		// and flag = 0 means i is not prime
		if (flag == 1)
			cout << i << " ";
	}
}

// Driver Code
int main()
{
	// Given Range
    int l,r;
    cout<<"Enter the range : ";
    cin>>l>>r;

	// Function Call
	primeInRange(l, r);

	return 0;
}


