// Object Slicing




#include <iostream>
using namespace std;

class Parent
{
protected:
        int i;
public:
        Parent(int x)         { i = x; }
        virtual void show()
        { cout << "I am Base class object, i = " << i << endl; }
};

class Child : public Parent
{
        int j;
public:
        Child(int x, int y) : Parent(x) { j = y; }
        virtual void show()
        { cout << "I am Derived class object, i = "<< i << ", j = " << j << endl; }
};


void globalfun (Parent obj)
{
        obj.show();
}

int main()
{
        Parent b(33);
        Child d(45, 54);
        globalfun(b);
        globalfun(d); 
        return 0;
}