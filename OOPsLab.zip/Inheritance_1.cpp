#include <bits/stdc++.h>
using namespace std;
/*
Access in Base Class        Base Class Inherited As         Access in Derived Class
Public                      Public                          Public
Protected                                                   Protected
Private                                                     No access

Public                      Protected                       Protected
Protected                                                   Protected
Private                                                     No access

Public                      Private                         Private
Protected                                                   Private
Private                                                     No access

*/
// Protected data cannot be accessed for 3rd level inheritance.

// Base class
class Shape
{
protected:
    int width;
    int height;

public:
    void setWidth(int w)
    {
        width = w;
    }
    void setHeight(int h)
    {
        height = h;
    }
};

// Derived class
class Rectangle : public Shape
{
public:
    int getArea()
    {
        return (width * height);
    }
};
class C : public Rectangle
{
public:
    void show()
    {
        cout << width << endl
             << height << endl;
    }
    int getArea()
    {
        return (width * height);
    }
};
int main(void)
{
    Rectangle Rect;
    C c;
    Rect.setWidth(5);
    Rect.setHeight(7);
    c.setHeight(7);
    c.setWidth(5);
    // Print the area of the object.
    cout << "Total area: " << Rect.getArea() << endl;
    c.show();
    cout << "Total area in c class: " << c.getArea() << endl;
    return 0;
}