#include<bits/stdc++.h>
using namespace std;

int main(){
    int arr1[5];
    int arr2[3][4];
    int arr3[1][2][3];
    int arr4[3][4][5][6];
    char arr5[5];
    char arr6[3][4];
    char arr7[3][4][5];
    char arr8[3][4][5][6];

    // int in
    // for(int i = 0; i < 1; i++){
    //     cin >> arr1[i];
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++)
    //         cin >> arr2[i][j];
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             cin >> arr3[i][j][k];
    //         }
    //     }
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             for(int l = 0; l < 4; l++){
    //                 cin >> arr4[i][j][k][l];
    //             }
    //         }
    //     }
    // }

    // // char in
    // for(int i = 0; i < 1; i++){
    //     cin >> arr5[i];
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++)
    //         cin >> arr6[i][j];
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             cin >> arr7[i][j][k];
    //         }
    //     }
    // }
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             for(int l = 0; l < 4; l++){
    //                 cin >> arr8[i][j][k][l];
    //             }
    //         }
    //     }
    // }

    // // int out
    // for(int i = 0; i < 1; i++){
    //     cout << arr1[i] << " ";
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++)
    //         cout << arr2[i][j] << " ";
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             cout << arr3[i][j][k] << " ";
    //         }
    //     }
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             for(int l = 0; l < 4; l++){
    //                 cout << arr4[i][j][k][l] << " ";
    //             }
    //         }
    //     }
    // }
    // cout << endl;

    // //  char out
    // for(int i = 0; i < 1; i++){
    //     cout << arr5[i] << " ";
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++)
    //         cout << arr6[i][j] << " ";
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             cout << arr7[i][j][k] << " ";
    //         }
    //     }
    // }
    // cout << endl;
    // for(int i = 0; i < 1; i++)
    // {
    //     for(int j = 0; j < 2; j++){
    //         for(int k = 0; k < 3; k++){
    //             for(int l = 0; l < 4; l++){
    //                 cout << arr8[i][j][k][l] << " ";
    //             }
    //         }
    //     }
    // }
    // cout << endl;

    int *ip;
    char *cp;
    ip = &arr3[0][0][0];
    // for(int i = 0; i < 1; i++){
    //     cin >> *cp++;  // combination of two statements i.e *ip and ip++
    // }
    for(int i = 0; i < 1; i++){
        for(int j = 0; j < 2; j++){
            for(int k = 0; k < 3; k++){
                cin >> arr3[i][j][k];
            }
        }
    }
    // for(int i = 0; i < 1; i++){
        // for(int j = 0; j < 2; j++){
            // for(int k = 0; k < 3; k++){
                // cout << **arr3[i] << " ";   // p to p
            // }
        // }
    // }
    // cout << arr3[0][0][0][0] << endl; // 3 *'s are due to 3-d array
    // for(int i = 0; i < 12; i++){
    //         cout <<  *ip++ << " ";
    // }
    // // cout << *cp << endl;
    // cout << endl;
    // for(int i = 0; i < 3; i++){
    //     // for(int j = 0; j < 4; j++){
    //         cout << *ip[i] << " "; // Not allowed 
    //     // }
    // }
    return 0;
}