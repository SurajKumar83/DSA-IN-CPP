#include <bits/stdc++.h>
using namespace std;
void f1(int a, int b) 
{ 
  int c; 
  c=a;
  a=b;
  b=c; 
}

void f2(int *a, int *b)
 { 
  int c; 
  c=*a; 
  *a=*b; 
  *b=c; 
}

int main()
{ 
int a=4, b=5, c=6; 
f1(a,b); // call by value 
cout<<a<<" "<<b<<" "<<endl;//4 5
f2(&b, &c); // call by reference 
cout<<b<<" "<<c<<" "<<endl;//6 5
cout<<c-a-b<<endl;//-5
}