#include<bits/stdc++.h>
using namespace std;
class A{
    protected:
    int i;
    private:
    int j;
    
    public:
    void set(){
        cout<<"Enter the value for 1st number: "<<endl;cin>>i;
        cout<<"Enter the value for 2nd number: "<<endl;cin>>j;
    }
    void show()
    {
        cout<<"Base class called"<<endl;
        cout<<"Sum of "<<i<<" and "<<j<<" is "<<(i+j)<<endl;
    }
};
class B: public A
{
};
int main(){
    B b;
    int x,y;
    b.set();
    b.show();
    return 0;
}