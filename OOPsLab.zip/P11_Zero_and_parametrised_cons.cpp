// Write a program to demonstrate the use of const data members.
#include <bits/stdc++.h>
using namespace std;
class Area
{
    int radius;
    float val_of_pi;

public:
    Area()
    {
        cout << "Zero arguments area constructor" << endl;
    }
    int feed_data()
    {
        cout << "Feed radius data" << endl;
        cin >> radius;
        cout << "Feed pi data" << endl;
        cin >> val_of_pi;
    }
    float getArea()
    {
        cout << "Get Area" << endl;
        cout<< val_of_pi * radius * radius<<endl;
    }
    Area(int x, float pi)
    {
        cout << " Parameterised  area constructor" << endl;
        radius = x;
        val_of_pi = pi;
        cout << val_of_pi * radius * radius << endl;
    }
};
int main()
{
    Area Area1;
    Area1.feed_data();
    Area1.getArea();
    cout << endl;
    Area Area2(7, 3.141);
}
