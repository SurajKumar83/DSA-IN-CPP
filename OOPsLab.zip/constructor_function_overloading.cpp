#include<bits/stdc++.h>
using namespace std;
class overloading 
{
   int val_of_pi;
   int radius;
   public:
   overloading()
   {}
   
   overloading(int pi,int r){
      val_of_pi=pi;
      radius=r;
   }
    overloading(int r){
      val_of_pi=3.14;
      radius=r;
   }
   float getArea(){
       return val_of_pi*radius*radius;
   }
   // function overloading

   float area3(float pi,float r){
       cout<<"Area of triangle:- "<<(pi*r*r)<<endl;
   }
   float area3(float r){
       cout<<(3.14*r*r)<<endl;
   }
};
void area(float pi,float r){
    cout<<(pi*r*r)<<endl;
}
int main()
{
    overloading area1(3.14,7),area2(7),area;
    cout<<"constructor overloading"<<endl; 
    cout<<"Area1 "<<area1.getArea()<<endl;
    cout<<"Area2 "<<area2.getArea()<<endl;
    cout<<"function overloading"<<endl;
    area.area3(3.14,7);
    area.area3(7);
    return 0;
}