//#include <iostream>
//
//using namespace std;
//
//class Box {
//        private:
//      double length;     // Length of a box
//      double breadth;    // Breadth of a box
//      double height;     // Height of a box
//      public:
//      static int objectCount;
//      // Constructor definition
//      Box(double l = 2.0, double b = 2.0, double h = 2.0) {
//         cout <<"Constructor called." << endl;
//         length = l;
//         breadth = b;
//         height = h;
//        
//         // Increase every time object is created
//         objectCount++;
//      }
//                 double Volume() {
//         return length * breadth * height;
//      }
//};
//
//// Initialize static member of class Box
//int Box::objectCount;
//
//int main(void) {
//   Box Box1(3.3, 1.2, 1.5);    // Declare box1
//   Box Box2(8.5, 6.0, 2.0);    // Declare box2
//   // Print total number of objects.
//   cout << "Total objects: " << Box::objectCount << endl;
//
//   return 0;
//}
//
//



//#include <iostream>
 
//using namespace std;

//class Box {
//   public:
//      static int objectCount;
//      const int j=10;
//      // Constructor definition
//      Box(double l = 2.0, double b = 2.0, double h = 2.0) {
//         cout <<"Constructor called." << endl;
//         length = l;
//         breadth = b;
//         height = h;
//         // Increase every time object is created
//         objectCount++;
//      }
//      double Volume() {
//         return length * breadth * height;
//      }
//      static int getCount() {
//      return objectCount;
//      }
//      
//   private:
//      double length;     // Length of a box
//      double breadth;    // Breadth of a box
//      double height;     // Height of a box
//};
//
//// Initialize static member of class Box
//int Box::objectCount;
//int main(void) {
//   // Print total number of objects before creating object.
//  cout << "Inital Stage Count: " << Box::getCount() << endl;
//
//   Box Box1(3.3, 1.2, 1.5);    // Declare box1
//   Box Box2(8.5, 6.0, 2.0);    // Declare box2
//
//   // Print total number of objects after creating object.
//   cout << "Final Stage Count: " << Box::getCount() << endl;
//
//   return 0;
//}

//#include <iostream>
//using namespace std;
//class Test
//{
//public:
//    Test()
//    {
//        cout << "Constructor is executed\n";
//    }
//    ~Test()
//    {
//       cout << "Destructor is executed\n";
//    }
//};
//void myfunc()
//{
//    static Test obj;
//} // Object obj is still not destroyed because it is static
//  
//int main()
//{
//   // cout << "main() starts\n";
//    myfunc();    // Destructor will not be called here
//          //cout << "main() terminates\n";
//    return 0;
//}

// #include <iostream>
// using namespace std;
// class Test
// {
// public:
//     int a;
//     Test()
//     {
//         a = 130;
//         //cout << "Constructor is executed\n";
//     }
//     Test(const Test &t1, Test t2)
//     {
//             Test t3;
//             //t1.a=30;
//             t3=t1;
//             t2.a=40;
//             cout<<t3.a<<endl<<t2.a;
//         }
//     ~Test()
//     {
//         //cout << "Destructor is executed\n";
//     }
// };

// int main()
// {
//         const Test obj;
//         Test obj1,obj2,obj3(obj1,obj2);
// //    cout << obj.a<<endl;
// //    //obj.a=20;
// //    cout<<obj.a<<endl;
// //    obj1.a=29;
// //    cout<<obj1.a<<endl;
//     return 0;
// }

//int fun1(int n) {
//    static int i= 0;
//    if (n > 0) {
//       ++i;
//      fun1(n-1);
//   }
//  return (i);
//}
//int fun2(int n) {
//   static int i= 0;
//   if (n>0) {
//      i = i+ fun1 (n) ;
//      fun2(n-1) ;
//  }
//return (i);
//}