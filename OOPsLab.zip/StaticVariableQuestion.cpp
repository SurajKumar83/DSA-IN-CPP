#include <bits/stdc++.h>
using namespace std;

// class Test 
// {
//     static int x;
//     public:
//     Test()
//     {
//         x++;
//     }
//     static int getX()
//      {
//           return x; 
//      }
// };

class Player
{
 private:
 int id;
 static int next_id;
 public:
 int getID()
 {
     return id;
 }
 Player()
 {
     id=next_id++;
 }
};
int Player::next_id=2;

// int Test:: x=0;// compulsary for making static variable
int main()
 {

    // cout<<Test::getX()<<" ";
    // Test t[6];// array of 5 object 
    // cout<<Test::getX();

    Player p1;
    Player p2;
    Player p3;
    cout<<p1.getID()<<" ";
    cout<<p2.getID()<<" ";
    cout<<p3.getID()<<" ";
    return 0;
}