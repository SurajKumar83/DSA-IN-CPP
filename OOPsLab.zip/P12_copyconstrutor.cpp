// Write a program to demonstrate the use of const data members.
#include <bits/stdc++.h>
using namespace std;
class Area
{
    int x;

public:
    Area(int val)
    {
        cout<<"Original constructor called"<<endl;
        x = val;
    }
    Area(const Area &obj1)
    {
        cout << "Copy constructor called" << endl;
        x = obj1.x;
        cout << "The value of X using copy constructor " << x << endl;
    }
 
};
int main()
{
    Area a1(2);
    Area a2 = a1;
}
