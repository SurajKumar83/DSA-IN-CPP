/*
Copy Constructor is constructor which
creates an object by initializing
it with an object of the same class.

1. It is used to initialize one object from
 another of the same type
2. Copy an object to pass it as an argument
 to a function .
3. Copy and object to return it from a
 function.

*/
#include <iostream>
using namespace std;
class Line
{
private:
    int L1;

public:
    Line(int len)
    {
        cout << "Normal constructor" << endl;
        L1 = len;
    }
    Line(const Line &obj)
    {
        cout << "Copy constructor" << endl;
        L1 = obj.L1; // copy the value
       
    }
    void ModifyLength(int var){
        cout<<"Modified length"<<endl;
            L1=var;
    }
    int printLength()
    {
        cout << L1<<endl;

    }
};
int main()
{
    Line line1(10);
    Line line2 = line1;
    line1.printLength();
    line2.printLength();
    line2.ModifyLength(11);
    line1.printLength();
    line2.printLength();
    return 0;
}