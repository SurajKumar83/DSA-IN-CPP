#include "bits/stdc++.h"
using namespace std;

class c1
{
public:
    float x;


    c1() { x = 4.3; }
    friend class c2;
};
class c2
{
public:
    int y;
    c2() {}
    c2(int val) { y = val; }
     
    friend c2 operator+(c1 &obj1, c2 &obj2)
    {
        c2 temp;
        temp.y = obj1.x + obj2.y;
        return temp;
    }
    void show()
    {
        cout << y << endl;
    }
};
int main()
{
    c1 cl1, cl2;
    c2 cl3(56), cl4;
    cl4 = cl1 + cl3;
    cl4.show();
}
