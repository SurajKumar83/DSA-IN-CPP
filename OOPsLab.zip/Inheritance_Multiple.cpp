#include "bits/stdc++.h"
using namespace std;
class circle
{
    int radius;

public:
    void setRadius()
    {
        cout << "Enter the radius of the circle: " << endl;
        cin >> radius;
    }
    void CArea()
    {
        cout << "Area of the circle: " << (3.14 * radius * radius) << endl;
    }
};
class Rectangle
{
    int width;
    int length;

public:
    void setDimensions()
    {
        cout << "Enter the length and width of the rectangle: " << endl;
        cin >> length >> width;
    }
    void RArea()
    {

        cout << "Area of the Rectangle: " << (length * width) << endl;
    }
};
class Area : public circle, public Rectangle
{
};
int main()
{
    Area area;
    area.setRadius();
    area.setDimensions();
    area.CArea();
    area.RArea();
    return 0;
}