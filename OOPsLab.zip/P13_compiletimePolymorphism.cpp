// Write a program to demonstrate the run time polymorphism.

#include <iostream>
using namespace std;
class Parent
{
public:
    virtual void virtualshow()
    {
        cout << "Parent class" << endl;
    }
    void show()
    {
        cout << "Parent class show function" << endl;
    }
};
class Derived : public Parent
{
public:
    void virtualshow()
    {
        cout << "Derived class" << endl;
    }
    void show()
    {
        cout << "Derived class show function" << endl;
    }
};
int main()
{
    Parent *b;
    Derived d;
    b = &d;
    b->show();//Non virtual function 
    b->virtualshow(); // virtual function, binded at runtime
    d.show();
}