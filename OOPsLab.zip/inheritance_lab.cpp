#include<bits/stdc++.h>
using namespace std;
class f
{
    private:
    int real;
    int img;
    int a;
    public:
    f()// Default constructor to initalize real and img to 0
    {
        real=0;img=0;
    }
    
    void input()
    {
        cout<<"Enter real and imaginary part of the Complex Number"<<endl;
        cin>>real;
        cin>>img;
    
    }

    void input1()
    {
        cout<<"Enter the real number you want to add to real part "<<endl;
       cin>>a;
    }
    
    f operator +(const f&obj)
    {
        f temp;
        temp.real=real+obj.real;
        temp.img=img+obj.img;
        return temp;
    }

   f operator +(int a)
    {
        
        f temp;
        temp.real=real +a;
        temp.img=img ;
        return temp; 
    }
    
   
    void output()
    {
        cout<<real<<"+"<<" i"<<img<<endl;
    }
};

int main()
{
    f c1,c2,result;// f is object of function that
    int a;
    cout<<"Enter the real number you want to add to complex number "<<endl;
    cin>>a;
    c1.input();
    c2.input();
    result=c1+c2;
    result.output();
    result=c1+a;
    result.output();
    return 0;
}