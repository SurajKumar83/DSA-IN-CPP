#include <bits/stdc++.h>
using namespace std;
class A
{
    int x;

public:
    A(int val)
    {
        x = val;
    }

    A() {}
    A operator+(A &a1)
    {
        A tmp;
        tmp.x = x * a1.x;
        return tmp;
    }
    A operator-(A &a1)
    {
        A tmp;
        tmp.x = x / a1.x;
        return tmp;
    }
    A operator/(A &a1)
    {
        A tmp;
        tmp.x = a1.x;
        return tmp;
    }
    void print()
    {
        cout << x << endl;
    }
};
int main()
{
    A a(10), b(5), res;
    res = a + b;
    cout << "Value of a*b using + operator " << endl;
    res.print();
    res = a - b;
    cout << "Value of a/b using - operator" << endl;
    res.print();
    res = a / b;
    cout << "Value of b to a using / operator" << endl;
    res.print();
    res = b / a;
    cout << "Value of a to b using / operator" << endl;
    res.print();
}