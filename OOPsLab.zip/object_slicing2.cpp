#include<bits/stdc++.h>
using namespace std;
class Base{
   int x;
   public:
   Base(int x) : x(x) {}
 void display(){ cout<<"x: of Base class "<<x<<endl;}
};
class Derived: public Base{
    int y;
    public:
    Derived(int x,int value) :Base(x)
    {
        y=value;
    }
    void display(){ cout<<"y: of Derived class "<<y<<endl;}
};
int main(){
    Derived d(23,32);
    Base b(32);
    b.display();
    b=d;
    b.display();
    return 0; 
}