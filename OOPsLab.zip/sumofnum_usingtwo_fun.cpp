#include<bits/stdc++.h>
using namespace std;

class Test{
    private:
    int firstNum,seconNum;// data hiding 
    public:
    void f1(){
        cout<<"Input two nums";
        cin>>firstNum>>seconNum;
    }
    void add(){
        cout<<"Result:"<<firstNum+seconNum;
    }
};
int main(){
    Test m;// creaing an obj of the class
    m.f1();
    m.add();

    return 0;
}
