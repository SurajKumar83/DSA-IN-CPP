//WAP to access the private data members of two different classes and find their sum
#include<bits/stdc++.h>
using namespace std;
class B;
class A{
    private:
    int i;
    public:
    void setdata()
    {
         cout<<"Entered the value "<<endl;cin>>i;
    }
    friend void sum(A,B);
};
class B
{
    private:
    int j;
    public:
    void setdata()
    {
       cout<<"Entered the value "<<endl;cin>>j;
     }
    friend void sum(A,B);
};
void sum(A a,B b)
{
    int SUM=a.i+b.j;
   cout<<"Sum of "<<a.i<<" and "<<b.j<<" is  "<<SUM<<endl;

}
int main(){
    A a1;
    B b1;
    a1.setdata();
    b1.setdata();
    sum(a1,b1);
    return 0;
}