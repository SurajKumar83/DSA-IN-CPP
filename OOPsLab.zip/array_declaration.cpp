#include<bits/stdc++.h>
using namespace std;
int main(){
    int marks[50],i;
    float sum=0;
    cout<<"Enter marks of student :"<<endl;
    marks[0]=2;
    marks[1]=11;
    marks[2]=25;
    marks[3]=24;
    marks[4]=27;
    marks[5]=29;
    marks[6]=28;
    for (int i = 0; i < 7; i++)
    {
        cout<<marks[i]<<" ";
    }
    cout<<endl;
    
    for (int i = 0; i <7; i++)
    {
        sum+=marks[i];
    }
    cout<<"Sum of the elements is: "<<sum<<endl;
    cout<<"Average of these numbers: "<<(sum/7)<<endl;


}