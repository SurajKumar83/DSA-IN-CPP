#include "bits/stdc++.h"
using namespace std;
class A
{

public:
    int length;
    void setlength()
    {
        cout << "Enter the value of length: " << endl;
        cin >> length;
    }
};
class B
{
public:
    void shape_name()
    {
        cout << "This is in square shape" << endl;
    }
};
class C : public A
{
public:
    void area()
    {
        cout << length * length << endl;
    }
};
class D : public B, public C
{
public:
    void square()
    {
        cout << "The area of this square shape is ";
    }
};
int main()
{

    D d;
    d.setlength();
    d.shape_name();
    d.square();
    d.area();
}