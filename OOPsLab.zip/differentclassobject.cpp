#include<iostream>
using namespace std;

// class c1
// {
// public:
// float m1;
// public:
//     c1()
//     {
//       m1=3.9;
//     }
// // c1 operator =(c2 &a){
// //    c1 temp;
// //    m1=a.m;
// //    temp.m1=m1;
// //    return temp;
// // }
// c1(c1 &c)
// {
// m1=c.m1;
// }
// c1 operator = (c2 &a){
//     c1 tem;
//     tem.m1=a.m2;
//     return tem;
// }
// void showc1()
// {
// cout<<"value is"<<endl<<m1<<endl;
// }
// };
// class c2
// {
//    public:
//    float m2;
//    public:
//    c2()
//    {
//     m2=3.3;
//    }
//    c2(int i)
//    {
//     m2=i;
//    }
//    c2 operator=(c1 &c)
//    {
//     c2 f;
//     m2=c.m1;
//     f.m2=m2;
//     return(f);
//    }
//    void showc2()
//    {
//     cout<<"value is"<<endl<<m2<<endl;
//    }
// };

// Plus Over loading 
class c3
{
     public:
    int a;
    c3(){}
    c3 (int x)
    {
     a=x;
    }
   friend c3 operator +(c3 A, c3 B){
       c3 temp;
       temp.a = A.a+B.a;
       return temp;
   }
     friend c3 operator +(c3 A, int B){
       c3 temp;
       temp.a = A.a+B;
       return temp;
   }
  void output()
  {
      cout<<"Output is"<<a<<endl;
  }
};

// class c4
// {
//      public:
//      int d;
//     c4(){}
//   c4(int x){
//       d=x;
//   }
//     c4 operator +(const c3& obj4)
//     {// in case of taking more than one arument use friend keyword before
//       c4 temp;
//        d =d+ obj4.a;
//       temp.d=d;
//       return temp;
//     }
//     void Show()
//     {
//         cout<<"d"<<d<<endl;
//     }
// };

int main()
{

//    c1 cl1,cl2;
//    int i=1;
//    c2 cl3(56),cl4;
//    cl4=cl1;
//    cl4.showc2();
// cl1=cl4;torun this it need to declare class 2 before c1
// cl1.showc1();

c3 C1(28),C2(21);
C1=C1+C2+3;

C1.output();
}
// c4 D,result;
// D=C+D;
// D.Show();
// }  
/*
c2 cl3(20),cl4(70);
cl4=cl3+cl4+7;
cl4.showc2();
cl4=cl3+7+cl4;
cl4.showc2();
*/