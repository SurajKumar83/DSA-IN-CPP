/*
 create pointer to the objects of a class for
 entering name of the cities and then count
length of the city name that you have entered
 in the pointer object.
 */

#include "bits/stdc++.h"
#include<string>
using namespace std;
// class CityName
// {
//     public:
//     string name;
//     int Length;
//     void getLength(string s){
//         name=s;
//         Length=s.length();
//     } 
//     void showLength(){
//         cout<<"Length of CityName: "<<Length<<endl;
//     }   

// };
// const int size=2;
// int main()
// {
//     CityName *p=new CityName[size];
//     CityName *d=p;
//     string str;
//     for (int i = 0; i < size; i++)
//     {
//         cout<<"Enter CityName: "<<endl;
//         cin>>str;
//         p->getLength(str);
//         p++;
//     }
//     for (int i = size-1; i >=0; i--)
//     {
       
//         p--;
//     }
//     for (int i = 0; i < size; i++){
//         cout<<"CityName: "<<i+1<<endl;
//         p->showLength();
//         p++;
//     }
    
// }

class person
{
   public:
   int age;
   char name[100];
   
   person(char *s,float b){
       strcpy(name,s);
     age=b;
   }
   
   void display()
   {
       cout<<"Name "<<name<<end<<"Age "<<age<<end<<end;

   }
  person &person::greator(a &x)
{
    if(x.age>=age)
       return x;
    else
       return *this;
   }
};

int main(){
    person p1("Ram",25.5),p2("Shita",28);
    person p=p1.greator(p2);
    cout<<"Elder one is "<<endl;
    p.display();
    return 0;
}