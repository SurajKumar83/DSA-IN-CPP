#include "bits/stdc++.h"
using namespace std;
class A
{
    protected:
    int i;
public:
    A(int v)
   { i=v;}
   void print_outside();
    
};
void A::print_outside()
{
    cout << "value of i using outside decleration of memeber fun" << endl;
    cout << i << endl;
    cout<<"We have used scope resolution operator"<<endl;
}
int main()
{
    A a(9);
    a.print_outside();
}
