#include<bits/stdc++.h>
using namespace std;

// void sumofarray(int arr[],int n){
//     int s=0;
//     for (int i = 0; i < n; i++)
//     {
//         s+=arr[i];
//     }
//     cout<<"Sum of array elements:"<<s<<endl;
    
// }

int sumofarray(int arr[],int n){
    int ans=0;
    for (int i = 0; i<n; i++)
    {
        ans+=arr[i];
    }
    return 19;// this will be the return as it execute first
    return ans;
    
    
}
int main(){
    int arr[100],n;
    cout<<"Enter size of an array:-";
    cin>>n;
     cout<<"Enter array elements:-";
     for (int i = 0; i <n; i++)
     {
         cin>>arr[i];
     }
     cout<<sumofarray(arr,n)<<endl;
     
    return 0;
}