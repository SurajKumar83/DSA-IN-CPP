#include<bits/stdc++.h>//heder file which include all function of 
using namespace std;
int main(){
    int firstNum,secondNum,sumofNums;
    cout<<"Enter two integers: ";
    cin>>firstNum>>secondNum;

    sumofNums=firstNum+secondNum;
    cout<<firstNum<<"+"<<secondNum<<"  =  "<<sumofNums;

    return 0;
}