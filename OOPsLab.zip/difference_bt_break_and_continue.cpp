#include<bits/stdc++.h>
using namespace std;

int main()
{

    for (int j = 11; j <=15; j++)
    {
        for (int  i = 1; i <=10; i++)
       {
        cout<<i<<" j =" <<j;
        if (j==13)
        {
            cout<<" CHECK 1... "<<endl;
            continue;
        }
        if(i==8)
        {
            cout<<" BREAK..."<<endl;
            break;
        }
        cout<<" check 3... ";
        cout<<i<<endl;
      }
      cout<<"check 4..."<<endl;
    }
    
    return 0 ;
}
/*
1 j =11 check 3... 1
2 j =11 check 3... 2
3 j =11 check 3... 3
4 j =11 check 3... 4
5 j =11 CHECK 1...    as when i = 5 then we are not getting check 3 as after check 1 there is continue which says that to move again to start of loop
6 j =11 check 3... 6
7 j =11 check 3... 7
8 j =11 BREAK...  as we are not getting anything after i==8 executed means break of loop
*/