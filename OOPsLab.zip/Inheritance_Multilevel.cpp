#include<bits/stdc++.h>
using namespace std;

class Dim
{
    protected:
   int len;
   int wid;
   public:
   void setDimensions(){
       cout<<"Length and width are: "<<endl;
       cin>>len>>wid;
   }
};
class area:public Dim
{
     protected:
    int Area;
   public:
    void setArea()
    {
        Area=len*wid;
       if (len>wid)
       {
            cout<<"Area of rectangle is "<<Area<<endl;
       }
       if (len==wid)
       {
            cout<<"Area of square is "<<Area<<endl;
       }
    }
};

class VOLUME:public area
{
    int h;
  public:
  void set_height(){
      cout<<"Enter the value of height: "<<endl;cin>>h;
  }
  void Volume()
  {

     if (len>wid || len>h||h>len||wid>h||wid<h)
     {
          cout<<"Volume of cuboid is: "<<Area*h<<endl;
     }
     if (len==wid && wid==h)
     {
         cout<<"Volume of cube is: "<<Area*h<<endl;
     }
  }
};
int main(){

   VOLUME sh;
   sh.setDimensions();
   sh.setArea();
   sh.set_height();
   sh.Volume();

}