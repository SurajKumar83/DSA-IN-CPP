// This is the way how 
#include <bits/stdc++.h>
using namespace std;
class Employee
{
    protected:
  string name;
  int id;
  float BasicSalary, DA, HRA, Salary;

public:
 float calculate_sal(float, float, float);
 void feed_data();
 void showdata(); 
};
 void Employee:: feed_data()
  {
    cout << "Enter Employee Name: " << endl;
    cin >> name;
    cout << "Enter ID: " << endl;
    cin >> id;
    cout << "Enter the Salary data " << endl;
   
    cout << "Enter the BasicSalary : "<< endl;
    cin >> BasicSalary;
    cout << "Enter DA : "<< endl;
    cin >> DA;
    cout << "Enter HRA : "<< endl;
    cin >> HRA;
    calculate_sal(BasicSalary, DA, HRA);
  }

  float Employee::calculate_sal(float BasicSalary, float DA, float HRA)
  {
    Salary = (BasicSalary + DA + HRA);
  }
   void Employee:: showdata() 
  {
    cout << endl;
    cout << "Employee Name : " << name << endl;
    cout << "Employee Id : " << id << endl;
    cout << "Employee Salary : " << Salary << endl;
  }
int main()
{
  Employee emp;
  emp.feed_data();
  emp.showdata();
  return 0;
}