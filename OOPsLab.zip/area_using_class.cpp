// Function Overloading
#include <bits/stdc++.h>
using namespace std;

class Area
{
   private:
   int length,breadth;
   public:
      Area()
      {
          length=5;
          breadth=10;
      }
       Area(int l,int b)
      {
          length=l;
          breadth=b;
      }
   void getlength()
   {
       cin>>length>>breadth;
   }
   int AreaCalculation(){
       return (length * breadth);
   }
   void DisplayArea(int a){
       cout<<"Area of the Rectangle :"<<a<<endl;
   }


};
int main()
{
    Area a1;// Default  constructor is called 
    Area a2(5,2);// Parameteridsed Constructor is called
    int area1,area2;
    a1.getlength();
    cout<<"\n \n Calculating Area using a Default Constructor:"<<endl;
     
    area1 =a1.AreaCalculation();
    a1.DisplayArea(area1);
    cout<<"\n\nCalculating Area using a Parameterised Constructor: "<<endl;
    area2=a2.AreaCalculation();
    a2.DisplayArea(area2);


    
    return 0;
}
