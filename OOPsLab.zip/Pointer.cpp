#include "bits/stdc++.h"
using namespace std;
int main()
{
    int *p, a;
    a = 5;
    p = &a;
    cout << "Value of a " << a << endl;                    // Value of a =5
    cout << "address of a " << &a << endl;                 // address of a 0x61ff08
    cout << "value stored in p " << p << endl;             // value stored in p 0x61ff08
    cout << "value of address stored in p " << *p << endl; // value of address stored in p 5

    cout << "address of p " << &p << endl; // address of p 0x61ff0c

    int n[] = {12, 8, 3, 4, 5};
    int *ptr1;
    int i;
    cout << *n << endl; // similar to n[0]
    cout << *n + 2 << endl;
    cout << *(n + 2) << endl;
    cout << n[0] + 2 << endl;
    ptr1 = n; // for &n[0]

    cout << "base address " << ptr1 << endl;           // base address 0x61fef4
    cout << "value at base address " << *ptr1 << endl; // value at base address 1

    cout << "address of ptr1 " << &ptr1 << endl; // address of ptr1 0x61fef0
    cout << *(++ptr1) << endl
         << ++(*ptr1) << endl; // to print next address of ptr then derefrence 8 but next one will give 2 as in that case first we derefrence then pre Increment
    cout << *ptr1++ << endl;   // print value at value of ptr1
    int *ptr2 = &n[2];         // way of declaring particular address

    cout << *ptr2++ << endl; // print value at value of ptr2
    int *tofind = ptr2 + 4;

    bool found = false;
    for (int i = 0; i < 5; i++)
    {
        if (n[i] == *tofind)
        {
            found = true;
            cout << "At index " << i << endl;
        }
    }
    if (found == true)
    {
        cout << "Founded element is " << *tofind << endl;
    }
    else
    {
        cout << "Not found and the garbage value is " << *tofind << endl;
    }
    int num = 4;
    bool found = false;
    for (int i = 0; i < 5; i++)
    {
        if (*ptr2 == num)
        {
            cout << "Number exists " << num << " at location " << ptr2 << endl;
            break;
        }

        ptr2++;
    }
}