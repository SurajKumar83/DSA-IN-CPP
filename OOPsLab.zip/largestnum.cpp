// to find largest num
#include<iostream>
using namespace std;
int main(){

    int i,n;
    float array[100];


    cout<<"Enter total number of elements(1 to 100)";
    cin>>n;
    cout<<endl;
    // store number entered by the user 
    for (int i = 0; i < n; i++)
    {
        cin>>array[i];
    }

    // loop to store largest number to array[0]
    for (int i = 0; i < n; i++)
    {
        // change <to > if you want to find the smallest element
        if (array[0]<array[i])
        {
          array[0]=array[i];
        }
        
    }
    cout<<"Largest element = "<<array[0];
    return 0;
    
    
}