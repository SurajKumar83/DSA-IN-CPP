//WAP using static member variables to count the entered number of students by the user.
#include"bits/stdc++.h"
using namespace std;
class StudentCount
{
	
	string NameofStudent;// variable to store name of the student
	int  Reg_Num_Number;//variable to store the Reg_Num number of the student
	public:
	static int Count;// Static Variable That will count the number of 
	//students and the keyword static means value can be update but 
	//that will reamin for whole program
	StudentCount(string str,int Reg_Num_Num)
	{
		
		NameofStudent=str;
		Reg_Num_Number=Reg_Num_Num;
		Count++;
		cout<<"Student Count Till now is: "<<Count<<endl;
	}
};
int StudentCount::Count=0;
int main()
{
	bool flag=true;
	int check;
	string NameofStudent;
	int Reg_Num;
	while(flag)
	{
		cout<<"Enter 1 if you want to enroll "<<endl<<"Enter 0 if you want to stop"<<endl;
		cin>>check;
		if(check!=0 && check!=1)
		{
			cout<<"Please Enter the Correct Number "<<endl;
			continue;
		}
		if(check==0)
		{
			flag=false;
			continue;
		}
		cout<<"Enter the Name of Student -"<<endl;
		cin>>NameofStudent;
		cout<<"Enter the Reg_Num.No -"<<endl;
		cin>>Reg_Num;
		StudentCount obj(NameofStudent,Reg_Num);//After Each Entering of Name and Reg_Num we will get the an updated value of the number of students
		
	}
	
	
	cout<<"Total students enrolled for this program: "<<StudentCount::Count<<endl;
	return 0;
}