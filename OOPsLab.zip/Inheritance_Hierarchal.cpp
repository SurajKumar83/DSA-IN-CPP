#include "bits/stdc++.h"
using namespace std;

class A
{
  
  public:
  void property(){
      cout<<"Property of Parallelogram: "<<endl;
      
  }
};
class B : public A
{
    public:
    void p1(){
        cout<<"The opposite sides are parallel: "<<endl;
    }

};
class C : public A
{
   public:
void p2(){
       cout<<"The opposite sides are congruent(equal in length ): "<<endl;
   }
};
class D : public A
{
   public:
void p3(){
       cout<<"The opposite angles are equal to each other: "<<endl;
   }
};
class E : public A
{
   public:
void p4(){
       cout<<"Any two adjacent angles add up to 180 degrees: "<<endl;
   }
};
int main(){
    B b;C c;D d;E e;
   
   b.property();
   b.p1();
   c.p2();
   d.p3();
   e.p4();
return 0;
}