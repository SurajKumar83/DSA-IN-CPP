// Average of array element using class

#include<bits/stdc++.h>
using namespace std;
class Arr{
  // int n;// size of array
   public:
   float sum(float arr[],int n){
       float ans =0;
       for (int i = 0; i < n; i++)
       {
           ans+=arr[i];
       }
       return ans/n;
       
   }

};
int main(){
    float arr[]={2,4,5,2,35,3,4,6};
    Arr odj;
    cout<<odj.sum(arr,8)<<endl;
    
}