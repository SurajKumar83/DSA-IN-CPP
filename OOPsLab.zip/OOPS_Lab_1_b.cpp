// swaping of two number
#include<iostream>
using  namespace std;
int main(){
    int a=5,b=19,temp;
    cout<<"Before swapping"<<endl;
    cout<<"a ="<<a<<"and b ="<<b<<endl;
    temp=a;
    a=b;
    b=a;
     cout<<"After swapping"<<endl;
    cout<<"a ="<<a<<"and b ="<<b<<endl;

    return 0;
}