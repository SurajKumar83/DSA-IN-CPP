/* Friend Function :
1 used for function overloading.
2 indipendent of class but friend of class
3 can access private member of class
4 Normal 
*/ 
#include "bits/stdc++.h"
using namespace std;
class Box
{
    private:
    int length;
    public:
      Box(): length(0){}
    friend int printLength(Box );// friend function 
   

};

int printLength(Box b)//No need to use help of obj of class , also save time and memory 
{
    b.length+= 10;
    return b.length;
}
int main(){
    Box b;
    cout<<"Length of box: "<<printLength(b)<<endl;
    return 0;
}
