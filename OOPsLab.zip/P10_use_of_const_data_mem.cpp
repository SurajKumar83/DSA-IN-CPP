// Write a program to demonstrate the use of const data members.
#include <bits/stdc++.h>
using namespace std;
class Area
{
    int radius;
    int val_of_pi;

public:
   //const int val_of_pi = 3.14;

    Area(int x, int pi)
    {
        radius = x;
        val_of_pi = pi;//Once initialized, a const data member may never be modified, not even in the constructor or destructor.
        cout << pi * radius * radius << endl;
    }
};
int main()
{

    Area Area2(7, 3.141);
}
