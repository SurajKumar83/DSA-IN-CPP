#include<bits/stdc++.h>
using namespace std;

class destru
{
     int a;
     int b;
     public:
     destru(int j, int k)
     {
         a=j;b=k;
     }
     destru(destru &j){
         a=j.a;b=j.b;
     }
     ~destru(){
         cout<<"destructor called"<<endl;
     }
};
void f1(){
    destru d1(34);
}
int main(){
    // Default constructor called automatically when the object is created
    int i=0;
    f1();// constructor 
    return 0;
}