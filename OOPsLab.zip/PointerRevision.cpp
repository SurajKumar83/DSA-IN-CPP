#include "bits/stdc++.h"
using namespace std;
int main()
{
    int *p, a;
    a = 5;
    p = &a;
    // p=a; this is not permissible as we cann't store the pointer to int to int
    // cout<<a<<endl;// value at a
    // cout<<&a<<endl;// address of a
    //  cout<<p<<endl;// address of a
    // // cout<<*p<<endl;// value at value of p(value of a)
    // // cout<<&p<<endl;// address of p
    // p=p+2;
    // cout<<p<<endl;
    //  cout<<*p<<endl;
    // p=p-1;
    // cout<<p<<endl;
    // cout<<*p<<endl;
    // p=p*2;
    // p=p/2;
   // int arr[] = {9, 2, 8, 4, 5};
   int arr[]={65,9,8,89,5};
    int *ptr1; // array of pointers of int type
    int **g = &ptr1;
    int *ptr2 = arr;     // means storing base address
    int *ptr3 = &arr[0]; // means address of first value of the array
                         // cout<<ptr2[0]//<<endl<<ptr3<<endl<<arr<<endl<<*ptr3<<endl;
    cout<<*++ptr3<<endl;
    cout<<++*ptr3<<endl;
    // ptr3++;
    // cout << *ptr3++ << endl; // 2
    // cout << *ptr3<<endl;           // 8
    // int i;
    // cout<<*arr+2 << endl;// *arr means value at index 0 then add 2 to it
    // // cout<<*(*arr+2)<<endl; as we can use asterisk to value means (*arr+2) is value not address
    // cout<<*(arr+1)<<endl;// output 2
    // cout<<arr[1]<<endl;// output 2 both same
    // int num = 9;
    // for (int i = 0; i < 7; i++)
    // {
    //     if (*ptr3 == num)
    //     {
    //         cout << "Number " << num <<" exits at location " << ptr3;
    //         break;
    //     }
    //     ptr3++;
    // }
}