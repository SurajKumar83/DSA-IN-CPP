//SUM OF TWO NUMBER 
#include<iostream>
using namespace std;
int main(){
    int firstNum,secondNum,sumofnumber;
    cout<<"Enter two number:-";
    cin>>firstNum;cin>>secondNum;
    //sum of two num
    sumofnumber=firstNum+secondNum;
    cout<<"Sum of "<<firstNum<<"and"<<secondNum<<"="<<sumofnumber<<endl;
        return 0;
}