#include<bits/stdc++.h>
using namespace std;
#define ll unsigned long long int
ll factorial(int num) {

    if (num==0||num==1) return 1;
    else
    {
        ll fact=1;
        for (int i=2; i<=num; i++){
           fact*=i;
        }
        return fact;
    }
    
}
int main(){
    int num;
    cout<<"Enter the number you want to  find Factorial of : "<<endl;
    cin>>num;
    cout<<"Factorial of the number is : "<<factorial(num)<<endl;
    return 0;
}