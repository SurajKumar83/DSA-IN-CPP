#include <iostream>

using namespace std;
class item
{
  int code;
  float price;

public:
  void getdata(int a, float b)
  {
    code = a;
    price = b;
  }
  void show()
  {
    cout << "code " << code << endl;
    cout << "price" << price << endl;
  }
};
const int size = 2;
int main()
{
  item *p = new item[size]; // Dynamic memory allocation
  item *d = p;
  int x;
  float y;
  for (int i = 0; i < size; i++)
  {
    cout << "input code and price " << i + 1;
    cin >> x >> y;
    p->getdata(x, y);
    p++;
  }
  for (int i = 0; i < size; i++)
  {
    cout << "item: " << i + 1 << endl;
    d->show();
    d++;
  }
  return 0;
}
