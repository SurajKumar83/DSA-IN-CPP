#include<iostream>
using namespace std;
int main()
{

 
  int a,b;
  cout<<"Enter integer value:-"<<endl;
  cin>>a;
  cout<<endl;
  cout<<a<<" "<<a++<<" "<<++a<<" "<<endl;
  a++;
  cout<<"postfix answer is="<<a<<endl;
  ++a;
  cout<<"prefix answer is="<<a<<endl;
  b=a++;
  cout<<"postfix answer is="<<b<<endl<<a<<endl;
  b=++a;
  cout<<"prefix answer is="<<b<<endl<<a<<endl;
  int g=++a + ++b;
  cout<<"answer is:-"<<g<<endl;
  cout<<a<<" "<<b<<endl;
  g=a++ +b;
  cout<<"answer is:-"<<g<<endl;
 cout<<a<<" "<<b<<endl;
  g=++++a;
cout<<"answer is:-"<<g<<endl;
cout<<a<<" "<<b<<endl;
 
  char c;
  cout<<"Enter the character:-"<<endl;
  cin>>c;
  c++;
  cout<<"postfix answer is="<<c<<endl;
  ++c;
  cout<<"prefix answer is="<<c<<endl;
  char d=c;
  cout<<"postfix answer is ="<<d<<endl;
  d=++c;
  cout<<"prefix answer is ="<<d<<endl;
  char e=c++ + ++d;
  cout<<"answer is = "<<e<<endl;

  float f;
  cout<<"Enter the number:-"<<endl;
  cin>>f;
  f++;
  
  cout<<"postfix answer is="<<f<<endl;
  ++f;
  cout<<"prefix answer is="<<f<<endl;
  float h=f;
  cout<<"postfix answer is ="<<h<<endl;
  h=++f;
  cout<<"prefix answer is ="<<h<<endl;
  float i=f++ + ++h;
  cout<<"answer is = "<<i<<endl;
  return 0;
}