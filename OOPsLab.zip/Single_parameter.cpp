#include<bits/stdc++.h>
using namespace std;

class MyClass{
   int a,b;
   public:
      MyClass(int i)
      {
          a=i;
          b=i;
      }
      void Display(){
          cout<<"a= "<<a<<" b="<<b<<endl;
      }
 
 

};
int main (){
    MyClass obj(10);
    obj.Display();

    //Single Parameter Conversion Constructor is invoked
    obj=20;
    obj.Display();
    return 0;
}